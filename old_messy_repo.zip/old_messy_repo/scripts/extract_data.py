import os
import yaml
import pandas as pd
from aim.sdk import Repo
from aim.storage.context import Context

# Load the repository
repo = Repo("")

# out path
out_path = "run_metrics"

# Get all runs in the repository
runs = repo.iter_runs()

# Specify names of runs to export
name = "lda_precycles_interpolation_ethanol"
out_path = os.path.join(out_path, name)
os.makedirs(out_path, exist_ok=True, mode=0o777)

# Specify the metrics to export
metrics_to_export = [
    "epoch mean absolute train loss",
    "epoch mean absolute val loss",
    "epoch mean absolute val energy difference [Ha]",
    "epoch mean absolute train energy difference [Ha]",
    "train energy difference [Ha]",
    "train target energy [Ha]",
    "train predicted energy [Ha]",
    "train xc energy [Ha]",
    "val energy difference [Ha]",
]

# Collect data from each run
for run in runs:
    if name in run.name:
        params_path = os.path.join(out_path, "params_" + run.name + ".yaml")
        yaml.dump(
            {"hparams": run["hyperparameters"], "data": run["data"]},
            open(params_path, "w"),
        )
        df = pd.DataFrame({"step": []})
        for metric in metrics_to_export:
            try:
                v = run.get_metric(metric, context=Context({"SchNet": "debug"}))
                temp_df = pd.DataFrame(v.dataframe())
                temp_df = pd.DataFrame(
                    {"step": temp_df["step"], metric: temp_df["value"]}
                )
                df = df.merge(temp_df, how="outer", on="step")
            except:
                print(f"Metric {metric} not found in run {run.name}")
        metrics_path = os.path.join(out_path, "metrics_" + run.name + ".csv")
        df.to_csv(metrics_path, index=False)
