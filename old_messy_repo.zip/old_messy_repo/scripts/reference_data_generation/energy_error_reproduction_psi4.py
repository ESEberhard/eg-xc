import psi4


# QM9 dataset: https://pytorch-geometric.readthedocs.io/en/latest/generated/torch_geometric.datasets.QM9.html#torch_geometric.datasets.QM9
methane_string =  """
C  -1.26999998e-02  1.08580005e+00  8.00000038e-03
H   2.19999999e-03 -6.00000005e-03  2.00000009e-03
H   1.01170003e+00  1.46379995e+00  3.00000014e-04
H  -5.40799975e-01  1.44749999e+00 -8.76600027e-01
H  -5.23800015e-01  1.43789995e+00  9.06400025e-01"""

qm9_energy_label = -40.47890535014648  # energy in Hartree

methane = psi4.geometry(methane_string)

# psi4.energy('scf/cc-pVDZ', molecule=methane)
# # psi4:     -40.19871356776252
# # pyscf:    -40.19870845634066

# psi4.energy('b3lyp/6-311G(2df,p)', molecule=methane)
# # psi4:                       -40.5349868698392370
# # pyscf 6-31G(2df,p):         -40.52311294216243
# # Gaussian 09 6-31G(2df,p):   -40.47890535014648

ethanol_string = """
C   5.52056776e-03  5.91490030e-01 -8.13817489e-04
C  -1.25363934e+00 -2.55356789e-01 -2.98005920e-02
O   1.08783066e+00 -3.07554662e-01  4.82298136e-02
H   6.28212094e-02  1.28375268e+00 -8.42788577e-01
H   6.05666963e-03  1.23031211e+00  8.85346413e-01
H  -2.21822071e+00  1.89805046e-01 -5.81601225e-02
H  -9.10971701e-01 -1.05392635e+00 -7.81595826e-01
H  -1.19200945e+00 -7.42476821e-01  9.21966732e-01
H   1.84879851e+00 -2.86324043e-02 -5.25690258e-01"""

ethanol = psi4.geometry(ethanol_string)

psi4.energy('ccsd/cc-pVTZ', molecule=ethanol)
## psi4:
#  @RHF Final Energy:  -154.12222713223522

## pyscf:
# Energy Label from MD17 Dataset (CCSD(T)):-154.72139891619085
# hartree fock energy:                     -154.1222271322938
# Energy CCSD(T):                          -154.8248247209799