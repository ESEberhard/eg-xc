from pyscf import gto, cc, scf, dft


# QM9 dataset: https://pytorch-geometric.readthedocs.io/en/latest/generated/torch_geometric.datasets.QM9.html#torch_geometric.datasets.QM9
methane =  "6  -1.26999998e-02  1.08580005e+00  8.00000038e-03; \
            1   2.19999999e-03 -6.00000005e-03  2.00000009e-03; \
            1   1.01170003e+00  1.46379995e+00  3.00000014e-04; \
            1  -5.40799975e-01  1.44749999e+00 -8.76600027e-01; \
            1  -5.23800015e-01  1.43789995e+00  9.06400025e-01"

qm9_energy_label = -40.47890535014648  # energy in Hartree

cc_molecule = gto.Mole(
                atom = methane,
                basis = 'cc-pVDZ',  # CCSD(T) compatible basis
                unit='angstrom'
            ).build()


### CC related computation pipeline
hartree_fock = scf.RHF(cc_molecule)  # restricted hartree fock
hartree_fock.run()
coupled_cluster = cc.CCSD(hartree_fock, frozen=1)  # freeze core orbitals
coupled_cluster.kernel()
ccsd_t_correction = coupled_cluster.ccsd_t()
ccsd_t_energy = coupled_cluster.e_tot + ccsd_t_correction


### DFT related computation pipeline following procedure explained in
#   https://doi.org/10.1038/sdata.2014.22:
#   * Basis: 6-31G(2df,p)
#   * XC: B3LYP
#   * Different Software: Gaussian 09
dft_molecule = gto.Mole(
                atom = methane,
                basis = '6-31G(2df,p)',
                unit='angstrom'
            ).build()

dft_b3lyp = dft.RKS(dft_molecule)
# dft_b3lyp.xc = 'B3LYP'
dft_b3lyp.xc = '.2 * HF + .08 * LDA + .72 * B88, .81 * LYP + .19 * VWN5' # B3LYP: Gaussian convention
# dft_b3lyp.xc = '.2 * HF + .08 * LDA + .72 * B88, .81 * LYP + .19 * VWN3' # B3LYP: pyscf convention

# # Additional Things I tried to recover the energy label from the QM9 dataset:
#   dft_b3lyp.verbose = 4       # increase verbosity level for debugging (optional)
#   dft_b3lyp.max_cycle = 200   # increase max iterations
#   dft_b3lyp.conv_tol = 1e-12  # decrease convergence tolerance
#   dft_b3lyp.grids.level = 9   # Try Ultrafine integration grid

dft_b3lyp.run()

print("Energy Label from QM9 Dataset (B3LYP): \t", qm9_energy_label,
      "\nB3LYP Energy: \t\t\t\t", dft_b3lyp.e_tot,
      "\nhartree fock energy: \t\t\t", hartree_fock.e_tot,
      "\nEnergy CCSD(T): \t\t\t", ccsd_t_energy)

# OUTPUT [hartree]:
# Energy Label from QM9 Dataset (B3LYP):   -40.47890535014648
# B3LYP Energy:                            -40.52311294216243
# hartree fock energy:                     -40.19870845634066
# Energy CCSD(T):                          -40.38726974427279


# MD17 dataset: https://pytorch-geometric.readthedocs.io/en/latest/generated/torch_geometric.datasets.MD17.html#torch_geometric.datasets.MD17
ethanol = " 6   5.52056776e-03  5.91490030e-01 -8.13817489e-04; \
            6  -1.25363934e+00 -2.55356789e-01 -2.98005920e-02; \
            8   1.08783066e+00 -3.07554662e-01  4.82298136e-02; \
            1   6.28212094e-02  1.28375268e+00 -8.42788577e-01; \
            1   6.05666963e-03  1.23031211e+00  8.85346413e-01; \
            1  -2.21822071e+00  1.89805046e-01 -5.81601225e-02; \
            1  -9.10971701e-01 -1.05392635e+00 -7.81595826e-01; \
            1  -1.19200945e+00 -7.42476821e-01  9.21966732e-01; \
            1   1.84879851e+00 -2.86324043e-02 -5.25690258e-01"


md17_energy_label = -154.72139891619085  # energy in Hartree

# Calculation methods as layed out in https://doi.org/10.48550/arXiv.1802.09238:
# * Basis: cc-pVTZ
# * Theory: CCSD(T) for ethanol
# * Different Software: Psi4
cc_molecule = gto.Mole(
                    atom = ethanol,
                    basis = 'cc-pVTZ',  # CCSD(T) compatible basis
                    unit='angstrom'
                ).build()

hartree_fock = scf.RHF(cc_molecule)  # restricted hartree fock
hartree_fock.run()

coupled_cluster = cc.CCSD(hartree_fock, frozen=3)  # freeze core orbitals
coupled_cluster.kernel()
ccsd_t_correction = coupled_cluster.ccsd_t()
ccsd_t_energy = coupled_cluster.e_tot + ccsd_t_correction

print("Energy Label from MD17 Dataset (CCSD(T)):", md17_energy_label,
      "\nhartree fock energy: \t\t\t ", hartree_fock.e_tot,
      "\nEnergy CCSD(T): \t\t\t ", ccsd_t_energy)

# OUTPUT [hartree]:
# Energy Label from MD17 Dataset (CCSD(T)):-154.72139891619085
# hartree fock energy:                     -154.1222271322938
# Energy CCSD(T):                          -154.8248247209799

# Things I played with to recover the energy label from the MD17 dataset:
#   hartree_fock = dft.RKS(molecule).newton()
#   hartree_fock.diis_space = 15
#   hartree_fock.conv_tol = 1e-12
#   hartree_fock.max_cycle = 100
#   hartree_fock.init_guess = 'minao'(default) vs. 'atom'
#   hartree_fock = hartree_fock.apply(scf.addons.remove_linear_dep_)
#   coupled_cluster.diis_space = 10