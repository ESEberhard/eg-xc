"""
Automize the Coupled Cluster density data generation process
"""

import numpy as np
from pyscf import gto, dft
from torch_geometric.datasets import QM9
import h5py

from tqdm import tqdm
import logging

DATA_PATH = './mldft/data/custom_densities/qm9'
# BASIS = '6-311++G(3df,2pd)'
BASIS = '6-31G(2df,p)'
RESTRICTED = True
SET_SIZE = 100

logging.basicConfig(filename=f'{DATA_PATH}/qm9.log',
                    filemode='a',
                    level=logging.INFO)

data_set = QM9(root=f'{DATA_PATH}/../torch_geometric/')

for set_idx in range(len(data_set) // SET_SIZE + 1):
    logging.info(f'Generating data for "QM9_{set_idx * SET_SIZE}" \n \
                    \t Basis: {BASIS} \n\
                    \t Restricted: {RESTRICTED}')

    outfile = DATA_PATH + f"/QM9_{set_idx * SET_SIZE}_CCSD(T)  copy.h5"

    with h5py.File(outfile, 'a') as f:
        parameters_group = f.create_group("dft_reference_params")
        parameters_group.create_dataset("restricted", data=RESTRICTED)
        parameters_group.create_dataset("basis", data=BASIS)

    for id in tqdm(range(SET_SIZE)):

        logging.info(f'Generating data for sample {id + set_idx * SET_SIZE}' \
                        + f'of {SET_SIZE}')

        sample = data_set[id + set_idx * SET_SIZE]
        atoms = np.concatenate((sample['z'][:,None], sample['pos']), axis=1)
        atoms_str = str(atoms).replace('\n', ';')\
                            .replace('[', '')\
                            .replace(']', '')\
                            .replace('.00000000e+00', ' ')\
                            .replace('. ', ' ')

        energy_label = sample["y"][0, 7] * 0.0367493  # energy in Hatree

        molecule = gto.Mole(
                    atom = atoms_str,
                    basis = BASIS,
                    unit = 'angstrom'  # TODO: Check
                ).build()

        for xc in ['LDA', 'PBE', 'SCAN', 'B3LYP']:
            if RESTRICTED:
                mean_field = dft.RKS(molecule)
            else:
                mean_field = dft.UKS(molecule)

            mean_field.xc = xc
            mean_field.run()
            energy = mean_field.e_tot
            logging.info(f"energy label {energy_label} calculated {energy}")


            with h5py.File(outfile, 'a') as f:
                sample = f[str(id)].create_group(xc)
                sample.create_dataset("density_matrix",
                                      data=mean_field.make_rdm1())
                sample.create_dataset("energy",
                                      data=energy)
