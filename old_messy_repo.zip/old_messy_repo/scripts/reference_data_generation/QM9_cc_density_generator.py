"""
Automize the Coupled Cluster density data generation process
"""

import numpy as np
from pyscf import gto, cc, scf
from torch_geometric.datasets import QM9
import h5py

from tqdm import tqdm
import logging

DATA_PATH = './mldft/data/custom_densities/qm9'
BASIS = 'cc-pVDZ'
RESTRICTED = True
SET_SIZE = 100

logging.basicConfig(filename=f'{DATA_PATH}/qm9.log',
                    filemode='w',
                    level=logging.INFO)

data_set = QM9(root=f'{DATA_PATH}/../torch_geometric/')

for set_idx in range(len(data_set) // SET_SIZE + 1):
    logging.info(f'Generating data for "QM9_{set_idx * SET_SIZE}" \n \
                    \t Basis: {BASIS} \n\
                    \t Restricted: {RESTRICTED}')

    outfile = DATA_PATH + f"/QM9_{set_idx * SET_SIZE}_CCSD(T).h5"

    with h5py.File(outfile, 'a') as f:
        parameters_group = f.create_group("system_params")
        parameters_group.create_dataset("restricted", data=RESTRICTED)
        parameters_group.create_dataset("basis", data=BASIS)

    for id in tqdm(range(SET_SIZE)):

        logging.info(f'Generating data for sample {id + set_idx * SET_SIZE}' \
                        + f'of {SET_SIZE}')

        sample = data_set[id + set_idx * SET_SIZE]
        atoms = np.concatenate((sample['z'][:,None], sample['pos']), axis=1)
        atoms_str = str(atoms).replace('\n', ';')\
                            .replace('[', '')\
                            .replace(']', '')\
                            .replace('.00000000e+00', ' ')\
                            .replace('. ', ' ')

        energy_label = sample["y"][0, 7] * 0.0367493  # energy in Hatree

        molecule = gto.Mole(
                    atom = atoms_str,
                    basis = BASIS,
                ).build()

        if RESTRICTED:
            mean_field = scf.RHF(molecule)
        else:
            mean_field = scf.UHF(molecule)
        mean_field.run()

        coupled_cluster = cc.CCSD(mean_field)
        coupled_cluster.kernel()
        ccsd_t_correction = coupled_cluster.ccsd_t()

        energy = coupled_cluster.e_tot + ccsd_t_correction

        # if abs(energy - energy_label) > ccsd_t_correction:
        #     logging.warn(f'\t Energy difference: {energy - energy_label} Hartrees' \
        #                  + f'larger than CCSD(T) correction: {ccsd_t_correction} Hartrees')

        density_matrix = coupled_cluster.make_rdm1()

        with h5py.File(outfile, 'a') as f:
            sample = f.create_group(str(id))
            sample.create_dataset("molecule", data=molecule.atom)
            sample.create_dataset("density_matrix", data=density_matrix)
            energy_group = sample.create_group("energy")
            energy_group.create_dataset("ccsd_t", data=energy)
            energy_group.create_dataset("scf", data=mean_field.e_tot)
            energy_group.create_dataset("cc", data=coupled_cluster.e_tot)