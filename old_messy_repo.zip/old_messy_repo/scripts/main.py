import logging
import tqdm


if __name__ == "__main__" or True:
    from copy import deepcopy
    import os
    import jax
    import optax

    jax.config.update("jax_compilation_cache_dir", os.path.expanduser("~/.jax_cache"))

    from mldft.sacred_config import ex
    from mldft import scf, grids
    from mldft.xc_energy import get_xc_energy_fn
    from mldft.systems.initializer import ElementInitializer
    from mldft.dataloading import get_dataloaders
    from mldft.utils.typing import NnParams, LossAuxiliaryOutput, MoleculeSolverParams
    from mldft.utils.logger import Logger
    from mldft.utils.checkpointer import Checkpointer
    from mldft.train_and_eval import get_optimizer, loss
    from mldft.train_and_eval.training import train, pretrain_mgga
    from mldft.train_and_eval.testing import test
    from mldft.systems.molecule_params import preprocess_params
    from seml.utils import Hashabledict
    from mldft import nn

    from typing import Tuple

    @ex.automain
    def run(
        log_params,
        data_params,
        hparams,
        debug_params,
        db_collection,
        ggxc_model,
        irreps,
        local_readout,
        global_readout,
        use_mgga_model,
        feature_dim,
        overwrite,
        prepare_dataset: bool = False,
    ):
        to_log_conf = deepcopy(locals())
        hparams = Hashabledict(deepcopy(hparams))
        jax.config.update("jax_default_matmul_precision", "float32")

        log_params = deepcopy(log_params)
        if db_collection is not None:
            log_params["name"] = f"{db_collection}_{overwrite}"
            log_params["dir"] = os.path.expanduser(f"~/mldft_logs/{log_params["name"]}")

        if hparams["test"]:
            print("###### WARNING: TESTING MODE ######")

        if debug_params["disable_jit"]:
            jax.config.update("jax_disable_jit", True)
        if debug_params["enable_x64"]:
            jax.config.update("jax_enable_x64", True)
        if debug_params["debug_nans"]:
            jax.config.update("jax_debug_nans", True)

        logger = Logger(log_params, to_log_conf)
        logger.log_config_params("data", data_params)

        if log_params["make_checkpoints"]:
            checkpointer = Checkpointer(log_params)
            if hparams["model"]["use_metaGGA"] and log_params["make_checkpoints"]:
                name = hparams["model"]["metaGGA"]["pretraining"]["dir_name"]
                mgga_checkpointer = Checkpointer(log_params, name=name, pretrain=True)
            else:
                mgga_checkpointer = None
        else:
            checkpointer = None

        # initialize molecule grid
        molecule_grid = grids.generate_base_grid(
            grid_spacing=hparams["density_grids"]["molecule_grid_spacing"],
            cutoff=hparams["density_grids"]["molecule_cutoff"],
        )

        # initialize atom_grid
        base_atom_grid = grids.generate_base_grid(
            grid_spacing=hparams["density_grids"]["atom_max_grid_spacing"],
            cutoff=hparams["density_grids"]["atom_max_cutoff"],
        )

        # element_initializer = ElementInitializer(hparams, data_params["atom_data_dir"])
        element_initializer = None

        # initialize dataloaders
        train_data, val_data, test_data, dataset, train_indices, val_indices = (
            get_dataloaders(
                data_params,
                molecule_grid.coords,
                base_atom_grid.coords,
                hparams,
                element_initializer,
                return_test_set=hparams["test"],
            )
        )
        if prepare_dataset:
            logging.info("Iterating training data")
            to_compile = set()
            with tqdm.tqdm(train_data) as tq:
                for _ in tq:
                    h = hash(jax.tree_map(jax.numpy.shape, _[-1]))
                    to_compile.add(h)
                    tq.set_postfix({"n_compiled": len(to_compile)})
            logging.info("Iterating validation data")
            to_compile = set()
            with tqdm.tqdm(val_data) as tq:
                for _ in tq:
                    h = hash(jax.tree_map(jax.numpy.shape, _[-1]))
                    to_compile.add(h)
                    tq.set_postfix({"n_compiled": len(to_compile)})
            if hparams["test"]:
                to_compile = set()
                logging.info("Iterating test data")
                with tqdm.tqdm(test_data) as tq:
                    for _ in tq:
                        h = hash(jax.tree_map(jax.numpy.shape, _[-1]))
                        to_compile.add(h)
                        tq.set_postfix({"n_compiled": len(to_compile)})

        # initialize model and define xc_energy
        model = nn.get_model(hparams)
        from mldft.nn.model import NewModel

        model = NewModel(
            model.mgga_model if use_mgga_model else None,
            irreps=irreps,
            global_model=ggxc_model,
            local_readout=local_readout,
            global_readout=global_readout,
            feature_dim=feature_dim,
        )

        feature_fn_factory = grids.FeatureFnFactory(
            hparams, base_atom_grid, None
        )

        gnn_feature_fn = (
            feature_fn_factory.get_gnn_feature_fn()
            if hparams["model"]["use_schnet"] or hparams["model"]["use_painn"]
            else None
        )

        mgga_feature_fn = (
            feature_fn_factory.get_meta_gga_feature_fn()
            if hparams["model"]["use_metaGGA"]
            else None
        )

        _, _, _, init_sample = train_data.__iter__().__next__()
        init_sample = preprocess_params(
            init_sample, hparams, data_params["max_number_of_atoms"], False
        )

        model, params = nn.init_model(
            model,
            init_sample,
            mgga_feature_fn,
            gnn_feature_fn,
            seed=hparams["model"]["seed"],
        )

        logger.log_parameter_shapes(params)

        xc_energy_fn = get_xc_energy_fn(model, hparams, mgga_feature_fn, gnn_feature_fn)

        optimizer, opt_state = get_optimizer(hparams["optimizer"], params)

        if hparams["eri_calculation"]["using_host_callbacks"]:
            j_fns_list = dataset.get_j_fns()
        else:
            j_fns_list = None

        # solver_fn = scf.solver.get_solver(xc_energy_fn, hparams, j_fns_list)
        solver_fn = scf.solver.get_interpolated_solver(xc_energy_fn, hparams, j_fns_list)

        loss_fn = loss.get_loss_fn(
            solver_fn,
            molecule_grid,
            hparams["energy_weights"],
            hparams["density_weights"],
        )

        loss_grad_fn = jax.value_and_grad(loss_fn, argnums=0, has_aux=True)

        @jax.jit
        def step(
            params: NnParams,
            opt_state: optax.OptState,
            target_energy: float,
            target_density: jax.Array,
            mol_params: MoleculeSolverParams,
            key=None,
        ) -> Tuple[NnParams, optax.OptState, LossAuxiliaryOutput]:
            """
            Performs a single optimization step.
            """
            (loss, auxiliary_data), grads = loss_grad_fn(
                params, target_energy, target_density, mol_params, key
            )

            if (
                hparams["optimizer"]["schedule"]["type"] == "reduce_on_plateau"
                or hparams["optimizer"]["schedule"]["type"]
                == "reduce_on_plateau_with_linear_decay"
            ):
                updates, opt_state = optimizer.update(
                    grads, opt_state, params, value=loss
                )
            else:
                updates, opt_state = optimizer.update(grads, opt_state, params)
            params = optax.apply_updates(params, updates)
            grad_norm = optax.global_norm(grads)
            update_norm = optax.global_norm(updates)
            auxiliary_data = auxiliary_data.replace(grad_norm=grad_norm, update_norm=update_norm)
            return params, opt_state, auxiliary_data

        if (
            hparams["model"]["use_metaGGA"]
            and hparams["model"]["metaGGA"]["pretraining"]["epochs"] > 0
        ) and use_mgga_model:
            pretrain = not hparams["model"]["metaGGA"]["pretraining"]["load"]
            try:
                if not pretrain:
                    mgga_params = mgga_checkpointer.load_best()
            except ValueError:
                pretrain = True
                print("Pretraining metaGGA model")
            if pretrain:
                mgga_params = pretrain_mgga(
                    init_sample,
                    hparams["model"]["seed"],
                    opt_state,
                    train_data,
                    val_data,
                    hparams,
                    data_params,
                    mgga_feature_fn,
                    molecule_grid,
                    mgga_checkpointer,
                    logger,
                )

            params["params"]["mgga_model"] = mgga_params["params"]

        jax.clear_caches()  # free all compiled functions
        params = train(
            params,
            train_data,
            val_data,
            step,
            loss_fn,
            hparams,
            opt_state,
            logger,
            molecule_grid,
            checkpointer,
            gnn_feature_fn,
            data_params,
        )

        jax.clear_caches()  # free all compiled functions
        if hparams["test"]:
            test(
                params,
                train_data,
                val_data,
                test_data,
                hparams,
                data_params,
                loss_fn,
                molecule_grid,
                logger,
            )
