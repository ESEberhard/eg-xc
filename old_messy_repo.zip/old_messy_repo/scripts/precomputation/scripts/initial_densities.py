import os
import abc
import numpy as onp
from seml.experiment import Experiment
from mldft.dataloading.utils import DataDir, np_array_to_pyscf_string
from mldft.utils.initial_density_generation import compute_initial_densities_for_data_set
from torch_geometric.datasets import QM9

from typing import Any

ex = Experiment()


ROOT_DIR = "/nfs/homedirs/eberhare/ml-powered_dft/src/mldft/data"


class BaseDataset:
    data: Any
    def __len__(self):
        return len(self.data)

    @abc.abstractmethod
    def get_molecule_string(self, idx: int) -> str:
        pass

    def __getitem__(self, idx: slice | int):
        if isinstance(idx, slice):
            out = []
            step = idx.step if idx.step is not None else 1
            for i in range(idx.start, idx.stop, step):
                out.append(self.get_molecule_string(i))
            return out
        else:
            return self.get_molecule_string(idx)


class QM9Dataset(BaseDataset):
    def __init__(self,
                 root_dir: str = os.path.join(ROOT_DIR, "qm9")):
        self.root_dir = root_dir
        self.data = QM9(root_dir)

    def get_molecule_string(self, idx: int) -> str:
        sample = self.data[idx]
        atoms = onp.concatenate((sample['z'][:,None], sample['pos']), axis=1)
        mol_str = np_array_to_pyscf_string(atoms)
        return mol_str


class Mace3BPA(BaseDataset):
    def __init__(self,
                 key: str,
                 root_dir: str = os.path.join(ROOT_DIR, "3bpa")):
        self.root_dir = root_dir
        self.data = DataDir(os.path.join(root_dir, "preprocessed", key))

    def get_molecule_string(self, idx: int) -> str:
        atoms = self.data[idx]
        return np_array_to_pyscf_string(atoms)


@ex.config
def config():
    dataset = "3bpa"
    key = "train_300K"
    xc = "LDA"
    basis = "6-31G(d)"
    precycles = 15
    out_dir = f"/ceph/hdd/students/eberhare/3bpa/initial_densities/{key}/{xc}_{basis}_{precycles}/"
    mol_per_job = 10
    job_id = 0


@ex.automain
def generate(
    dataset: str,
    key: str,
    xc: str,
    basis: str,
    precycles: int,
    out_dir: str,
    mol_per_job: int,
    job_id: int) -> None:

    dataparams = {
        "initial_density": {
            "precycles": precycles,
            "xc": xc,
            "sub_dir_size": None,
        }
    }
    hparams = {
        "basis": basis,
        "restricted": True,
    }

    if dataset == "qm9":
        dataset = QM9Dataset()
    elif dataset == "3bpa":
        dataset = Mace3BPA(key)
    else:
        raise NotImplementedError(f"Dataset {dataset} not implemented")

    # split the dataset into jobs
    start = job_id * mol_per_job
    end = min(start + mol_per_job, len(dataset))
    compute_initial_densities_for_data_set(
        out_dir=out_dir,
        dataset=dataset[start:end],
        dataparams=dataparams,
        hparams=hparams,
        offset=start
    )


# @ex.config
# def config():
#     out_dir = "/nfs/students/eberhare/initial_densities/LDA_6-31G(d)_15/"
#     block_id = 0
#     files_per_dir = 5000
#     blocks_per_dir = 50
#     start_id = 0
#     end_id = 16

#     dataparams = {
#         "initial_density": {
#             "precycles": 15,
#             "xc": "LDA"
#         }
#     }

#     hparams = {
#         "basis": "6-31G(d)",
#         "restricted": True,
#     }

# @ex.automain
# def generate(out_dir: str,
#              dataparams: Dict[str, Any],
#              hparams: Dict[str, Any],
#              files_per_dir: int,
#              blocks_per_dir: int,
#              block_id: int,
#              start_id: int,
#              end_id: int) -> None:

#     dataset = QM9Dataset()
#     if end_id is None:
#         end_id = len(dataset)

#     block_size = (end_id - start_id) // (files_per_dir * blocks_per_dir)

#     assert files_per_dir % blocks_per_dir == 0
#     block_size = files_per_dir // blocks_per_dir

#     start = start_id + block_id * block_size
#     end   = start_id + (block_id + 1) * block_size

#     out_dir = os.path.join(out_dir, str((start // files_per_dir) * files_per_dir))
#     os.makedirs(out_dir, exist_ok=True)

#     compute_initial_densities_for_data_set(
#         out_dir, dataset, dataparams, hparams, start, end)
