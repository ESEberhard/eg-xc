from mldft.utils.typing import MoleculeParams

import matplotlib.pyplot as plt
import numpy as np
from typing import Optional
from numpy.typing import ArrayLike


def plot_lstsq_atomwise_energy(n_molecules: int,
                               total_xc_energy: ArrayLike,
                               xc_energy_atom_regression: ArrayLike,
                               reference_xc: str,
                               recompute: bool) -> plt.Figure:
    id = np.arange(n_molecules)
    if recompute:
        plt.scatter(id, np.abs(xc_energy_atom_regression - total_xc_energy))
        plt.title('Atomwise xc energy error')
        plt.xlabel('Molecule index')
        plt.ylabel('xc energy error [Ha]')
        plt.show()
        plt.scatter(id, total_xc_energy)
        plt.title(f'{reference_xc} xc energy')
        plt.xlabel('Molecule index')
        plt.ylabel('xc energy [Ha]')
        plt.show()
    else:
        plt.scatter(id, xc_energy_atom_regression)
        plt.title(f'Predicted {reference_xc}-based atomwise xc energy')
        plt.xlabel('Molecule index')
        plt.ylabel('xc energy [Ha]')
        plt.show()
    return plt.gcf()


def charges_to_colors(nuc_charges):
    """
    Convert nuclear charges to colors.
    """
    colors = []
    for charge in nuc_charges:
        if charge == 6:    # Carbon
            colors.append('k')
        elif charge == 7:  # Nitrogen
            colors.append('b')
        elif charge == 8:  # Oxygen
            colors.append('r')
        elif charge == 9:  # Fluorine
            colors.append('g')
        else:
            colors.append('grey')
    return colors


def plot_density(density: np.ndarray,
                 cutoff: float,
                 marker_pos: Optional[np.ndarray] = None,
                 mol_params: Optional[MoleculeParams] = None,
                 grid_spacing: Optional[float] = None,
                 max_density: Optional[float] = None) -> plt.Figure:
    limits = np.array([[-cutoff, cutoff],
                       [-cutoff, cutoff],
                       [-cutoff, cutoff]])

    Nx, Ny, Nz = density.shape

    xtick_positions = np.linspace(0, Nx - 1, 11)
    xtick_labels    = np.linspace(limits[0, 0], limits[0, 1], 11)
    ytick_positions = np.linspace(0, Ny - 1, 11)
    ytick_labels    = np.linspace(limits[1, 0], limits[1, 1], 11)
    ztick_positions = np.linspace(0, Nz - 1, 11)
    ztick_labels    = np.linspace(limits[2, 0], limits[2, 1], 11)

    if mol_params is not None or marker_pos is not None:
        plot_markers = True
        assert grid_spacing is not None
        origin = np.array([Nx//2, Ny//2, Nz//2])

        if mol_params is not None:
            marker_pos = mol_params.atom_positions * (1 / grid_spacing) + origin
            nuc_charges = mol_params.nuclear_charges
            colors = charges_to_colors(nuc_charges)
        elif marker_pos is not None:
            assert grid_spacing is not None
            marker_pos = marker_pos * (1 / grid_spacing) + origin
            colors = None
    else:
        plot_markers = False

    # Create subplots with a larger figure size
    plt.figure(figsize=(16, 4))

    # Plot the first subplot
    plt.subplot(1, 3, 1)
    if plot_markers:
        plt.scatter(marker_pos[:, 0], marker_pos[:, 1], c=colors)
    im1 = plt.imshow(density[:, :, Nz // 2].T, norm="log",
                         vmin=1e-6, vmax=max_density, origin='lower')
    plt.colorbar(im1)
    if mol_params is not None:
        plt.title(f'Mol {mol_params.id}: Density in z=0 Plane')

    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ytick_positions, ytick_labels)
    plt.ylabel('y / Angstrom')

    # Plot the second subplot
    plt.subplot(1, 3, 2)
    if plot_markers:
        plt.scatter(marker_pos[:, 0], marker_pos[:, 2], c=colors)
    im2 = plt.imshow(density[:, Ny // 2, :].T, norm="log",
                         vmin=1e-6, vmax=max_density, origin='lower')
    plt.colorbar(im2)
    if mol_params is not None:
        plt.title(f'Mol {mol_params.id}: Density in y=0 Plane')

    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    # Plot the third subplot
    plt.subplot(1, 3, 3)
    if plot_markers:
        plt.scatter(marker_pos[:, 1], marker_pos[:, 2], c=colors)
    im3 = plt.imshow(density[Nx // 2, :, :].T, norm="log",
                         vmin=1e-6, vmax=max_density, origin='lower')
    plt.colorbar(im3)
    if mol_params is not None:
        plt.title(f'Mol {mol_params.id}: Density in x=0 Plane')

    # Set custom ticks and labels for x-axis
    plt.xticks(ytick_positions, ytick_labels)
    plt.xlabel('y / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    return plt.gcf()


def plot_density_comparison(predicted_density: np.ndarray,
                           target_density: np.ndarray,
                           mol_params: MoleculeParams,
                           cutoff: float,
                           grid_spacing: float) -> plt.Figure:
    """
    Plot the density matrix of a molecule.
    """
    limits = np.array([[-cutoff, cutoff],
                       [-cutoff, cutoff],
                       [-cutoff, cutoff]])

    Nx, Ny, Nz = predicted_density.shape

    xtick_positions = np.linspace(0, Nx - 1, 11)
    xtick_labels    = np.linspace(limits[0, 0], limits[0, 1], 11)
    ytick_positions = np.linspace(0, Ny - 1, 11)
    ytick_labels    = np.linspace(limits[1, 0], limits[1, 1], 11)
    ztick_positions = np.linspace(0, Nz - 1, 11)
    ztick_labels    = np.linspace(limits[2, 0], limits[2, 1], 11)

    # Create subplots with a larger figure size
    plt.figure(figsize=(14, 12))

    # Plot the first subplot
    plt.subplot(3, 3, 1)
    im1 = plt.imshow(predicted_density[:, :, Nz // 2].T, norm="log",
                         vmin=1e-6, origin='lower')
    plt.colorbar(im1)
    plt.title('Predicted Density in z=0 Plane')

    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ytick_positions, ytick_labels)
    plt.ylabel('y / Angstrom')

    # Plot the second subplot
    plt.subplot(3, 3, 2)
    im2 = plt.imshow(predicted_density[:, Ny // 2, :].T, norm="log",
                         vmin=1e-6, origin='lower')
    plt.colorbar(im2)
    plt.title('Predicted Density in y=0 Plane')

    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    # Plot the third subplot
    plt.subplot(3, 3, 3)
    im3 = plt.imshow(predicted_density[Nx // 2, :, :].T, norm="log",
                         vmin=1e-6, origin='lower')
    plt.colorbar(im3)
    plt.title('Predicted Density in x=0 Plane')

    # Set custom ticks and labels for x-axis
    plt.xticks(ytick_positions, ytick_labels)
    plt.xlabel('y / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    # Plot target densities
    origin = np.array([Nx//2, Ny//2, Nz//2])
    nuc = mol_params.atom_positions * (1 / grid_spacing) + origin
    nuc_charges = mol_params.nuclear_charges
    colors = charges_to_colors(nuc_charges)

    plt.subplot(3, 3, 4)
    im4 = plt.imshow(target_density[:, :, Nz//2].T, norm="log",
                vmin=1e-6, origin='lower')
    plt.colorbar(im4)
    plt.title(f'Target Density of Molecule {mol_params.id}')
    # add nuclei
    plt.scatter(nuc[:,0], nuc[:,1],
                s=nuc_charges * 10, c=colors, alpha=0.7)
    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ytick_positions, ytick_labels)
    plt.ylabel('y / Angstrom')

    plt.subplot(3, 3, 5)
    im5 = plt.imshow(target_density[:, Ny//2, :].T, norm="log",
                vmin=1e-6, origin='lower')
    plt.colorbar(im5)
    plt.title(f'Target Density of Molecule {mol_params.id}')
    # add nuclei
    plt.scatter(nuc[:,0], nuc[:,2],
                s=nuc_charges * 10, c=colors, alpha=0.7)
    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    plt.subplot(3, 3, 6)
    im6 = plt.imshow(target_density[Nx//2, :, :].T, norm="log",
                vmin=1e-6, origin='lower')
    plt.colorbar(im6)
    plt.title(f'Target Density of Molecule {mol_params.id}')
    # add nuclei
    plt.scatter(nuc[:,1], nuc[:,2],
                s=nuc_charges * 10, c=colors, alpha=0.7)
    # Set custom ticks and labels for x-axis
    plt.xticks(ytick_positions, ytick_labels)
    plt.xlabel('y / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    # plot density error
    plt.subplot(3, 3, 7)
    im7 = plt.imshow(np.abs(predicted_density[:, :, Nz//2] - target_density[:, :, Nz//2]).T,
                norm="log", vmin=1e-6, origin='lower')
    plt.colorbar(im7)
    plt.title(f'Density Error of Molecule {mol_params.id}')
    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ytick_positions, ytick_labels)
    plt.ylabel('y / Angstrom')

    plt.subplot(3, 3, 8)
    im8 = plt.imshow(np.abs(predicted_density[:, Ny//2, :] - target_density[:, Ny//2, :]).T,
               norm="log", vmin=1e-6, origin='lower')
    plt.colorbar(im8)
    plt.title(f'Density Error of Molecule {mol_params.id}')
    # Set custom ticks and labels for x-axis
    plt.xticks(xtick_positions, xtick_labels)
    plt.xlabel('x / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    plt.subplot(3, 3, 9)
    im9 = plt.imshow(np.abs(predicted_density[Nx//2, :, :] - target_density[Nx//2, :, :]).T,
               norm="log", vmin=1e-6, origin='lower')
    plt.colorbar(im9)
    plt.title(f'Density Error of Molecule {mol_params.id}')
    # Set custom ticks and labels for x-axis
    plt.xticks(ytick_positions, ytick_labels)
    plt.xlabel('y / Angstrom')
    # Set custom ticks and labels for y-axis
    plt.yticks(ztick_positions, ztick_labels)
    plt.ylabel('z / Angstrom')

    plt.tight_layout()
    return plt.gcf()