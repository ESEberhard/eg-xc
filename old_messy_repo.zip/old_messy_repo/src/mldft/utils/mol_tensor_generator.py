import os
from pyscf import gto, df
import numpy as np
from scipy import linalg
from tqdm import tqdm

from typing import Optional


def generate_eri_mol_str(path: str, mol_str: str, basis: str) -> None:
    mol = gto.M(atom=mol_str, basis=basis)
    eri = mol.intor("int2e")
    np.save(path, eri)


def fast_df_pyscf(mol, auxmol, lib):

    nao = mol.nao
    naux = auxmol.nao

    # ints_3c is the 3-center integral tensor (ij|P), where i and j are the
    # indices of AO basis and P is the auxiliary basis
    ints_3c2e = df.incore.aux_e2(mol, auxmol, intor="int3c2e").reshape(nao * nao, naux)
    ints_2c2e = auxmol.intor("int2c2e")

    # Compute the DF coefficients (df_coef) and the DF 2-electron (df_eri)
    if lib == 'torch':
        import torch
        ints_2c2e = torch.from_numpy(ints_2c2e)
        ints_3c2e = torch.from_numpy(ints_3c2e)
        ints_2c2e_sqrt = torch.linalg.cholesky(ints_2c2e, upper=True, out=ints_2c2e)
        return (
            # (P|Q)^{-1/2} (ij|P)
            torch.linalg.solve_triangular(ints_2c2e_sqrt, ints_3c2e, upper=True, left=False, out=ints_3c2e)
            .T.reshape(naux, nao, nao)
            .numpy()
        )
    elif lib == 'scipy':
        import scipy
        cho = scipy.linalg.cholesky(ints_2c2e, overwrite_a=True)
        return scipy.linalg.solve_triangular(cho.T, ints_3c2e.T, overwrite_b=True, lower=True).reshape(naux, nao, nao)
    elif lib == 'jax':
        # will be done on the main process
        return ints_3c2e.reshape(nao, nao, naux), ints_2c2e
    else:
        raise ValueError(f"Unknown lib: {lib}")


def fast_df(mol_str: str, basis: str):
    import torch

    mol = gto.M(atom=mol_str, basis=basis)
    auxmol = df.addons.make_auxmol(mol, "weigend")

    nao = mol.nao
    naux = auxmol.nao

    # ints_3c is the 3-center integral tensor (ij|P), where i and j are the
    # indices of AO basis and P is the auxiliary basis
    ints_3c2e = df.incore.aux_e2(mol, auxmol, intor="int3c2e").reshape(nao * nao, naux)
    ints_2c2e = auxmol.intor("int2c2e")

    # Compute the DF coefficients (df_coef) and the DF 2-electron (df_eri)
    ints_2c2e = torch.from_numpy(ints_2c2e)
    ints_3c2e = torch.from_numpy(ints_3c2e)
    ints_2c2e_sqrt = torch.linalg.cholesky(ints_2c2e, upper=True, out=ints_2c2e)
    return (
        # (P|Q)^{-1/2} (ij|P)
        torch.linalg.solve_triangular(ints_2c2e_sqrt, ints_3c2e, upper=True, left=False, out=ints_3c2e)
        .T.reshape(naux, nao, nao)
        .numpy()
    )


def fast_df_scipy(mol_str: str, basis: str):
    import scipy
    mol = gto.M(atom=mol_str, basis=basis)
    auxmol = df.addons.make_auxmol(mol, "weigend")
    nao = mol.nao
    naux = auxmol.nao
    ints_3c2e = df.incore.aux_e2(mol, auxmol, intor="int3c2e").reshape(nao * nao, naux)
    ints_2c2e = auxmol.intor("int2c2e")
    cho = scipy.linalg.cholesky(ints_2c2e, overwrite_a=True)
    return scipy.linalg.solve_triangular(cho.T, ints_3c2e.T, overwrite_b=True, lower=True).reshape(naux, nao, nao)


def slow_df(mol_str: str, basis: str):
    mol = gto.M(atom=mol_str, basis=basis)
    auxmol = df.addons.make_auxmol(mol, "weigend")

    # ints_3c is the 3-center integral tensor (ij|P), where i and j are the
    # indices of AO basis and P is the auxiliary basis
    ints_3c2e = df.incore.aux_e2(mol, auxmol, intor="int3c2e")
    ints_2c2e = auxmol.intor("int2c2e")

    nao = mol.nao
    naux = auxmol.nao

    # Compute the DF coefficients (df_coef) and the DF 2-electron (df_eri)
    df_coef = linalg.solve(ints_2c2e, ints_3c2e.reshape(nao * nao, naux).T)
    df_coef = df_coef.reshape(naux, nao, nao)

    T = linalg.cholesky(ints_2c2e)
    return np.einsum("Pij,QP->Qij", df_coef, T)


def generate_df_mol_str(path: str, mol_str: str, basis: str, idx: int) -> None:
    mol = gto.M(atom=mol_str, basis=basis)
    auxmol = df.addons.make_auxmol(mol, "weigend")

    # ints_3c is the 3-center integral tensor (ij|P), where i and j are the
    # indices of AO basis and P is the auxiliary basis
    ints_3c2e = df.incore.aux_e2(mol, auxmol, intor="int3c2e")
    ints_2c2e = auxmol.intor("int2c2e")

    nao = mol.nao
    naux = auxmol.nao

    # Compute the DF coefficients (df_coef) and the DF 2-electron (df_eri)
    df_coef = linalg.solve(ints_2c2e, ints_3c2e.reshape(nao * nao, naux).T)
    df_coef = df_coef.reshape(naux, nao, nao)

    T = linalg.cholesky(ints_2c2e)
    df_tensor = np.einsum("Pij,QP->Qij", df_coef, T)

    np.save(path, df_tensor)


def generate_data_set_tensors(
    key: str,
    out_dir: str,
    dataset,
    sub_dir_size: int,
    basis: str,
    start_id: int = 0,
    end_id: Optional[int] = None,
) -> None:
    if end_id is None:
        end_id = len(dataset)
    for i in tqdm(range(start_id, end_id)):
        mol_str = dataset.get_molecule_string(i)
        n_dir = str(sub_dir_size * (i // sub_dir_size))

        if key == "eri":
            path_str = os.path.join(out_dir, n_dir, f"mol_{i}.npy")
            os.makedirs(os.path.join(out_dir, n_dir), exist_ok=True, mode=0o777)
            generate_eri_mol_str(path_str, mol_str, basis)
        elif key == "density_fitting":
            path_str = os.path.join(out_dir, n_dir, f"mol_{i}_df_tensor.npy")
            os.makedirs(path_str, exist_ok=True, mode=0o777)
            generate_df_mol_str(path_str, mol_str, basis, i)
        else:
            raise ValueError(f"Unknown key: {key}")
