import jax
import numpy as onp
from flax import struct
from flax.struct import dataclass

from optax import OptState
from typing import Tuple, Dict, Any, Callable, Optional
from pyscf.gto import Mole

PRNGKey = jax.Array

NnParams = Dict[str, Any]
Labels = Dict[str, Any]
AoValues = jax.Array
DensityMatrix = jax.Array
HostAoValues = onp.ndarray


class HostFockTensors(struct.PyTreeNode):
    """
    Fock tensors for the molecule.
        overlap:            shape (n_basis_functions, n_basis_functions)
        h_core:             shape (n_basis_functions, n_basis_functions)
        elect_rep_integrals: shape (n_basis_functions, n_basis_functions, n_basis_functions, n_basis_functions)
    """

    overlap: onp.ndarray
    h_core: onp.ndarray
    elect_rep_integrals: Optional[onp.ndarray]
    df_tensor: Optional[jax.Array]


# @host_dataclass
# class HFExchangeDensityTensors:
#     """
#     Tensors needed for the calcuation of local Hartree-Fock features as proposed by
#     Kirkpatrick et al. “Pushing the Frontiers of Density Functionals by Solving
#     the Fractional Electron Problem.”
#     Science 374, no. 6573 (December 10, 2021): 1385–89.
#     https://doi.org/10.1126/science.abj6511.
#     """


class HostMoleculeSolverParams(struct.PyTreeNode):
    """
    Molecule dependent parameters for the self-consistent field calculation.
        id:                 scalar
        atom_positions:     shape (n_atoms, 3)
        n_electrons:        scalar
        e_nuclei:           scalar
        occupancy:          shape (n_basis_functions)
        initial_density_matrix: shape (n_basis_functions, n_basis_functions)
        molecule_ao_values: shape (1, n_grid_points, n_basis_functions)
        atom_ao_values:     shape (n_atoms, n_resolutions, n_grid_points, n_basis_functions)
        tensors:            HostFockTensors
        atom_base_xc:       scalar
    """

    id: int
    atom_positions: onp.ndarray
    n_electrons: int
    e_nuclei: float
    occupancy: onp.ndarray
    nuclear_charges: onp.ndarray
    periods: tuple[int, ...] = struct.field(pytree_node=False)
    initial_density_matrix: onp.ndarray
    molecule_ao_values: AoValues
    atom_ao_values: AoValues
    tensors: HostFockTensors
    atom_base_xc: Optional[float]
    quadrature_points: Optional[onp.ndarray]
    quadrature_ao_values: Optional[onp.ndarray]
    quadrature_weights: Optional[onp.ndarray]
    molecule: Optional[Mole]
    masks: tuple


@dataclass
class FockTensors:
    """
    Fock tensors for the molecule.
        overlap:            shape (n_basis_functions, n_basis_functions)
        h_core:             shape (n_basis_functions, n_basis_functions)
        molecule_id:        scalar
        elect_rep_integrals: shape (n_basis_functions, n_basis_functions, n_basis_functions, n_basis_functions)
    """

    overlap: jax.Array
    h_core: jax.Array
    molecule_id: Optional[int]
    elect_rep_integrals: Optional[jax.Array]
    df_tensor: Optional[jax.Array]


class MoleculeSolverParams(struct.PyTreeNode):
    """
    Molecule dependent parameters for the self-consistent field calculation.
        id:                 scalar
        atom_positions:     shape (n_atoms, 3)
        atom_mask:          shape (maximum number of atoms in dataset)
        n_electrons:        scalar
        e_nuclei:           scalar
        occupancy:          shape (n_basis_functions)
        initial_density_matrix: shape (n_basis_functions, n_basis_functions)
        molecule_ao_values: shape (1, n_grid_points, n_basis_functions)
        atom_ao_values:     shape (n_atoms, n_resolutions, 1 or 4 depending on
                whether grad is required, n_grid_points, n_basis_functions)
        tensors:            FockTensors
        atom_base_xc:       scalar
    """

    id: int
    nuclear_positions: jax.Array
    atom_mask: jax.Array
    n_electrons: int
    e_nuclei: jax.Array  # scalar array
    occupancy: jax.Array
    nuclear_charges: jax.Array
    initial_density_matrix: jax.Array
    molecule_ao_values: AoValues
    atom_ao_values: AoValues
    tensors: FockTensors
    atom_base_xc: Optional[jax.Array]  # scalar array
    quadrature_points: Optional[jax.Array]
    quadrature_ao_values: Optional[jax.Array]
    quadrature_weights: Optional[jax.Array]
    ao_mask: Optional[jax.Array]

    def __str__(self):
        out = f"id: \t {self.id}\n"
        out += f"energy of nuclei: {self.e_nuclei}\n"
        atoms_str = onp.hstack(
            [
                self.nuclear_charges[self.atom_mask, None],
                self.nuclear_positions[self.atom_mask],
            ]
        )
        atoms_str = onp.array2string(atoms_str, precision=2, floatmode="fixed")
        out += f"atoms: \n {atoms_str}\n"
        out += f"atom_ao_values (shape): {self.atom_ao_values.shape}\n"
        out += f"initial_density_matrix (shape): {self.initial_density_matrix.shape}\n"
        out += f"charges (elec | nucl): ( -{self.n_electrons} | {self.nuclear_charges[self.atom_mask].sum()})\n"
        return out


XcEnergyFn = Callable[[NnParams, DensityMatrix, MoleculeSolverParams], jax.Array]


@dataclass
class MoleculeParams:
    """
    General Molecule Params
    """

    id: int
    atom_positions: onp.ndarray
    n_basis_functions: int
    n_electrons: int
    nuclear_charges: onp.ndarray
    dataset: str


@dataclass
class Energies:
    """
    A dataclass to store the energies of the SCF calculation.
    """

    nuclei: jax.Array
    core: jax.Array
    ee_rep: jax.Array
    xc: jax.Array

    @property
    def total(self) -> jax.Array:
        return self.nuclei + self.core + self.ee_rep + self.xc


@dataclass
class SolverOutput:
    """
    A dataclass to store the output of the solver function.
    energies: jax.Array (shape: (n_steps))
    density_matrices: jax.Array (shape: (n_steps, n_electrons, n_electrons))
    xc_energies: jax.Array (shape: (n_steps))
    delta_e_j: scalar
    """

    last_n_energies: jax.Array
    last_n_density_matrices: jax.Array
    last_energies: Energies


SolverFn = Callable[[NnParams, MoleculeParams], SolverOutput]


class LossAuxiliaryOutput(struct.PyTreeNode):
    """
    A dataclass to store the output of the loss function.
    """

    energy_loss: jax.Array
    density_loss: jax.Array
    pred_energies: Energies
    density_matrix: jax.Array
    predicted_density: jax.Array
    energy_volatility: jax.Array
    update_norm: jax.Array | None = None
    grad_norm: jax.Array | None = None

    @property
    def loss(self) -> jax.Array:
        return self.energy_loss + self.density_loss


TargetEnergy = float
TargetDensity = jax.Array

LossFn = Callable[
    [NnParams, TargetEnergy, TargetDensity, MoleculeSolverParams],
    Tuple[jax.Array, LossAuxiliaryOutput],
]
StepFn = Callable[
    [NnParams, OptState, TargetEnergy, TargetDensity, MoleculeSolverParams],
    Tuple[NnParams, OptState, LossAuxiliaryOutput],
]
