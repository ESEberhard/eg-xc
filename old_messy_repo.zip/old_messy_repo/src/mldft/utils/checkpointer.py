import os
import orbax.checkpoint as ocp
from datetime import datetime
import randomname

from typing import Dict, Any


class Checkpointer:
    def __init__(self, log_params: Dict[str, Any], name=None, pretrain=False) -> None:
        if name is None:
            name = randomname.get_name(sep="_")
            name = name + "_" + datetime.now().strftime("%Y_%m_%d")
            if pretrain:
                name = name + "_pretrain"

        ckpt_dir = os.path.join(log_params["checkpoint_dir"], name)
        ckpt_dir = os.path.abspath(ckpt_dir)

        val_options = ocp.CheckpointManagerOptions(
            save_interval_steps=1,
            best_fn=lambda ckpt: ckpt["val_loss"],
            best_mode="min",
            max_to_keep=3,
        )

        item_names = ("params", "optimizer_state")

        ckpt_mngr = ocp.CheckpointManager(
            ckpt_dir, item_names=item_names, options=val_options
        )
        self.mngr = ckpt_mngr

    def save(self, params, optimizer_state, epoch, loss) -> None:
        if loss is not None:
            args = ocp.args.Composite(
                params=ocp.args.StandardSave(params),
                optimizer_state=ocp.args.StandardSave(optimizer_state),
            )
            self.mngr.save(epoch, args=args, metrics={"val_loss": float(loss)})

    def load_best(self) -> Dict[str, Any]:
        best_step = self.mngr.best_step()

        if best_step is None:
            raise ValueError("No 'best' checkpoint available to restore.")

        restore_args = ocp.args.Composite(
            params=ocp.args.StandardRestore(),
            optimizer_state=ocp.args.StandardRestore(),
        )

        restored = self.mngr.restore(best_step, args=restore_args)
        params = restored["params"]

        return params
