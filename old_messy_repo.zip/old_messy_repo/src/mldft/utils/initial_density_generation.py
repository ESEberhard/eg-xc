import os
from pyscf import gto, dft
import numpy as np
from tqdm import tqdm

from typing import Dict, Any, Optional


def compute_initial_density_of_molecule(
    molecule: str, basis: str, precycles: int, xc: str
) -> np.ndarray:
    mol = gto.M(atom=molecule, basis=basis)
    print("basis", basis)
    print("precycles", precycles)
    print("xc", xc)
    mean_field = dft.RKS(mol, xc=xc)
    mean_field.max_cycle = precycles
    mean_field.run()
    P = mean_field.make_rdm1()
    return P


def save_initial_density_of_molecule(path: str, compute_params: Dict[str, Any]) -> None:
    P = compute_initial_density_of_molecule(**compute_params)
    np.save(path, P)


def compute_initial_densities_for_data_set(
    out_dir: str,
    dataset,
    dataparams: Dict[str, Any],
    hparams: Dict[str, Any],
    start_id: int = 0,
    end_id: Optional[int] = None,
    offset: int = 0,
) -> None:
    if not hparams["restricted"]:
        raise ValueError(
            "In spin unrestricted case, \
                         occupancy must be specified"
        )

    sub_dir_size = dataparams["initial_density"]["sub_dir_size"]

    if end_id is None:
        end_id = len(dataset)
    for i in tqdm(range(start_id, end_id)):
        if isinstance(dataset, list):
            mol_str = dataset[i]
        else:
            mol_str = dataset.get_molecule_string(i)

        if sub_dir_size is None:
            path_str = os.path.join(out_dir, f"mol_{offset + i}.npy")
            os.makedirs(out_dir, exist_ok=True, mode=0o777)
        else:
            n_dir = str(sub_dir_size * (i // sub_dir_size))
            path_str = os.path.join(out_dir, n_dir, f"mol_{offset + i}.npy")
            os.makedirs(os.path.join(out_dir, n_dir), exist_ok=True, mode=0o777)

        save_initial_density_of_molecule(
            path_str,
            {
                "molecule": mol_str,
                "basis": hparams["basis"],
                "precycles": dataparams["initial_density"]["precycles"],
                "xc": dataparams["initial_density"]["xc"],
            },
        )
