import jax
import time
import jax.numpy as jnp
import numpy as np
import matplotlib.pyplot as plt
from functools import wraps

from typing import Any, Callable, Dict
from dataclasses import fields


@jax.jit
def test_nan(tree):
    return jax.tree_util.tree_reduce(
        jnp.logical_or,
        jax.tree_util.tree_map(
            lambda x: jnp.isnan(x).any(),
            tree
        )
    )

def try_to_numpy(array):
    try:
        if isinstance(array, jax.Array):
            return np.asarray(array)
        else:
            return array
    except RuntimeError:
        return "deleted"

def add_nan_catch(fun: Callable, extras: Any = None) -> Callable:
    """Kindly provided by N. Gao"""
    @wraps(fun)
    def wrapped(*args, **kwargs):
        result = fun(*args, **kwargs)
        is_nan = test_nan(result).item()
        if is_nan:
            import pickle
            with open("dump.pickle", "wb") as f:
                to_log = jax.tree_util.tree_map(
                    try_to_numpy,
                    {
                        'args': args,
                        'kwargs': kwargs,
                        'result': result,
                        'extras': extras
                    }
                )
                pickle.dump(to_log, f)
            raise ValueError("NaN encountered, input and output has been dumped to 'dump.pickle'.")
        return result
    return wrapped


def save_io(fun: Callable, extras: Any = None) -> Callable:
    """saves input and output of a function to a pickle file"""
    @wraps(fun)
    def wrapped(*args, **kwargs):
        result = fun(*args, **kwargs)
        print("Logging input and output to pickle file.")
        import pickle
        import time
        stamp = time.time()
        with open(f"logs/debug/dump_{stamp}.pickle", "wb") as f:
            to_log = jax.tree_util.tree_map(
                try_to_numpy,
                {
                    'args': args,
                    'kwargs': kwargs,
                    'result': result,
                    'extras': extras
                }
            )
            pickle.dump(to_log, f)
        return result
    return wrapped


def time_this(fun: Callable) -> Callable:
    @wraps(fun)
    def wrapped(*args, **kwargs):
        start = time.time()
        result = fun(*args, **kwargs)
        end = time.time()
        print(f"Function {fun.__name__} took {end - start:.2f} seconds.", flush=True)
        return result
    return wrapped


def test_dtype(arg, name=""):
    if isinstance(arg, jax.Array) or isinstance(arg, np.ndarray):
        print(f"Array with dtype {arg.dtype} (name: {name})")
    elif isinstance(arg, tuple):
        print(f"# Tuple with {len(arg)} elements:")
        for elem in arg:
            test_dtype(elem)
        print("# End of tuple.")
    elif isinstance(arg, dict):
        print(f"# Dict with {len(arg)} elements:")
        for key, value in arg.items():
            test_dtype(value, key)
        print("# End of dict.")
    else:
        try:
            print(f"# Dataclass with {len(fields(arg))} fields.")
            for field in fields(arg):
                test_dtype(getattr(arg, field.name), field.name)
            print("# End of dataclass.")
        except:
            print(f"{name} has type {type(arg)}.")


def check_types(fun: Callable) -> Callable:
    @wraps(fun)
    def wrapped(*args, **kwargs):
        print("## Input type check:")
        for arg in args:
            test_dtype(arg)
        for kwarg in kwargs.values():
            test_dtype(kwarg)
        print("## Output type check:")
        out = fun(*args, **kwargs)
        test_dtype(out)
        return out
    return wrapped


def plot_tree(tree: Dict[str, Any]):
    """
    Plot distribution of all arrays in a tree.
    Useful for debugging neural network activations.
    """
    leafs = []
    def get_leafs(tree, title=""):
        for key in tree.keys():
            if type(tree[key]) == dict:
                get_leafs(tree[key], f"{title} {key}")
            else:
                leaf = np.array(tree[key][0].flatten())
                leafs.append((title, leaf))
    get_leafs(tree)
    plt.figure(figsize=(70, 40))
    for i, (title, leaf) in enumerate(leafs):
        plt.subplot(10, 10, i+1)
        plt.hist(leaf, bins=50)
        plt.title(f"{title}: {len(leaf)}")
        plt.yscale("log")
    plt.show()