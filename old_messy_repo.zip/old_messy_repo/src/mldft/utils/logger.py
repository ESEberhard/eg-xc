import atexit
import datetime
import aim
import numpy as onp
import matplotlib.pyplot as plt
import jax
import jax.numpy as jnp
import os

from mldft.grids import Grid
from mldft.nn.embedding.feature_mask import RadialMask
from mldft.nn.embedding.radial_conv import get_base_kernels
from mldft.utils import plotter

from mldft.utils.typing import LossAuxiliaryOutput, MoleculeParams, NnParams, Energies
from typing import Dict, Optional
from optax import OptState


class Logger:
    def __init__(
        self, log_params: Dict[str, str], hyperparameters: Dict[str, float]
    ) -> None:
        self.run = aim.Run(
            experiment=hyperparameters.get(
                "db_collection", log_params["experiment_name"]
            ),
            repo=log_params["aim_repo"],
        )
        atexit.register(lambda: self.run.close())
        self.run.name = log_params["name"]
        self.context = {log_params["model_name"]: log_params["run_purpose"]}
        self.complete_log_every = log_params["complete_log_every"]
        self.hparams = hyperparameters
        self.run["hyperparameters"] = self.hparams
        self.run["environ"] = dict(os.environ)

        self.epoch = 0
        self.recent_val_loss = None
        self.prefix = ""
        self.stats = {}

        self.mask_module = None
        self.last_masks = None
        self.csv = None

        from mldft.sacred_config import ex

        log_dir = log_params["dir"]
        if os.path.exists(log_dir):
            log_dir += str(datetime.datetime.now()).replace(' ', '_')
        ex.info["log_dir"] = log_dir
        self.run["log_dir"] = log_dir

        os.makedirs(log_dir, exist_ok=False)
        self.init_csv(os.path.join(log_dir, "results.csv"))

        # if self.hparams["model"]["use_schnet"] or self.hparams["model"]["use_painn"]:
        #     self.log_base_kernels()

    def __del__(self):
        if self.csv is not None:
            self.csv.flush()
            self.csv.close()

    def log_config_params(self, name: str, params: Dict[str, float]) -> None:
        self.run[name] = params

    def log_parameter_shapes(self, params: Dict[str, jax.Array]) -> None:
        self.run["model_parameters_shape"] = jax.tree_map(lambda x: x.shape, params)

    def log_epoch_mean(self) -> None:
        log_scalars = {}
        for key in self.stats.keys():
            mean = onp.mean(onp.abs(self.stats[key]))
            log_scalars[f"epoch mean absolute {key}"] = mean
            if "val loss" in key:
                self.recent_val_loss = mean
        self.log_scalars(log_scalars, step=self.epoch, epoch=self.epoch)
        self.stats = {}
        return log_scalars

    def start_epoch_mean(self, prefix: str, epoch: int) -> None:
        self.epoch = epoch
        self.prefix = prefix
        self.stats[f"{prefix} loss"] = []
        self.stats[f"{prefix} energy loss"] = []
        self.stats[f"{prefix} density loss"] = []
        self.stats[f"{prefix} energy difference [Ha]"] = []

    def init_csv(self, path: str) -> None:
        line = []
        line.append("dataset")
        line.append("id")
        line.append("split")
        line.append("nuclear charges")
        line.append("target energy [Ha]")
        line.append("predicted energy [Ha]")
        line.append("core energy [Ha]")
        line.append("ee repulsion energy [Ha]")
        line.append("xc energy [Ha]")
        self.csv = open(path, "w")
        self.csv.write("\t".join(line) + "\n")

    def write_to_csv(
        self,
        prefix: str,
        target_energy: float,
        mol_params: MoleculeParams,
        E: Energies,
    ) -> None:
        line = []
        line.append(mol_params.dataset)
        line.append(mol_params.id)
        line.append(prefix)
        line.append(str(mol_params.nuclear_charges))
        line.append(target_energy)
        line.append(E.total)
        line.append(E.core)
        line.append(E.ee_rep)
        line.append(E.xc)
        self.csv.write("\t".join(map(str, line)) + "\n")
        # self.csv.flush()

    def log_step(
        self,
        prefix: str,
        params: NnParams,
        target_energy: float,
        target_density: Optional[jax.Array],
        molecule_params: MoleculeParams,
        molecule_grid: Grid,
        loss_auxiliary_output: LossAuxiliaryOutput,
        opt_state: OptState,
        step: int,
        epoch: int,
    ) -> None:
        energy_difference = loss_auxiliary_output.pred_energies.total.astype(
            "float64"
        ) - target_energy.astype("float64")

        self.stats[f"{prefix} loss"].append(loss_auxiliary_output.loss)
        self.stats[f"{prefix} energy loss"].append(loss_auxiliary_output.energy_loss)
        self.stats[f"{prefix} density loss"].append(loss_auxiliary_output.density_loss)
        self.stats[f"{prefix} energy difference [Ha]"].append(energy_difference)

        log_scalars = {
            f"{prefix} loss": loss_auxiliary_output.loss,
            # f'{prefix} loss: molecule {molecule_params.id}': loss_auxiliary_output.loss,
            # f'{prefix} energy loss': loss_auxiliary_output.energy_loss,
            # f'{prefix} density loss': loss_auxiliary_output.density_loss,
            # f'{prefix} target energy [Ha]':target_energy,
            # f'{prefix} predicted energy [Ha]': loss_auxiliary_output.pred_energy,
            f"{prefix} energy difference [Ha]": energy_difference,
            # f'{prefix} energy difference [Ha]: molecule {molecule_params.id}': loss_auxiliary_output.pred_energy - target_energy,
            f"{prefix} relative energy difference": energy_difference / target_energy,
            f"{prefix} xc energy [Ha]": loss_auxiliary_output.pred_energies.xc,
            # f'{prefix} delta electron repulsion energy [Ha]': loss_auxiliary_output.delta_e_j,
            # f'{prefix} number of basis functions': molecule_params.n_basis_functions,
            # f"{prefix} number of atoms": molecule_params.atom_positions.shape[0],
            f"{prefix} energy_volatility": loss_auxiliary_output.energy_volatility,
        }
        if loss_auxiliary_output.update_norm is not None:
            log_scalars[f"{prefix} update_norm"] = loss_auxiliary_output.update_norm
        if loss_auxiliary_output.grad_norm is not None:
            log_scalars[f"{prefix} grad_norm"] = loss_auxiliary_output.grad_norm

        if step % self.complete_log_every == 0:
            # if self.hparams["model"]["filter_features"]:
            #     self.log_feature_filters(params["params"]["RadialMask_0"], step, epoch)
            # try:
            #     self.log_density(   prefix,
            #                         loss_auxiliary_output.predicted_density,
            #                         target_density,
            #                         molecule_params,
            #                         molecule_grid,
            #                         step,
            #                         epoch)
            # except:
            #     print("Density logging failed, likely do to nan values in the density.")

            if "train" in prefix:
                try:
                    log_scalars[f"{prefix}reduce_on_plateau_factor"] = float(
                        opt_state.inner_state[1].scale
                    )
                except:
                    print("Could not log reduce_on_plateau_factor")

                # if not self.hparams["model"]["use_metaGGA"] and (
                #     self.hparams["model"]["use_schnet"]
                #     or self.hparams["model"]["use_painn"]
                # ):
                #     embedding_params = params["params"]["gnn"][
                #         "InvariantAtomEmbedding_0"
                #     ]
                #     self.log_kernels(embedding_params, step, epoch)

        self.log_scalars(log_scalars, step, epoch)

    def log_feature_filters(
        self, feature_filter_params: NnParams, step: int, epoch: int
    ) -> None:
        return
        if self.mask_module is None:
            n = int(
                self.hparams["density_grids"]["atom_max_cutoff"]
                / self.hparams["density_grids"]["atom_max_grid_spacing"]
                * 2
                + 1
            )
            r = self.hparams["density_grids"]["n_resolutions"]
            c = feature_filter_params["Dense_0"]["kernel"].shape[-1] // r
            input_shape = (1, r, n, n, n, c)
            mask_module = RadialMask(
                **self.hparams["model"]["RadialMask"], shape=input_shape
            )
            mask_module.init(jax.random.PRNGKey(0))
            self.mask_module = mask_module

        masks = self.mask_module.apply({"params": feature_filter_params})
        self.last_masks = masks
        r, n, _, _, c = masks.shape

        plt.figure(figsize=(7 * r, 5 * c))
        for res in range(r):
            for channel in range(c):
                plt.subplot(c, r, channel * (res + 1) + channel + 1)
                plt.imshow(masks[res, ..., n // 2, channel])
                plt.colorbar()
                plt.title(f"resolution: {res}, channel: {channel}")
                plt.xlabel("x")
                plt.ylabel("y")
        plt.tight_layout()
        self.run.track(
            aim.Image(plt.gcf()), name="feature_filter", step=step, epoch=epoch
        )
        plt.close()

    def log_scalars(self, scalars: Dict[str, float], step: int, epoch: int) -> None:
        self.run.track(scalars, context=self.context, step=step, epoch=epoch)

    def log_gnn_input(
        self, f_start: jax.Array, f_final: jax.Array, step: int, epoch: int
    ) -> None:
        return
        if self.last_masks is not None:
            f_start *= self.last_masks[None]
            f_final *= self.last_masks[None]
        atoms, res, n, _, _, channels = f_start.shape
        a = onp.random.randint(atoms)
        for label, f in [("initial", f_start), ("final", f_final)]:
            plt.figure(figsize=(7 * res, 5 * channels))
            for r in range(res):
                for c in range(channels):
                    plt.subplot(channels, res, c * res + r + 1)
                    plt.imshow(f[a, r, ..., n // 2, c])
                    plt.colorbar()
                    plt.title(f"[{label}] resolution: {r}, channel: {c}")
                    plt.xlabel("x")
                    plt.ylabel("y")
            plt.tight_layout()
            self.run.track(
                aim.Image(plt.gcf()), name=f"{label} gnn input", step=step, epoch=epoch
            )
            plt.close()

    def log_base_kernels(self):
        return
        kernel_size = self.hparams["model"]["Embedding"]["invariant"]["block_params"][
            "base"
        ]["kernel_size"]
        n_basis = self.hparams["model"]["Embedding"]["invariant"]["block_params"][
            "base"
        ]["n_base_kernels"]

        base_kernels = get_base_kernels(
            kernel_size,
            self.hparams["density_grids"]["atom_max_grid_spacing"],
            n_basis,
            dtype=self.hparams["precision"]["general"],
        )

        self.base_kernels = onp.array(base_kernels)

        plt.figure(figsize=(15, 4))
        for n in range(n_basis):
            plt.subplot(2, n_basis // 2, n + 1)
            plt.imshow(
                self.base_kernels[n][kernel_size // 2],
                origin="lower",
                vmin=0,
                vmax=1,
                cmap="binary",
            )
            plt.title(f"n {n}")
        plt.tight_layout()
        self.run.track(aim.Image(plt.gcf()), name="base_kernels", step=0, epoch=0)
        plt.close()

    def log_kernels(self, embedding_params: NnParams, step: int, epoch: int) -> None:
        return
        # TODO: why does this not work?
        n_resolutions = self.hparams["density_grids"]["n_resolutions"]
        kernel_size = self.hparams["model"]["Embedding"]["invariant"]["block_params"][
            "base"
        ]["kernel_size"]

        embedding_params = embedding_params["BaseAtomEmbedding_0"]

        coefficients = []
        for key in embedding_params.keys():
            if "EmbeddingBlock_" in key:
                coefficients.append(embedding_params[key]["RadConv_0"]["basis_coeff"])

        kernels = []
        for c in coefficients:
            kernel = jnp.einsum(
                "ruvl, lijk -> ruvijk",
                c,  # shape (n_resolutions, out_features, in_features, n_basis)
                self.base_kernels,
            )  # shape (n_resolutions, n_basis, kernel_size, kernel_size, kernel_size)
            kernels.append(kernel)
        # kernels: shape (layers, n_resolutions, out_features, in_features, kernel_size, kernel_size, kernel_size)

        # plot kernels
        n_layers = len(kernels)
        plt.figure(figsize=(30, 3 * n_layers))
        for l in range(n_layers):
            for r in range(n_resolutions):
                n_out_features = min(2, kernels[l].shape[1])
                n_in_features = min(2, kernels[l].shape[2])
                for out_f in range(n_out_features):
                    for in_f in range(n_in_features):
                        plt.subplot(
                            n_layers,
                            n_resolutions * n_out_features * n_in_features,
                            l * n_resolutions * n_out_features * n_in_features
                            + r * n_out_features * n_in_features
                            + out_f * n_in_features
                            + in_f
                            + 1,
                        )
                        plt.imshow(
                            kernels[l][r, out_f, in_f][kernel_size // 2],
                            origin="lower",
                            vmin=-0.05,
                            vmax=0.05,
                            cmap="coolwarm",
                        )
                        plt.title(f"l {l}, r {r}, out {out_f}, in {in_f}")
        plt.tight_layout()
        self.run.track(aim.Image(plt.gcf()), name="kernels", step=step, epoch=epoch)
        plt.close()

    def log_density(
        self,
        prefix: str,
        predicted_density: jax.Array,
        target_density: Optional[jax.Array],
        molecule_params: MoleculeParams,
        grid: Grid,
        step: int,
        epoch: int,
    ) -> None:
        """
        Logs the density to aim.
        """
        return

        if target_density is not None:
            target_density = target_density.squeeze()
            figure = plotter.plot_density_comparison(
                predicted_density,
                target_density,
                molecule_params,
                grid.cutoff,
                grid.grid_spacing,
            )
        else:
            figure = plotter.plot_density(
                predicted_density,
                grid.cutoff,
                mol_params=molecule_params,
                grid_spacing=grid.grid_spacing,
            )

        self.run.track(
            aim.Image(figure), name=f"{prefix} density", step=step, epoch=epoch
        )
        plt.close()

        self.run.track(
            {
                "total grid charge error": predicted_density.sum()
                * grid.grid_spacing**3
                - molecule_params.n_electrons
            },
            context=self.context,
            step=step,
            epoch=epoch,
        )
