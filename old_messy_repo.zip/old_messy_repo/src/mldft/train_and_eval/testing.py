import jax
import numpy as np
from tqdm import tqdm

from typing import Dict, Any, Callable
from torch.utils.data import DataLoader

from mldft.systems.molecule_params import preprocess_params
from mldft.utils.typing import NnParams, LossAuxiliaryOutput
from mldft.utils.logger import Logger
from mldft.grids.generation import Grid


def test(
    params: NnParams,
    train_data: DataLoader,
    val_data: DataLoader,
    test_data: DataLoader,
    hparams: Dict[str, Any],
    data_params: Dict[str, Any],
    loss_fn: Callable,
    molecule_grid: Grid,
    logger: Logger,
) -> None:
    print("############# Test #############")

    loss_fn = jax.jit(loss_fn)

    logger.start_epoch_mean("test", epoch=0)

    def val_step_fn(params, target_energy, target_density, msp):
        msp = preprocess_params(
            msp,
            hparams,
            data_params["max_number_of_atoms"],
            data_params["pad_quadrature_grid"],
        )
        _, auxiliary_data = loss_fn(params, target_energy, target_density, msp)
        return auxiliary_data

    if hparams.get("jit_step"):
        val_step_fn = jax.jit(val_step_fn)

    
    print("############# Eval final model on traing + val #############")

    for split, data in [("train", train_data), ("val", val_data)]:
        for sample in tqdm(data):
            (target_energy, target_density, mp, msp) = sample
            aux_data = val_step_fn(params, target_energy, target_density, msp)
            aux_data = jax.tree_util.tree_map(np.asarray, aux_data)

            logger.write_to_csv(split, target_energy, mp, aux_data.pred_energies)

            del target_energy, target_density, mp, msp, sample

    print("############# Eval final model on test #############")
    step = 0
    for sample in tqdm(test_data):
        (target_energy, target_density, mp, msp) = sample
        aux_data = val_step_fn(params, target_energy, target_density, msp)
        aux_data = jax.tree_util.tree_map(np.asarray, aux_data)
        aux_data: LossAuxiliaryOutput

        logger.log_step(
            "test",
            params,
            target_energy,
            target_density,
            mp,
            molecule_grid,
            aux_data,
            opt_state=None,
            step=step,
            epoch=0,
        )
        step += 1

        logger.write_to_csv("test", target_energy, mp, aux_data.pred_energies)

        print(
            "test energy difference [mEh]: ",
            abs(aux_data.pred_energies.total - target_energy) * 1e3,
            flush=True,
        )

        del target_energy, target_density, mp, msp, sample

    stats = logger.log_epoch_mean()

    print("------------------- Test Results --------------------")
    print(stats)
    print("-----------------------------------------------------")

