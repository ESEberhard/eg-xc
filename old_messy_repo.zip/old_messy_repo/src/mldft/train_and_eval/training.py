import jax
import jax.numpy as jnp
import jax.tree_util as jtu
import optax
import itertools
import numpy as np
from tqdm import tqdm

from mldft.train_and_eval import get_optimizer
from mldft import scf, xc_energy
from mldft.train_and_eval import loss
from mldft.nn import get_mgga_model

from typing import (
    Dict,
    Any,
    Callable,
    Generic,
    NamedTuple,
    Optional,
    Tuple,
    TypeVar,
    Union,
)
from optax import OptState
from torch.utils.data import DataLoader
from flax.struct import dataclass

from mldft.systems.molecule_params import preprocess_params
from mldft.utils.typing import (
    NnParams,
    LossAuxiliaryOutput,
    MoleculeSolverParams,
    LossFn,
    StepFn,
)
from mldft.utils.logger import Logger
from mldft.utils.checkpointer import Checkpointer
from mldft.grids.generation import Grid


EpochFn = Union[StepFn, LossFn]


@dataclass
class TrainLoopParams:
    epochs: int
    max_number_of_atoms: Optional[int]
    pad_quadrature_grid: bool
    val_step_size: int = (1,)
    patience: int = 10


def __gnn_io_log_callback(
    gnn_feature_fn: Callable,
    logger: Logger,
    density_matrix: jax.Array,
    msp: MoleculeSolverParams,
    step: int,
    epoch: int,
):
    initial_features = gnn_feature_fn(
        msp.initial_density_matrix,
        msp.atom_ao_values,
        msp.nuclear_positions,
        msp.nuclear_charges,
    )[msp.atom_mask]
    final_features = gnn_feature_fn(
        density_matrix, msp.atom_ao_values, msp.nuclear_positions, msp.nuclear_charges
    )[msp.atom_mask]
    logger.log_gnn_input(initial_features, final_features, step=step, epoch=epoch)


T = TypeVar("T")


class EMA(NamedTuple, Generic[T]):
    data: T
    weight: jax.Array


def ema_make(tree: T) -> EMA[T]:
    return EMA(jtu.tree_map(lambda x: jnp.zeros_like(x), tree), jnp.zeros(()))


@jax.jit
def ema_update(ema: EMA[T], value: T, decay) -> EMA[T]:
    return EMA(
        jtu.tree_map(lambda a, b: a * decay + b, ema.data, value),
        ema.weight * decay + 1,
    )


@jax.jit
def ema_value(ema: EMA[T], backup: T | None = None) -> T:
    if backup is None:
        backup = ema.data
    is_nan = ema.weight == 0
    return jtu.tree_map(
        lambda x, y: jnp.where(is_nan, y, x / ema.weight), ema.data, backup
    )


def __train_loop(
    prefix: str,
    params: NnParams,
    train_data: DataLoader,
    val_data: DataLoader,
    step_fn: StepFn,
    loss_fn: LossFn,
    loop_params: TrainLoopParams,
    hparams: Dict[str, Any],
    opt_state: OptState,
    logger: Logger,
    molecule_grid: Grid,
    checkpointer: Optional[Checkpointer],
    gnn_feature_fn: Optional[Callable],
    min_epochs: int = 10,
) -> NnParams:
    n_steps = len(train_data)

    step_fn = jax.jit(step_fn)
    loss_fn = jax.jit(loss_fn)

    key = jax.random.PRNGKey(42)

    @jax.jit
    def step_with_ema_update(
        params, opt_state, params_ema, target_energy, target_density, msp, key
    ):
        params, opt_state, auxiliary_data = step_fn(
            params, opt_state, target_energy, target_density, msp, key
        )
        params_ema = ema_update(params_ema, params, 0.995)
        return params, opt_state, params_ema, auxiliary_data

    def train_step_fn(
        params, opt_state, params_ema, target_energy, target_density, msp, key
    ):
        msp = preprocess_params(
            msp,
            hparams,
            loop_params.max_number_of_atoms,
            loop_params.pad_quadrature_grid,
        )
        return step_with_ema_update(
            params, opt_state, params_ema, target_energy, target_density, msp, key
        )

    def val_step_fn(params, opt_state, params_ema, target_energy, target_density, msp, key):
        msp = preprocess_params(
            msp,
            hparams,
            loop_params.max_number_of_atoms,
            loop_params.pad_quadrature_grid,
        )
        _, auxiliary_data = loss_fn(params, target_energy, target_density, msp)
        return params, opt_state, params_ema, auxiliary_data

    if hparams.get("jit_step"):
        train_step_fn = jax.jit(train_step_fn)
        val_step_fn = jax.jit(val_step_fn)

    def __epoch_loop(
        prefix: str,
        params: NnParams,
        params_ema: EMA[NnParams],
        data: DataLoader,
        step_fn: EpochFn,
        opt_state: Optional[OptState],
        epoch: int,
        validation: bool,
        key,
    ):
        step = epoch * n_steps

        logger.start_epoch_mean(prefix, epoch)
        if validation:
            params = ema_value(params_ema)

        for sample in tqdm(data):
            (target_energy, target_density, mp, msp) = sample
            # Put prefetched data from torch dataloader into jax.arrays:
            params, opt_state, params_ema, auxiliary_data = step_fn(
                params, opt_state, params_ema, target_energy, target_density, msp, key
            )
            auxiliary_data = jax.tree_util.tree_map(np.asarray, auxiliary_data)
            logger.log_step(
                prefix,
                params,
                target_energy,
                target_density,
                mp,
                molecule_grid,
                auxiliary_data,
                opt_state,
                step=step,
                epoch=epoch,
            )
            step += 1
            auxiliary_data: LossAuxiliaryOutput
            print(
                f"{prefix} energy difference [mEh]: ",
                abs(auxiliary_data.pred_energies.total - target_energy) * 1e3,
            )
            del target_energy, target_density, mp, msp, sample

        logger.log_epoch_mean()

        if opt_state is not None:
            return params, params_ema, opt_state

    # main training loop with early stopping
    best_val_loss = float("inf")
    best_params = params
    loss_fn = jax.jit(loss_fn)
    patience = loop_params.patience
    params_ema = ema_make(params)
    for i in range(loop_params.epochs):
        print(f"############# {prefix} epoch {i} #############")
        # train loop:
        key, subkey = jax.random.split(key)
        params, params_ema, opt_state = __epoch_loop(
            prefix + "train",
            params,
            params_ema,
            train_data,
            train_step_fn,
            opt_state,
            i,
            False,
            subkey,
        )
        # validation loop
        __epoch_loop(
            prefix + "val",
            params,
            params_ema,
            itertools.islice(val_data, None, None, loop_params.val_step_size),
            val_step_fn,
            opt_state,
            i,
            True,
            None,
        )

        if best_val_loss > logger.recent_val_loss:
            best_params = ema_value(params_ema)
            # make sure it's a useful improvement
            if best_val_loss * 0.99 > logger.recent_val_loss:
                best_val_loss = logger.recent_val_loss
                patience = loop_params.patience
            if checkpointer is not None:
                checkpointer.save(best_params, opt_state, epoch=i, loss=best_val_loss)
        elif i > min_epochs:
            patience -= 1
            if patience == 0:
                break
        # Remove all the bad init parameters
        if i == min_epochs:
            params_ema = ema_make(params)

    return best_params


def train(
    params: NnParams,
    train_data: DataLoader,
    val_data: DataLoader,
    step_fn: Callable,
    loss_fn: Callable,
    hparams: Dict[str, Any],
    opt_state: OptState,
    logger: Logger,
    molecule_grid: Grid,
    checkpointer: Optional[Checkpointer],
    gnn_feature_fn: Callable,
    data_params: Dict[str, Any],
) -> NnParams:
    # n_heavy = data_params["qm9_train_heavy_limit"]
    # if n_heavy is not None and data_params["dataset"] == "qm9":
    #     # alkane molecules have maximum number of atoms for a given number of heavy atoms
    #     max_number_of_atoms = n_heavy + 2 * (n_heavy + 1)
    # else:
    #     max_number_of_atoms = data_params["max_number_of_atoms"]

    loop_params = TrainLoopParams(
        hparams["epochs"],
        data_params["max_number_of_atoms"],
        data_params["pad_quadrature_grid"],
        int(1 / data_params["validation_subsample_fraction"]),
        hparams["early_stopping_patience"],
    )

    params = __train_loop(
        "",
        params,
        train_data,
        val_data,
        step_fn,
        loss_fn,
        loop_params,
        hparams,
        opt_state,
        logger,
        molecule_grid,
        checkpointer,
        gnn_feature_fn,
    )
    return params


def pretrain_mgga(
    init_sample: MoleculeSolverParams,
    seed: int,
    opt_state: OptState,
    train_data: DataLoader,
    val_data: DataLoader,
    hparams: Dict[str, Any],
    data_params: Dict[str, Any],
    mgga_feature_fn: Callable,
    molecule_grid: Grid,
    checkpointer: Optional[Checkpointer],
    logger: Logger,
) -> NnParams:
    model = get_mgga_model(hparams)
    mgga_in_features = (
        mgga_feature_fn(
            init_sample.initial_density_matrix, init_sample.quadrature_ao_values
        )
        if mgga_feature_fn is not None
        else None
    )

    params = model.init(
        jax.random.PRNGKey(seed), mgga_in_features, init_sample.quadrature_weights
    )
    xc_energy_fn = xc_energy.get_mgga_xc_energy_fn(model, hparams, mgga_feature_fn)

    optimizer, opt_state = get_optimizer(hparams["optimizer"], params)

    # solver_fn = scf.solver.get_solver(xc_energy_fn, hparams)
    solver_fn = scf.solver.get_interpolated_solver(xc_energy_fn, hparams)

    loss_fn = loss.get_loss_fn(
        solver_fn, molecule_grid, hparams["energy_weights"], hparams["density_weights"]
    )

    optimizer, opt_state = get_optimizer(
        hparams["model"]["metaGGA"]["pretraining"]["optimizer"], params
    )
    loss_grad_fn = jax.value_and_grad(loss_fn, argnums=0, has_aux=True)

    @jax.jit
    def step_fn(
        params: NnParams,
        opt_state: optax.OptState,
        target_energy: float,
        target_density: jax.Array,
        mol_params: MoleculeSolverParams,
        key,
    ) -> Tuple[NnParams, optax.OptState, LossAuxiliaryOutput]:
        """
        Performs a single optimization step.
        """
        (loss, auxiliary_data), grads = loss_grad_fn(
            params, target_energy, target_density, mol_params, key
        )

        if (
            hparams["model"]["metaGGA"]["pretraining"]["optimizer"]["schedule"]["type"]
            == "reduce_on_plateau"
            or hparams["model"]["metaGGA"]["pretraining"]["optimizer"]["schedule"][
                "type"
            ]
            == "reduce_on_plateau_with_linear_decay"
        ):
            updates, opt_state = optimizer.update(grads, opt_state, params, value=loss)
        else:
            updates, opt_state = optimizer.update(grads, opt_state, params)
        params = optax.apply_updates(params, updates)
        return params, opt_state, auxiliary_data

    loop_params = TrainLoopParams(
        hparams["model"]["metaGGA"]["pretraining"]["epochs"],
        data_params["max_number_of_atoms"],  # TODO: padding not required?
        data_params["pad_quadrature_grid"],
        int(1 / data_params["validation_subsample_fraction"]),
        hparams["model"]["metaGGA"]["pretraining"]["early_stopping_patience"],
    )

    params = __train_loop(
        "pretraining ",
        params,
        train_data,
        val_data,
        step_fn,
        loss_fn,
        loop_params,
        hparams,
        opt_state,
        logger,
        molecule_grid,
        checkpointer,
        None,
    )

    return params
