import functools
import optax
import jax.numpy as jnp

from optax import GradientTransformation, OptState
from typing import Dict, Any, Tuple
from mldft.utils.typing import NnParams


def get_optimizer(
    opt_params: Dict[str, Any], params: NnParams
) -> Tuple[GradientTransformation, OptState]:
    """
    Get the optimizer and the initial optimizer state.
    # TODO: add reduce learning rate on plateau options

    Args:
        opt_params (Dict[str, Any]): parameters for the optimizer
        params (NnParams): initial neural network parameters

    Returns:
        GradientTransformation, OptState: optimizer and initial optimizer state
    """
    learning_rate = opt_params["schedule"]["learning_rate"]
    warmup_steps = opt_params["schedule"]["warmup_steps"]
    decay_steps = opt_params["schedule"]["decay_steps"]
    min_lr = opt_params["schedule"]["minimum_learning_rate"]

    schedules = []
    if warmup_steps > 0:
        schedules.append(
            optax.linear_schedule(
                min(1e-6, learning_rate / 10), learning_rate, warmup_steps
            )
        )

    if (
        opt_params["schedule"]["type"] == "constant"
        or opt_params["schedule"]["type"] == "reduce_on_plateau"
    ):
        decay = optax.constant_schedule(learning_rate)
    elif (
        opt_params["schedule"]["type"] == "linear"
        or opt_params["schedule"]["type"] == "reduce_on_plateau_with_linear_decay"
    ):
        """
        Schedule recommend by optax authors for Prodigy optimizer.
        """
        # decay = optax.linear_schedule(learning_rate, min_lr, decay_steps)
        decay = lambda t: jnp.array(learning_rate / (1 + t / 1000), jnp.float32)
    elif opt_params["schedule"]["type"] == "cosine_decay":
        decay = optax.cosine_decay_schedule(learning_rate, decay_steps, min_lr)
    else:
        raise NotImplementedError(f"Schedule {opt_params['schedule']} not implemented.")
    schedules.append(decay)

    if warmup_steps > 0:
        schedule = optax.join_schedules(schedules, boundaries=(warmup_steps,))
    else:
        assert len(schedules) == 1
        schedule = schedules[0]

    if opt_params["name"] == "adam":
        optimizer = optax.adamw(
            learning_rate=schedule, weight_decay=opt_params["weight_decay"]
        )
    elif opt_params["name"] == "amsgrad":
        optimizer = optax.amsgrad(learning_rate=schedule)
    elif opt_params["name"] == "prodigy":
        if learning_rate != 1:
            print("Warning: Prodigy optimizer should have a learning rate of 1.")
        optimizer = optax.contrib.prodigy(
            learning_rate=schedule,
            betas=(0.9, 0.999),
            weight_decay=opt_params["weight_decay"],
        )
    else:
        raise NotImplementedError(f"Optimizer {opt_params['name']} not implemented.")

    if (
        opt_params["schedule"]["type"] == "reduce_on_plateau"
        or opt_params["schedule"]["type"] == "reduce_on_plateau_with_linear_decay"
    ):
        rop_params = opt_params["schedule"]["reduce_on_plateau"]
        optimizer = optax.chain(
            optimizer,
            optax.contrib.reduce_on_plateau(
                accumulation_size=rop_params["accumulation_size"],
                factor=rop_params["factor"],
                cooldown=rop_params["cooldown"],
                patience=rop_params["patience"],
            ),
        )

    if opt_params["grad_clip_max_norm"] is not None:
        optimizer = optax.chain(
            optax.clip_by_global_norm(opt_params["grad_clip_max_norm"]),
            optimizer,
        )

    if opt_params["apply_ever_k"] > 1:
        optimizer = optax.chain(
            optimizer, optax.apply_every(opt_params["apply_ever_k"])
        )

    if opt_params["skip_nan"]:
        optimizer = apply_if_finite(optimizer, max_consecutive_errors=1)

    return optimizer, optimizer.init(params)


from typing import Any, NamedTuple, Protocol

import chex
from jax import lax
from jax import tree_util as jtu
import jax.numpy as jnp

from optax import tree_utils as otu
from optax._src import base
from optax._src import numerics


class ApplyIfFiniteState(NamedTuple):
    """State of the `GradientTransformation` returned by `apply_if_finite`.

    Attributes:
      notfinite_count: Number of consecutive gradient updates containing an Inf or
        a NaN. This number is reset to 0 whenever a gradient update without an Inf
        or a NaN is done.
      last_finite: Whether or not the last gradient update contained an Inf or a
        NaN.
      total_notfinite: Total number of gradient updates containing an Inf or
        a NaN since this optimizer was initialised. This number is never reset.
        inner_state: The state of the inner `GradientTransformation`.

    """

    notfinite_count: Any
    last_finite: Any
    total_notfinite: Any
    inner_state: Any


def apply_if_finite(
    inner: base.GradientTransformation, max_consecutive_errors: int
) -> base.GradientTransformation:
    """A function that wraps an optimizer to make it robust to a few NaNs or Infs.

    The purpose of this function is to prevent any optimization to happen if the
    gradients contain NaNs or Infs. That is, when a NaN or Inf is detected in the
    gradients, the wrapped optimizer ignores that gradient update. If the NaNs or
    Infs persist after a given number of updates, the wrapped optimizer gives up
    and accepts the update.

    Args:
      inner: Inner transformation to be wrapped.
      max_consecutive_errors: Maximum number of consecutive gradient updates
        containing NaNs or Infs that the wrapped optimizer will ignore. After
        that many ignored updates, the optimizer will give up and accept.

    Returns:
      New ``GradientTransformationExtraArgs``.
    """

    inner = base.with_extra_args_support(inner)

    def init(params):
        return ApplyIfFiniteState(
            notfinite_count=jnp.zeros([], jnp.int32),
            last_finite=jnp.array(True, jnp.bool_),
            total_notfinite=jnp.zeros([], jnp.int32),
            inner_state=inner.init(params),
        )

    def update(updates, state, params=None, **extra_args):
        inner_state = state.inner_state
        flat_updates = jtu.tree_flatten(updates)[0]
        isfinite = jnp.all(jnp.array([jnp.all(jnp.isfinite(p)) for p in flat_updates]))
        notfinite_count = jnp.where(
            isfinite,
            jnp.zeros([], jnp.int32),
            numerics.safe_int32_increment(state.notfinite_count),
        )

        def do_update():
            return inner.update(updates, inner_state, params, **extra_args)

        def reject_update():
            return otu.tree_zeros_like(updates), inner_state

        cond = functools.partial(
            jnp.where,
            jnp.logical_or(isfinite, notfinite_count > max_consecutive_errors),
        )
        updates, new_inner_state = jtu.tree_map(cond, do_update(), reject_update())

        return updates, ApplyIfFiniteState(
            notfinite_count=notfinite_count,
            last_finite=isfinite,
            total_notfinite=jnp.where(
                isfinite,
                state.total_notfinite,
                numerics.safe_int32_increment(state.total_notfinite),
            ),
            inner_state=new_inner_state,
        )

    return base.GradientTransformationExtraArgs(init=init, update=update)
