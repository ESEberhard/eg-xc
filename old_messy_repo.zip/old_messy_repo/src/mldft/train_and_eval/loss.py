import jax
import jax.numpy as jnp

from mldft.scf.solver import MoleculeSolverParams
from mldft.grids import Grid, density_on_grid

from mldft.utils.typing import NnParams, LossFn, SolverFn, LossAuxiliaryOutput
from typing import Tuple, List


def get_loss_fn(
    solver_fn: SolverFn,
    molecule_grid: Grid,
    energy_weights: List,
    density_weights: List,
) -> LossFn:
    """
    Returns a loss function for the given solver function and molecule grid.
    The loss is calculated along a given SCF trajectory as proposed in
    https://doi.org/10.1103/PhysRevLett.126.036401.
    Both the energy and the electron density are considered.

    TODO: Idea for improvement: Use the gradient of the density as a loss term too.
    """
    energy_weights = jnp.array(energy_weights, dtype=jnp.float32)
    density_weights = jnp.array(density_weights, dtype=jnp.float32)
    include_density_loss = not jnp.all(density_weights == 0)

    @jax.jit
    def loss_fn(
        params: NnParams,
        target_energy: float,
        target_density: jax.Array,
        mol_params: MoleculeSolverParams,
        key=None,
    ) -> Tuple[jax.Array, LossAuxiliaryOutput]:
        solver_output = solver_fn(params, mol_params, key)

        energy_loss = jnp.dot(
            jnp.square(solver_output.last_n_energies - target_energy), energy_weights
        )

        energy_volatility = jnp.mean(
            jnp.abs(
                solver_output.last_n_energies[1:] - solver_output.last_n_energies[:-1]
            )
        ) / (-1 * target_energy)

        if include_density_loss:

            def pred_density(P):
                return density_on_grid(
                    mol_params.molecule_ao_values,
                    P,
                    molecule_grid.shape,
                    include_grad=False,
                    include_kinetic_energy_density=False,
                )[..., 0]

            last_n_densities = jax.vmap(pred_density)(
                solver_output.last_n_density_matrices
            )

            last_n_density_loss = (
                jnp.sum(
                    jnp.square(last_n_densities - target_density[None][..., 0]),
                    axis=(1, 2, 3),
                )
                * molecule_grid.grid_spacing**3
                / mol_params.n_electrons**2
            )

            density_loss = jnp.dot(last_n_density_loss, density_weights)
            density = last_n_densities[-1]
        else:
            density_loss = 0
            density = None
            # density = density_on_grid(
            #                     mol_params.molecule_ao_values,
            #                     solver_output.last_n_density_matrices[-1],
            #                     molecule_grid.shape,
            #                 )

        auxiliary_data = LossAuxiliaryOutput(
            energy_loss,
            density_loss,
            solver_output.last_energies,
            solver_output.last_n_density_matrices[-1],
            density,
            energy_volatility,
        )
        return energy_loss + density_loss, auxiliary_data

    return loss_fn
