import jax
import jax.numpy as jnp
import numpy as onp
from functools import lru_cache

from mldft.utils.typing import FockTensors

import pyscf
from jax.experimental import host_callback

from typing import Callable, Tuple, List, Any
from numpy.typing import ArrayLike

E_core = Any
E_ee_rep = Any
e_Energies = Tuple[E_core, E_ee_rep]


@lru_cache(maxsize=1)
def get_eri_tensor(mol: pyscf.gto.M):
    return mol.intor('int2e')

def get_host_j_fn(molecule: str,
                  basis: str,
                  hcb_using_numpy: bool) -> Callable:
    mol = pyscf.gto.M(atom=molecule,
                      basis=basis)
    if hcb_using_numpy:
        def j_fn(dm: ArrayLike) -> ArrayLike:
            eri = get_eri_tensor(mol)
            J = onp.einsum('ijkl,ij->kl', eri, dm)
            return J
    else:
        mf = pyscf.scf.HF(mol)
        j_fn =  mf.get_j

    return j_fn


def using_host_callbacks(j_fns_list: List[Callable],
                         solver_precision: str) -> Tuple[Callable, Callable]:
    def get_J(args):
        mol_id, density_matrix = args
        J = j_fns_list[mol_id](dm=density_matrix)
        return J

    @jax.custom_vjp
    def J_fn(density_matrix: jax.Array, mol_id: int) -> jax.Array:
       J = host_callback.call(
                get_J,
                (mol_id, density_matrix),
                result_shape=jax.ShapeDtypeStruct(
                                    density_matrix.shape,
                                    "float64"
                                )
            ).astype(density_matrix.dtype)
       return J

    def forward_J(density_matrix, mol_id):
        return J_fn(density_matrix, mol_id), mol_id

    def backward_J(cached, T):
        mol_id = cached
        return  J_fn(T, mol_id), None

    J_fn.defvjp(forward_J, backward_J)


    def electron_energy(density_matrix: jax.Array,
                        fock_tensors: FockTensors) -> e_Energies:
        """
        Calculates the energy for a given coefficient matrix and
        exchange-correlation energy.
        See section 3 in https://doi.org/10.3390/molecules25051218.
        """
        P = density_matrix
        # Calculate electron-electron repulsion
        core  = jnp.einsum('ij,ij', fock_tensors.h_core, P)
        J = J_fn(P, fock_tensors.molecule_id)
        ee_rep = 0.5 * jnp.einsum('ij,ij', J, P)
        return  core, ee_rep

    def fock_matrix(density_matrix: jax.Array,
                    fock_tensors: FockTensors,
                    v_xc: jnp.ndarray) -> Tuple[jax.Array, jax.Array]:
        P = density_matrix
        # Calculate electron-electron repulsion
        J = J_fn(P, fock_tensors.molecule_id)
        # Calculate the Fock matrix
        F  = fock_tensors.h_core + J + v_xc
        return F.astype(solver_precision)

    return electron_energy, fock_matrix


def density_fitting(solver_precision: str) -> Tuple[Callable, Callable]:
    def electron_energy(density_matrix: jax.Array,
                        fock_tensors: FockTensors) -> e_Energies:
        """
        Calculates the energy for a given coefficient matrix and
        exchange-correlation energy using density fitting for
        to approximate the eri tensor.
        """
        P = density_matrix
        # Calculate electron-electron repulsion
        core   = jnp.einsum('ij,ij', fock_tensors.h_core, P)
        ee_rep = 0.5 * (jnp.einsum('Pij,ij -> P', fock_tensors.df_tensor, P)**2).sum()
        return core, ee_rep

    def fock_matrix(density_matrix: jax.Array,
                    fock_tensors: FockTensors,
                    v_xc: jnp.ndarray) -> Tuple[jax.Array, jax.Array]:
        P = density_matrix
        # Calculate electron-electron repulsion
        J = jnp.einsum('Pij,Pkl,ij->kl',
                       fock_tensors.df_tensor, fock_tensors.df_tensor, P)
        # Calculate the Fock matrix
        F  = fock_tensors.h_core + J + v_xc
        return F.astype(solver_precision)

    return electron_energy, fock_matrix


def materializing_eri(solver_precision: str) -> Tuple[Callable, Callable]:
    def electron_energy(density_matrix: jax.Array,
                        fock_tensors: FockTensors) -> e_Energies:
        """
        Calculates the energy for a given coefficient matrix and
        exchange-correlation energy.
        See section 3 in https://doi.org/10.3390/molecules25051218.
        """
        P = density_matrix
        # Calculate electron-electron repulsion
        core   = jnp.einsum('ij,ij', fock_tensors.h_core, P)
        ee_rep = 0.5 * jnp.einsum('ijkl,ij,kl',
                                  fock_tensors.elect_rep_integrals,
                                  P, P)
        return core, ee_rep

    def fock_matrix(density_matrix: jax.Array,
                    fock_tensors: FockTensors,
                    v_xc: jnp.ndarray) -> Tuple[jax.Array, jax.Array]:
        P = density_matrix
        # Calculate electron-electron repulsion
        J = jnp.einsum('ijkl,ij->kl', fock_tensors.elect_rep_integrals, P)
        # Calculate the Fock matrix
        F  = fock_tensors.h_core + J + v_xc
        return F.astype(solver_precision)

    return electron_energy, fock_matrix