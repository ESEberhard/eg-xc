"""
Code adapted and extended from deepqmc
https://github.com/deepqmc/deepqmc
"""

import functools
import jax
import jax.numpy as jnp
import numpy as np
import pyscf
from jaxtyping import Array, ArrayLike, Float, Integer

from typing import Tuple, List


def get_cartesian_angulars(l: int) -> List[Tuple[int, int, int]]:
    """
    Returns the cartesian angular momentum quantum numbers for a given l.

    Args:
        l (int): angular momentum quantum number

    Returns:
        List[Tuple[int, int, int]]: list of (lx, ly, lz) tuples
    """
    if l == 0:
        return [(0, 0, 0)]
    elif l == 1:
        return [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    elif l == 2:
        return [(1, 1, 0), (0, 1, 1), (1, 0, 1), (2, 0, 0), (0, 2, 0), (0, 0, 2)]
    elif l == 3:
        return [
            (3, 0, 0),  # 0     x^3
            (1, 2, 0),  # 1     x   y^2
            (1, 0, 2),  # 2     x       z^2
            (2, 1, 0),  # 3     x^2 y
            (0, 3, 0),  # 4         y^3
            (0, 1, 2),  # 5         y   z^2
            (2, 0, 1),  # 6     x^2     z
            (0, 2, 1),  # 7         y^2 z
            (0, 0, 3),  # 8             z^3
            (1, 1, 1),  # 9     x   y   z
        ]
    else:
        raise NotImplementedError(f"l={l} not implemented")


def angular_normalization(ijk: Integer[ArrayLike, "..."]) -> Float[Array, "..."]:
    ijk = jnp.array(ijk, dtype=jnp.int32)
    out = jax.scipy.special.factorial(ijk) / jax.scipy.special.factorial(2 * ijk)
    return jnp.sqrt(out.prod(axis=-1))


def safe_power(x, power, eps=0):
    # TODO: check if this is necessary
    # 0.0^0.0 has undefined gradients,
    # but jnp.power has further issues with every power
    # if x == 0.0
    x = jnp.where(jnp.abs(x) < eps, x + eps, x)
    y = jnp.power(x, power)
    return y


def get_angulars(R: Array, l: int):
    """
    https://doi.org/10.1002/qua.560540202
    Returns the angular part of the GTO basis functions.
    Ordering follows
    https://en.wikipedia.org/wiki/Table_of_spherical_harmonics#Real_spherical_harmonics
    https://pyscf.org/user/gto.html#ordering-of-basis-functions
    https://github.com/pyscf/pyscf/blob/a40064009cd3865bce6315d9f87323340e3f343c/pyscf/lib/gto/grid_ao_drv.c
    """

    def normalize(ijk_s, angulars):
        anorms = angular_normalization(ijk_s)
        return angulars * anorms

    ijk_s = jnp.array(get_cartesian_angulars(l), dtype=jnp.int32)

    angulars = safe_power(R[..., None, :], ijk_s).prod(axis=-1)

    if l < 2:
        return normalize(ijk_s, angulars)

    elif l == 2:
        angulars = normalize(ijk_s, angulars)
        angulars = jnp.stack(
            [
                angulars[..., 0],  # d_xy
                angulars[..., 1],  # d_yz
                (1 / 2)
                * (2 * angulars[..., 5] - angulars[..., 4] - angulars[..., 3]),  # d_z^2
                angulars[..., 2],  # d_xz
                (jnp.sqrt(3) / 2) * (angulars[..., 3] - angulars[..., 4]),
            ],  # d_(x^2 - y^2)
            axis=-1,
        )
    elif l == 3:
        # factors from: https://github.com/sunqm/libcint/blob/master/src/cart2sph.c
        factors = (
            jnp.array(
                [
                    # f_y(3x^2 - y^2)
                    [
                        0,
                        0,
                        0,
                        1.770130769779930531,
                        -0.590043589926643510,
                        0,
                        0,
                        0,
                        0,
                        0,
                    ],
                    # f_xyz
                    [0, 0, 0, 0, 0, 0, 0, 0, 0, 2.890611442640554055],
                    # f_yz^2
                    [
                        0,
                        0,
                        0,
                        -0.457045799464465739,
                        -0.457045799464465739,
                        1.828183197857862944,
                        0,
                        0,
                        0,
                        0,
                    ],
                    [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        -1.119528997770346170,
                        -1.119528997770346170,
                        0.746352665180230782,
                        0,
                    ],
                    [
                        -0.457045799464465739,
                        -0.457045799464465739,
                        1.828183197857862944,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                    ],
                    [
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        1.445305721320277020,
                        -1.445305721320277020,
                        0,
                        0,
                    ],
                    [
                        0.590043589926643510,
                        -1.770130769779930530,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                    ],
                ]
            )
            / 8.17588381146625823
        )

        angulars = jnp.einsum("ij,...j->...i", factors, angulars)
    return angulars


def make_gto_shell(atom_idx: int, l: int, coeffs: ArrayLike, zetas: ArrayLike):
    rnorms = (2 * zetas / np.pi) ** (3 / 4) * (8 * zetas) ** (l / 2)

    def gto(diffs: Array):
        """
        Args:
            diffs (Array): Displacement vectors of grid points from atoms
                (N_positions, N_atoms, 4), where [i, j, 4] is the distance of
                grid point i from atom j

        Returns:
            the values of the GTO basis at the given grid points.

        Cramer, Christopher J. (2004).
        Essentials of computational chemistry : theories and models (2nd ed.).
        Chichester, West Sussex, England: Wiley. p. 167.
        ISBN 9780470091821.
        """
        diffs = diffs[..., atom_idx, :]
        r_vec, r = diffs[..., :3], diffs[..., 3:]

        exps = rnorms * jnp.exp(
            -jnp.abs(zetas * r**2)
        )  # TODO: abs should not be necessary
        radials = (coeffs * exps).sum(-1, keepdims=True)
        angulars = get_angulars(r_vec, l)
        return angulars * radials

    return gto


def make_gto_basis(mol: pyscf.gto.Mole, deriv: int = 0):
    center = jnp.array(mol.atom_coords())
    shells = [
        make_gto_shell(
            mol.bas_atom(i),
            mol.bas_angular(i),
            mol.bas_ctr_coeff(i).reshape(-1),
            mol.bas_exp(i),
        )
        for i in range(mol.nbas)
    ]

    @functools.partial(jnp.vectorize, signature="(d)->(o)")
    def basis(positions: ArrayLike):
        diffs = positions[..., None, :] - center
        diffs = jnp.concatenate(
            [
                diffs,  # diffs[i, j]... displacement vec of grid point i from atom j
                jnp.linalg.norm(diffs, axis=-1, keepdims=True),
            ],
            axis=-1,
        )  # (N_positions, N_atoms, 4)
        result = jnp.concatenate([shell(diffs) for shell in shells], -1)
        return result

    if deriv == 0:
        return basis

    elif deriv == 1:

        @functools.partial(jnp.vectorize, signature="(d)->(n,o)")
        def out(positions: ArrayLike):
            x_dot = jnp.eye(3, dtype=positions.dtype)
            ao, dpos = jax.vmap(
                lambda x_dot: jax.jvp(basis, (positions,), (x_dot,)), out_axes=(None, 0)
            )(x_dot)
            return jnp.concatenate([ao[None], dpos], axis=0)

        return out

    else:
        raise NotImplementedError(f"deriv={deriv} not implemented")


def safe_norm(x, axis=-1, keepdims=True):
    x = (jnp.conj(x) * x).sum(axis=axis, keepdims=keepdims)
    zero_mask = x == 0
    x_safe = jnp.where(zero_mask, 1.0, x)
    x_safe = jnp.sqrt(x)
    return jnp.where(zero_mask, 0.0, x_safe)



def make_gto_bases(period: int, basis, deriv: int = 0):
    elements = {
        1: np.arange(1, 3),
        2: np.arange(3, 11),
        3: np.arange(11, 19),
        4: np.arange(19, 37),
    }[period]
    bias = {1: 1, 2: 3, 3: 11, 4: 19}[period]
    mols = [
        pyscf.gto.M(atom=[(e, (0, 0, 0))], basis=basis, spin=e % 2) for e in elements
    ]
    angulars = [mols[0].bas_angular(i) for i in range(mols[0].nbas)]
    nao = len(angulars)
    ctr_coeffs = tuple(
        jnp.stack([m.bas_ctr_coeff(i).reshape(-1) for m in mols]) for i in range(nao)
    )
    bas_exp = tuple(jnp.stack([m.bas_exp(i) for m in mols]) for i in range(nao))

    @functools.partial(jnp.vectorize, signature="(d),(d),()->(o)")
    def basis(positions: ArrayLike, center: ArrayLike, charge: ArrayLike):
        charge = charge - bias  # subtract the previous period
        diffs = positions[..., None, :] - center
        
        diffs = jnp.concatenate(
            [
                diffs,  # diffs[i, j]... displacement vec of grid point i from atom j
                safe_norm(diffs),
            ],
            axis=-1,
        )  # (N_positions, N_atoms, 4)
        shells = [
            make_gto_shell(0, l, coeffs[charge], exps[charge])
            for l, coeffs, exps in zip(angulars, ctr_coeffs, bas_exp)
        ]
        result = jnp.concatenate([shell(diffs) for shell in shells], -1)
        return result

    if deriv == 0:
        return basis

    elif deriv == 1:

        @functools.partial(jnp.vectorize, signature="(d),(d),()->(n,o)")
        def out(positions: ArrayLike, center: ArrayLike, charge: ArrayLike):
            x_dot = jnp.eye(3, dtype=positions.dtype)
            ao, dpos = jax.vmap(
                lambda x_dot: jax.jvp(
                    lambda x: basis(x, center, charge), (positions,), (x_dot,)
                ),
                out_axes=(None, 0),
            )(x_dot)
            return jnp.concatenate([ao[None], dpos], axis=0)

        return out

    else:
        raise NotImplementedError(f"deriv={deriv} not implemented")
