"""
Implement Direct Inversion of the Iterative Subspace (DIIS)
algorithm applied to the Fock Matrix for SCF convergence.
Inspired by https://github.com/psi4/psi4numpy/blob/master/Tutorials/03_Hartree-Fock/3b_rhf-diis.ipynb
"""

import jax
import jax.numpy as jnp
from typing import Tuple, Callable


def get_diis_fock_fn(init: bool) -> Callable:
    def diis_fock(new_fock: jax.Array,
                  new_res: jax.Array,
                  fock_trajectory: jax.Array,
                  residuals: jax.Array,
                  overlap: jax.Array) -> Tuple[jax.Array, jax.Array]:
        """
        Returns the am DIIS update to the Fock matrix.
        fock_trajectory: (n_steps, n_basis, n_basis)
        residuals: (n_steps, n_basis, n_basis)

        Args:
            fock_trajectory (jax.Array | (n_steps, n_basis, n_basis))
            residuals (jax.Array | (n_steps, n_basis, n_basis))
            overlap (jax.Array | (n_steps - 1, n_steps - 1))
            init (bool)

        Returns:
            Fock matrix (jax.Array | (n_basis, n_basis)), overlap (jax.Array | (n_steps, n_steps))
        """
        dtype = fock_trajectory.dtype
        if init:
            overlap = jnp.einsum('ikl,jkl->ij', residuals, residuals)
        else:
            residuals = jnp.concatenate([residuals, new_res[None, ...]], axis=0)
            fock_trajectory = jnp.concatenate([fock_trajectory, new_fock[None, ...]], axis=0)
            new_overlap = jnp.einsum('ikl,kl->i', residuals, new_res)
            overlap = jnp.block([
                    [
                        overlap,
                        new_overlap[:-1][:, None]
                    ],[
                        new_overlap[:-1][None, :],
                        new_overlap[-1][None, None]
                    ]])
        N = residuals.shape[0]
        B = jnp.block([[overlap,                  -jnp.ones((N, 1), dtype)],
                    [-jnp.ones((1, N), dtype),  jnp.array([[0.0]], dtype)]])
        # Right hand side of Pulay equation
        rhs = jnp.where(jnp.arange(N + 1) < N, 0, -1)
        # Solve Pulay equation
        fock_coeffs = jnp.linalg.solve(B, rhs)
        # Calculate DIIS Fock matrix
        F = jnp.einsum('i,ijk->jk', fock_coeffs[:-1], fock_trajectory)
        if not init:
            F = jnp.where(jnp.isnan(F).any(), new_fock, F)
        return F, fock_trajectory, residuals, overlap

    return diis_fock



# def get_diis_fock_fn(append: bool, init: bool) -> Callable:
#     assert not (append and init), "Cannot append and initialize at the same time."
#     def diis_fock(new_fock: jax.Array,
#                   new_res: jax.Array,
#                   fock_trajectory: jax.Array,
#                   residuals: jax.Array,
#                   overlap: jax.Array) -> Tuple[jax.Array, jax.Array]:
#         """
#         Returns the am DIIS update to the Fock matrix.
#         fock_trajectory: (n_steps, n_basis, n_basis)
#         residuals: (n_steps, n_basis, n_basis)

#         Args:
#             fock_trajectory (jax.Array | (n_steps, n_basis, n_basis))
#             residuals (jax.Array | (n_steps, n_basis, n_basis))
#             overlap (jax.Array | (n_steps - 1, n_steps - 1))
#             init (bool)

#         Returns:
#             Fock matrix (jax.Array | (n_basis, n_basis)), overlap (jax.Array | (n_steps, n_steps))
#         """
#         dtype = fock_trajectory.dtype
#         if init:
#             overlap = jnp.einsum('ikl,jkl->ij', residuals, residuals)
#         else:
#             if append:
#                 residuals = jnp.concatenate([residuals, new_res[None, ...]], axis=0)
#                 fock_trajectory = jnp.concatenate([fock_trajectory, new_fock[None, ...]], axis=0)
#             else:
#                 fock_trajectory = jnp.concatenate([fock_trajectory, new_fock[None, ...]], axis=0)
#                 F = 0.5 * new_fock + 0.5 * fock_trajectory[-1]
#                 return F, fock_trajectory, residuals, overlap
#                 residuals = jnp.concatenate([residuals[:-1], new_res[None, ...]], axis=0)
#                 fock_trajectory = jnp.concatenate([fock_trajectory[:-1], new_fock[None, ...]], axis=0)
#                 overlap = overlap[:-1, :-1]

#             new_overlap = jnp.einsum('ikl,kl->i', residuals, new_res)
#             overlap = jnp.block([
#                     [
#                         overlap,
#                         new_overlap[:-1][:, None]
#                     ],[
#                         new_overlap[:-1][None, :],
#                         new_overlap[-1][None, None]
#                     ]])
#         N = residuals.shape[0]
#         B = jnp.block([[overlap,                  -jnp.ones((N, 1), dtype)],
#                     [-jnp.ones((1, N), dtype),  jnp.array([[0.0]], dtype)]])
#         # Right hand side of Pulay equation
#         rhs = jnp.where(jnp.arange(N + 1) < N, 0, -1)
#         # Solve Pulay equation
#         jax.debug.print("########################## COND {x}", x=jnp.linalg.cond(B))
#         # print("FOOOCK dtype", B.dtype)

#         fock_coeffs = jnp.linalg.solve(B, rhs)
#         # Calculate DIIS Fock matrix
#         F = jnp.einsum('i,ijk->jk', fock_coeffs[:-1], fock_trajectory)
#         # F = 0.5 * new_fock + 0.5 * fock_trajectory[-1]
#         return F, fock_trajectory, residuals, overlap

#     return diis_fock

