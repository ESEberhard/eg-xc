import jax.numpy as jnp
import jax

from mldft.utils.typing import (
    NnParams,
    SolverOutput,
    MoleculeSolverParams,
    FockTensors,
    Energies,
)
from mldft.scf import diis, fock_matrix

from typing import Callable, Tuple, Union, Dict, Optional, List


ScfCycleCarry = Union[jax.Array, Tuple[jax.Array, jax.Array, jax.Array, jax.Array]]


def coeff_to_density_matrix(coeff: jax.Array, occupancy: FockTensors) -> jax.Array:
    """
    Calculates the density matrix from the coefficient matrix.
    """
    return jnp.einsum("pi,qi,i->pq", coeff, coeff, occupancy)


def transformation_matrix(S: jax.Array) -> jax.Array:
    """
    Returns the transformation matrix X that diagonalizes the overlap matrix S.
    Follows section 7 in https://doi.org/10.3390/molecules25051218
    """
    # Lambda, V = jnp.linalg.eigh(S)
    # X = V @ jnp.diag(1 / jnp.sqrt(Lambda)) @ V.T
    # return X
    S = S.astype(jnp.float64)
    Lambda, V = jnp.linalg.eigh(S, symmetrize_input=True)
    inv_lambda = jnp.reciprocal(jnp.sqrt(Lambda))
    return jnp.einsum("ab,b,bd->ad", V, inv_lambda, V.T)


def generalized_eigenvalue_problem(
    F: jax.Array, X: jax.Array, mask=None
) -> Tuple[jax.Array, jax.Array]:
    """
    Returns a function that solves the generalized eigenvalue problem
    for a given Fock matrix F assuming a static overlap matrix S.
    Follows section 7 in https://doi.org/10.3390/molecules25051218
    # TODO: make more robust to degeneracies due to large basis sets (see reference above)
    """
    F_dash = X.T @ F @ X
    # e, C_dash = jnp.linalg.eigh(F_dash)
    # C = X @ C_dash
    # return e, C
    if mask is not None:
        F_dash *= mask
    e, C_dash = jnp.linalg.eigh(F_dash, symmetrize_input=True)
    C = X @ C_dash
    return e, C


def get_solver(
    xc_energy: Callable, hparams: Dict, j_fns_list: Optional[List[Callable]] = None
) -> Callable[[NnParams, MoleculeSolverParams], SolverOutput]:
    n_steps = hparams["steps"]
    return_last_n = hparams["return_last_n"]

    v_xc_fn = jax.grad(
        xc_energy, argnums=1
    )  # TODO: Think about how this generalizes to multiple spin orientations
    assert n_steps >= 2 + return_last_n

    solver_precision = hparams["precision"]["solver"]
    general_precision = hparams["precision"]["general"]

    if hparams["eri_calculation"]["using_host_callbacks"]:
        electron_energy_fn, fock_matrix_fn = fock_matrix.using_host_callbacks(
            j_fns_list, solver_precision
        )
    elif hparams["eri_calculation"]["density_fitting"]:
        electron_energy_fn, fock_matrix_fn = fock_matrix.density_fitting(
            solver_precision
        )
    else:
        electron_energy_fn, fock_matrix_fn = fock_matrix.materializing_eri(
            solver_precision
        )

    def solver(params: NnParams, mol_params: MoleculeSolverParams) -> SolverOutput:
        """
        Performs a self-consistent field calculation with n_steps iterations.

        Args:
            params: the parameters of the neural network.
            mol_params: the parameters of the molecule.

        Returns:
            SolverOutput: energies and density matrices for the last n steps.
        """
        S = mol_params.tensors.overlap
        X = transformation_matrix(S)

        if mol_params.ao_mask is not None:
            ao_mask = mol_params.ao_mask
            # mask out all the interaction terms of the padded basis functions
            density_mask = jnp.logical_and(ao_mask[:, None], ao_mask[None, :])
            fock_mask = jnp.logical_or(
                density_mask, jnp.eye(ao_mask.shape[0], dtype=bool)
            )
        else:
            density_mask = None
            fock_mask = None

        def energy_fn(P: jax.Array) -> Energies:
            e_xc = xc_energy(params, P.astype(general_precision), mol_params)
            e_core, e_ee_rep = electron_energy_fn(P, mol_params.tensors)
            return Energies(
                nuclei=mol_params.e_nuclei, core=e_core, ee_rep=e_ee_rep, xc=e_xc
            )

        def scf_cycle_fn(P: ScfCycleCarry) -> Tuple[ScfCycleCarry, Energies]:
            v_xc = v_xc_fn(params, P.astype(general_precision), mol_params)
            F = fock_matrix_fn(P, mol_params.tensors, v_xc)
            _, C = generalized_eigenvalue_problem(F, X, fock_mask)
            P = coeff_to_density_matrix(C, mol_params.occupancy)
            if density_mask is not None:
                P *= density_mask

            energies = energy_fn(P)
            return P, energies

        def scf_cycle_diis_fn(init: bool) -> Callable:
            diis_fn = diis.get_diis_fock_fn(init)

            def scf_cycle_diis(carry: ScfCycleCarry) -> Tuple[ScfCycleCarry, Energies]:
                P, fock_trajectory, residuals, overlap = carry
                v_xc = v_xc_fn(params, P.astype(general_precision), mol_params)
                F = fock_matrix_fn(P, mol_params.tensors, v_xc)
                _res_intermediate = jnp.einsum('ab,bc,cd->ad', F, P, S)
                res = (X.T @ (_res_intermediate - _res_intermediate.T) @ X)
                res = (res - res.mT) / 2
                # res = X.T @ (F @ P @ S - S @ P @ F) @ X
                F, fock_trajectory, residuals, overlap = diis_fn(
                    F, res, fock_trajectory, residuals, overlap
                )

                _, C = generalized_eigenvalue_problem(F, X, fock_mask)
                P = coeff_to_density_matrix(C, mol_params.occupancy)
                if density_mask is not None:
                    P *= density_mask

                energies = energy_fn(P)
                return (P, fock_trajectory, residuals, overlap), energies

            return scf_cycle_diis

        # Use initial guess of density matrix
        P = mol_params.initial_density_matrix

        if hparams["diis"]:
            init_scf_cycle_diis = scf_cycle_diis_fn(True)
            scf_cycle = scf_cycle_diis_fn(False)

            # initialize diis carry
            v_xc = v_xc_fn(params, P.astype(general_precision), mol_params)
            F = fock_matrix_fn(P, mol_params.tensors, v_xc)
            fock_trajectory = F[None, ...]
            _res_intermediate = jnp.einsum('ab,bc,cd->ad', F, P, S)
            residuals = (X.T @ (_res_intermediate - _res_intermediate.T) @ X)[None]
            residuals = (residuals - residuals.mT) / 2
            # residuals = (X.T @ (F @ P @ S - S @ P @ F) @ X)[None, ...]
            overlap = jnp.einsum("ikl,jkl->ij", residuals, residuals)
            _, C = generalized_eigenvalue_problem(F, X, fock_mask)  # first scf cycle
            P = coeff_to_density_matrix(C, mol_params.occupancy)
            if density_mask is not None:
                P *= density_mask
            scf_carry = (P, fock_trajectory, residuals, overlap)

            # second scf cycle
            scf_carry, _ = init_scf_cycle_diis(scf_carry)

            for _ in range(2, n_steps - return_last_n + 1):
                scf_carry, energies = scf_cycle(scf_carry)

        else:
            scf_carry = P
            for _ in range(n_steps - return_last_n + 1):
                scf_carry, energies = scf_cycle_fn(scf_carry)
            scf_cycle = scf_cycle_fn

        out_e = [energies.total]
        out_P = [scf_carry[0]]
        for _ in range(n_steps - return_last_n + 1, n_steps):
            scf_carry, energies = scf_cycle(scf_carry)
            is_nan = jnp.isnan(energies.total).any()
            out_e.append(jnp.where(is_nan, out_e[-1], energies.total))
            out_P.append(jnp.where(is_nan, out_P[-1], scf_carry[0]))

        out_e = jnp.stack(out_e, axis=0)
        out_P = jnp.stack(out_P, axis=0)

        return SolverOutput(out_e, out_P, energies)

    return solver


def get_interpolated_solver(
    xc_energy: Callable,
    hparams: Dict,
    j_fns_list: Optional[List[Callable]] = None,
) -> Callable[[NnParams, MoleculeSolverParams], SolverOutput]:
    from mldft.nn.learnable_mGGA import LDA

    lda = LDA(hparams["precision"]["general"])

    def lda_xc(_, P, msp: MoleculeSolverParams):
        rho = jnp.einsum(
            "ni,nj,ij->n", msp.quadrature_ao_values[0], msp.quadrature_ao_values[0], P
        )
        return lda.apply(
            {},
            rho[..., None].astype(hparams["precision"]["metaGGA"]),
            msp.quadrature_weights,
        )

    base_solver = get_solver(lda_xc, {**hparams, "return_last_n": 1}, j_fns_list)
    xc_solver = get_solver(xc_energy, hparams, j_fns_list)

    def solver(params: NnParams, mol_params: MoleculeSolverParams, key) -> SolverOutput:
        base_out = base_solver(params, mol_params)
        P_init = mol_params.initial_density_matrix
        P_base = base_out.last_n_density_matrices[-1]
        if key is None:
            p = 1
        else:
            p = (1 + jax.random.uniform(key)) / 2
        P_0 = (1 - p) * P_init + p * P_base
        P_0 = jax.lax.stop_gradient(P_0)
        # in case something didn't work we just default to the initial guess
        P_0 = jnp.where(jnp.isnan(P_0).any(), P_init, P_0)

        mol_params = mol_params.replace(initial_density_matrix=P_0)
        result = xc_solver(params, mol_params)
        return result

    return solver
