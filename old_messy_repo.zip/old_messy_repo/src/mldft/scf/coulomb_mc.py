"""
Presently this module is not used
"""

import jax
import jax.numpy as jnp
import numpy as onp

from mldft.grids import Grid, density_on_grid

from jaxtyping import Array
from typing import Tuple, Dict, Callable
from mldft.utils.typing import AoValues, MoleculeParams, FockTensors

from functools import partial


# for future reference:

# @partial(jax.jit, static_argnames=("n_samples",))
# def __weight_tensor(samples, p, n_samples):
#     id1, id2, _ = sample_pairing(n_samples)
#     r = jnp.linalg.norm(samples[id1, None, :] - samples[None, id2, :], axis=-1)
#     C = 1 / jnp.einsum('i, ij, j -> ij', p[id1], r, p[id2])
#     return C
# def __preprocess_monte_carlo(tensors: HostFockTensors,
#                              n_samples: int,
#                              precision: str,
#                              using_mc: bool):
#     if using_mc:
#         ao_values = jnp.array(tensors.mc_ao_values)
#         samples = jnp.array(tensors.mc_samples)
#         p_samples = jnp.array(tensors.prob_samples, dtype=precision)
#         ej0 = jnp.array(tensors.e_j0, dtype=precision)
#         weights_tensor = __weight_tensor(samples, p_samples, n_samples)
#         J0 = jnp.array(tensors.J_0)
#         return samples, ao_values, ej0, J0, weights_tensor
#     else:
#         return None, None, None, None, None



# def monte_carlo_based(eri_params: Dict,
#                       solver_precision: str) -> Tuple[Callable, Callable]:
#     """
#     Presently not used in the codebase.
#     """
#     delta_e_j_fn, J_fn = coulomb_mc.get_e_j_and_J_fn(eri_params)
#     def electron_energy(density_matrix: jax.Array,
#                         fock_tensors: FockTensors,
#                         e_xc: jax.Array) -> jax.Array:
#         """
#         Calculates the energy for a given coefficient matrix and
#         exchange-correlation energy.
#         See section 3 in https://doi.org/10.3390/molecules25051218.
#         """
#         P = density_matrix
#         # Calculate electron-electron repulsion
#         delta_e_j = delta_e_j_fn(P, fock_tensors)
#         energy  = fock_tensors.e_j0 + delta_e_j
#         energy += jnp.einsum('ij,ij', fock_tensors.h_core, P)
#         energy += e_xc
#         return energy, delta_e_j

#     def fock_matrix(density_matrix: jax.Array,
#                     fock_tensors: FockTensors,
#                     v_xc: jnp.ndarray) -> Tuple[jax.Array, jax.Array]:
#         P = density_matrix
#         # Calculate electron-electron repulsion
#         J = J_fn(P, fock_tensors)
#         # Calculate the Fock matrix
#         F  = fock_tensors.h_core + J + v_xc
#         return F.astype(solver_precision)

#     return electron_energy, fock_matrix

def host_electron_density_sampling_fn(molecule_params: MoleculeParams,
                                      params: Dict,
                                      rng: onp.random.Generator) -> onp.ndarray:
    assert params["mc_integration"] == True
    n_samples = params["n_samples"]
    sigma_sq = params["nuclei_standard_deviation"]

    charges = molecule_params.nuclear_charges
    n_nuclei = len(charges)

    charges = charges.astype(onp.float64)
    p_nuclei = charges / jnp.sum(charges)

    nuclei_ids = rng.choice(n_nuclei, size=n_samples, p=p_nuclei)

    delta_r_nuc = rng.normal(size=(n_samples, 3)) * onp.sqrt(sigma_sq)

    samples = molecule_params.atom_positions[nuclei_ids] + delta_r_nuc

    diffs = samples[:, None] - molecule_params.atom_positions[None, :]

    p_gaussian = 1 / (onp.sqrt(2 * onp.pi * sigma_sq)**3) * onp.exp(-onp.linalg.norm(diffs, axis=-1)**2 / (2 * sigma_sq))
    p_samples = onp.einsum('j,ij->i', p_nuclei, p_gaussian)

    return samples, p_samples


def get_device_electron_density_sampling_fn(params: Dict) -> Callable:
    """
    TODO: implement laplacian distribution
    """

    assert params["mc_integration"] == True
    n_samples = params["n_samples"]
    sigma_sq = params["nuclei_standard_deviation"]

    @jax.jit
    def sampling_fn(molecule_params: MoleculeParams,
                    random_key: jax.random.PRNGKey) -> Array:

        key1, key2 = jax.random.split(random_key, 2)

        nuclei_ids = jax.random.categorical(
                            key1,
                            jnp.log(molecule_params.nuclear_charges),
                            shape=(n_samples,)
                        )

        delta_r_nuc = jax.random.normal(key2, shape=(n_samples, 3)) * jnp.sqrt(sigma_sq)

        samples = molecule_params.atom_positions[nuclei_ids] + delta_r_nuc

        diffs = samples[:, None] - molecule_params.atom_positions[None, :]

        p_gaussian = 1 / (jnp.sqrt(2 * jnp.pi * sigma_sq)**3) * jnp.exp(-jnp.linalg.norm(diffs, axis=-1)**2 / (2 * sigma_sq))
        p_nuclei = molecule_params.nuclear_charges / jnp.sum(molecule_params.nuclear_charges)
        p_sample = jnp.einsum('j,ij->i', p_nuclei, p_gaussian)

        return samples, p_sample

    return sampling_fn

def sample_pairing(n_samples: int):
    n = n_samples
    n_half = n // 2

    id1 = jnp.arange(n_half)
    id2 = jnp.arange(n_half, n)

    length = len(id1)
    assert length == len(id2)

    return id1, id2, length


def get_e_j_and_J_fn(eri_params) -> Tuple[Callable, Callable]:

    id1, id2, sqrt_n_pairs = sample_pairing(eri_params["n_samples"])
    n_pairs = sqrt_n_pairs**2

    @partial(jax.custom_jvp, nondiff_argnums=(1,))
    def delta_e_j_fn(density_matrix: Array,
                     fock_tensors: FockTensors) -> float:

        initial_density = jnp.einsum('uv,iu,iv->i',
                                fock_tensors.initial_density_matrix,
                                fock_tensors.mc_ao_values,
                                fock_tensors.mc_ao_values)
        density = jnp.einsum('uv,iu,iv->i',
                                density_matrix,
                                fock_tensors.mc_ao_values,
                                fock_tensors.mc_ao_values)
        density_difference = (density - initial_density)

        C = fock_tensors.weight_tensor

        out =  jnp.einsum('ij, i, j', C,
                            initial_density[id1],
                            density_difference[id2])

        out += jnp.einsum('ij, i, j', C,
                            density_difference[id1],
                            density[id2])

        return 0.5 * out / n_pairs

    def _contraction_fn(fock_tensors: FockTensors,
                            T: jax.Array) -> Callable:

        ao_values = fock_tensors.mc_ao_values
        C = fock_tensors.weight_tensor

        out =  jnp.einsum('ij, iu, uv, iv, jk, jl -> kl',
                            C,
                            ao_values[id1],
                            T,
                            ao_values[id1],
                            ao_values[id2],
                            ao_values[id2])

        out += jnp.einsum('ij, ju, uv, jv, ik, il -> kl',
                            C,
                            ao_values[id2],
                            T,
                            ao_values[id2],
                            ao_values[id1],
                            ao_values[id1])

        return out

    @partial(jax.custom_jvp, nondiff_argnums=(1,))
    def J_fn(density_matrix: Array,
             fock_tensors: FockTensors):

        T = density_matrix - fock_tensors.initial_density_matrix
        out = _contraction_fn(fock_tensors, T)
        out = fock_tensors.J_0 + 0.5 * out / n_pairs

        return out

    @delta_e_j_fn.defjvp
    def delta_e_j_jvp(fock_tensors: FockTensors, primals, tangents):
        (density_matrix,) = primals
        (T,) = tangents
        delta_e_f = delta_e_j_fn(density_matrix, fock_tensors)
        J = J_fn(density_matrix, fock_tensors)
        tangent_out = jnp.vdot(J, T)
        return delta_e_f, tangent_out

    @J_fn.defjvp
    def J_jvp(fock_tensors: FockTensors, primals, tangents):
        # TODO: Avoid recomputations
        (density_matrix,) = primals
        (T,) = tangents
        J = J_fn(density_matrix, fock_tensors)
        tangent_out = _contraction_fn(fock_tensors, T)
        tangent_out = 0.5 * tangent_out / n_pairs
        return J, tangent_out

    J_fn2 = jax.grad(delta_e_j_fn)

    return delta_e_j_fn, J_fn2


def get_gridbased_electron_density_sampling_fn(sampling_grid: Grid,
                                               hparams: Dict) -> Callable:
    """
    Returns a function that samples the electron density on a grid
    """
    n_samples = hparams["coulomb_mc"]["n_samples"]
    grid_spacing = sampling_grid.grid_spacing

    def voxel_id_to_coords(voxel_id: int) -> Tuple[int, int, int]:
        lin_length = sampling_grid.shape[0]
        i = (voxel_id // lin_length) % lin_length
        j = voxel_id // (lin_length ** 2)
        k = voxel_id % lin_length

        R = jnp.stack([i, j, k]).T * grid_spacing - sampling_grid.cutoff
        return R

    def electron_density_sampling_fn(density_matrix: Array,
                                     ao_values: AoValues,
                                     random_key: jax.random.PRNGKey) -> Array:
        """
        Samples the electron density on a grid
        """
        key1, key2 = jax.random.split(random_key)
        density = density_on_grid(ao_values,
                                  density_matrix,
                                  sampling_grid.shape,
                                  include_grad=False,
                                  include_kinetic_energy_density=False,)

        voxel_sample_ids = jax.random.categorical(key1,
                                                jnp.log(density.flatten()),
                                                shape=(n_samples,))

        in_voxel_perturbation = jax.random.uniform(key2,
                                           shape=(n_samples, 3),
                                           minval=- grid_spacing / 2,
                                           maxval=  grid_spacing / 2)



        samples = voxel_id_to_coords(voxel_sample_ids) + in_voxel_perturbation

        return samples

    return electron_density_sampling_fn




# @partial(jax.jit, static_argnames=("unnormalized",))
# def weights_fn(p_samples: Array,
#                density_matrix: Array,
#                ao_values: Array,
#                n_electrons: int,
#                unnormalized = False) -> Array:
#     density = jnp.einsum('uv,iu,iv->i',
#                         density_matrix,
#                         ao_values,
#                         ao_values)

#     p_true = density if unnormalized else density / n_electrons

#     weights = p_true / p_samples
#     return weights


# @partial(jax.jit, donate_argnames=("weights1", "weights2"))
# def calculate_e_j_block(sample_block: jax.Array,
#                         weights1: jax.Array,
#                         weights2: jax.Array) -> float:
#     block_size = len(sample_block)
#     # TODO: avoid unnecessary recomputation of r
#     r = jnp.linalg.norm(sample_block[:, None] - sample_block[None, :], axis=-1)
#     r_inv = jnp.where(r == 0, 0, 1 / r)
#     return (r_inv * weights1[:, None] *  weights2[None, :]).sum() \
#             / (block_size * (block_size - 1))


# @partial(jax.jit, static_argnames=("block_size",))
# def calculate_e_j(density_matrix1: Array,
#                   density_matrix2: Array,
#                   fock_tensors: FockTensors,
#                   block_size: int) -> float:

#     n_blocks = len(fock_tensors.mc_samples) // block_size
#     sample_blocks = fock_tensors.mc_samples.reshape(n_blocks, block_size, 3)

#     weights1= weights_fn(fock_tensors.prob_samples,
#                          density_matrix1,
#                          fock_tensors.mc_ao_values,
#                          n_electrons=1,
#                          unnormalized=True)
#     weights2= weights_fn(fock_tensors.prob_samples,
#                          density_matrix2,
#                          fock_tensors.mc_ao_values,
#                          n_electrons=1,
#                          unnormalized=True)
#     weights1_blocks = weights1.reshape(n_blocks, block_size)
#     weights2_blocks = weights2.reshape(n_blocks, block_size)

#     e_js = jax.vmap(calculate_e_j_block, in_axes=(0, 0, 0))\
#             (sample_blocks, weights1_blocks, weights2_blocks)

#     # e_js = jnp.zeros(n_blocks)
#     # for i in range(n_blocks):
#     #     e_js = e_js.at[i].set(calculate_e_j_block(sample_blocks[i], weights1_blocks[i], weights2_blocks[i]))

#     e_j = e_js.mean()
#     return e_j * 0.5




    # N_half = len(samples) // 2
    # r = jnp.linalg.norm(samples[:N_half] - samples[N_half:], axis=-1)
    # r_inv = jnp.where(r == 0, 0, 1 / r)
    # weights = p_delta1[:N_half] * p2[N_half:] \
    #         + p1[:N_half]       * p_delta2[N_half:] \
    #         + p_delta1[:N_half] * p_delta2[N_half:]
    # out = 0.5 * (r_inv * weights).mean()

    # r2 = jnp.linalg.norm(samples[:N_half] - samples[N_half:][::-1], axis=-1)
    # r_inv2 = jnp.where(r2 == 0, 0, 1 / r2)
    # weights2 = p_delta1[:N_half] * p2[N_half:][::-1] \
    #         + p1[:N_half]       * p_delta2[N_half:][::-1] \
    #         + p_delta1[:N_half] * p_delta2[N_half:][::-1]
    # out2 = 0.5 * (r_inv2 * weights2).mean()

    # N_quater = len(samples) // 4
    # r3 = jnp.linalg.norm(samples[:N_half][:N_quater] - samples[:N_half][N_quater:], axis=-1)
    # r_inv3 = jnp.where(r3 == 0, 0, 1 / r3)
    # weights3 = p_delta1[:N_half][:N_quater] * p2[:N_half][N_quater:] \
    #         + p1[:N_half][:N_quater]       * p_delta2[:N_half][N_quater:] \
    #         + p_delta1[:N_half][:N_quater] * p_delta2[:N_half][N_quater:]
    # out3 = 0.5 * (r_inv3 * weights3).mean()

    # r4 = jnp.linalg.norm(samples[N_half:][:N_quater] - samples[N_half:][N_quater:], axis=-1)
    # r_inv4 = jnp.where(r4 == 0, 0, 1 / r4)
    # weights4 = p_delta1[N_half:][:N_quater] * p2[N_half:][N_quater:] \
    #         + p1[N_half:][:N_quater]       * p_delta2[N_half:][N_quater:] \
    #         + p_delta1[N_half:][:N_quater] * p_delta2[N_half:][N_quater:]
    # out4 = 0.5 * (r_inv4 * weights4).mean()

    # r5 = jnp.linalg.norm(samples[:N_half][:N_quater] - samples[:N_half][N_quater:][::-1], axis=-1)
    # r_inv5 = jnp.where(r5 == 0, 0, 1 / r5)
    # weights5 = p_delta1[:N_half][:N_quater] * p2[:N_half][N_quater:][::-1] \
    #         + p1[:N_half][:N_quater]       * p_delta2[:N_half][N_quater:][::-1] \
    #         + p_delta1[:N_half][:N_quater] * p_delta2[:N_half][N_quater:][::-1]
    # out5 = 0.5 * (r_inv5 * weights5).mean()

    # r6 = jnp.linalg.norm(samples[N_half:][:N_quater] - samples[N_half:][N_quater:][::-1], axis=-1)
    # r_inv6 = jnp.where(r6 == 0, 0, 1 / r6)
    # weights6 = p_delta1[N_half:][:N_quater] * p2[N_half:][N_quater:][::-1] \
    #         + p1[N_half:][:N_quater]       * p_delta2[N_half:][N_quater:][::-1] \
    #         + p_delta1[N_half:][:N_quater] * p_delta2[N_half:][N_quater:][::-1]
    # out6 = 0.5 * (r_inv6 * weights6).mean()

    # return (out + out2 + (out3 + out4) / 2 + (out5 + out6) / 2) / 4





# def get_electron_density_importance_sampling_fn2(hparams: Dict) -> Callable:
#     n_samples = hparams["coulomb_mc"]["n_samples"]

#     def sampling_fn(molecule_params: MoleculeParams,
#                                                 random_key: jax.random.PRNGKey) -> Array:

#         key1, key2, key3 = jax.random.split(random_key, 3)

#         nuclei_ids = jax.random.categorical(
#                             key1,
#                             jnp.log(molecule_params.nuclear_charges),
#                             shape=(n_samples,)
#                         )

#         sigma_sq_nuc = 0.5
#         delta_r_nuc = jax.random.normal(key2, shape=(n_samples, 3)) * jnp.sqrt(sigma_sq_nuc)

#         samples = molecule_params.atom_positions[nuclei_ids] + delta_r_nuc

#         diffs = samples[:, None] - molecule_params.atom_positions[None, :]

#         sigma_sq_elec = 1
#         delta_r_elec = jax.random.normal(key3, shape=(n_samples, 3)) * jnp.sqrt(sigma_sq_elec)

#         samples = jnp.stack([samples, samples + delta_r_elec])

#         # p_laplacian = (1 / 4 * jnp.pi) * jnp.exp(-jnp.linalg.norm(diffs, axis=-1))
#         p_gaussian_nuc = 1 / (jnp.sqrt(2 * jnp.pi * sigma_sq_nuc)**3) * jnp.exp(-jnp.linalg.norm(diffs, axis=-1)**2 / (2 * sigma_sq_nuc))
#         p_nuclei = molecule_params.nuclear_charges / jnp.sum(molecule_params.nuclear_charges)
#         p_gaussian_elec = 1 / (jnp.sqrt(2 * jnp.pi * sigma_sq_elec)**3) * jnp.exp(-jnp.linalg.norm(delta_r_elec, axis=-1)**2 / (2 * sigma_sq_elec))
#         # p_gamma = jax.scipy.stats.gamma.pdf(r, a=1) / (4 * jnp.pi)
#         p_sample = jnp.einsum('j,ij->i', p_nuclei, p_gaussian_nuc) * p_gaussian_elec

#         return samples, p_sample

#     @jax.jit
#     def weights_fn(p_sample: Array,
#                    density_matrix: Array,
#                    ao_values1: Array,
#                    ao_values2: Array,
#                    n_electrons: int) -> Array:
#         density1 = jnp.einsum('uv,iu,iv->i',
#                          density_matrix,
#                          ao_values1,
#                          ao_values1)

#         density2 = jnp.einsum('uv,iu,iv->i',
#                          density_matrix,
#                          ao_values2,
#                          ao_values2)

#         p_true = (density1 * density2) / (n_electrons**2)

#         weights = p_true / p_sample
#         return weights

#     return sampling_fn, weights_fn


# @partial(jax.jit, donate_argnames=("weights"))
# def calculate_e_j2(samples: Array, weights:Array, n_electrons: int) -> float:
#     r = jnp.linalg.norm(samples[0] - samples[1], axis=-1)
#     e_j = (1 / r * weights).mean()
#     return e_j * 0.5 * n_electrons**2


        # charges = molecule_params.nuclear_charges[nuclei_ids][:,None]

        # r = jnp.abs(jax.random.laplace(key2, shape=(n_samples,)))
        # phi = jax.random.uniform(key3, shape=(n_samples,), maxval=2*jnp.pi)
        # cos_theta = jax.random.uniform(key4, shape=(n_samples,), minval=-1, maxval=1)
        # theta = jnp.arccos(cos_theta)
        # x = r * jnp.sin(theta) * jnp.cos(phi)
        # y = r * jnp.sin(theta) * jnp.sin(phi)
        # z = r * jnp.cos(theta)
        # delta_r_nuc = jnp.stack([x, y, z], axis=-1)

# def  sample_xn_gaussian(
#     i: int,
#     alpha: Float[Array, '...'],
#     n_samples: int,
#     random_key: jax.random.PRNGKey):
#     """
#     Samples a one-dimensional Cartesian Gaussian basis function.
#     x^i exp(-alpha x^2)

#     https://en.wikipedia.org/wiki/List_of_integrals_of_Gaussian_functions

#     Args:
#         i (int): angular momentum quantum number
#         alpha (Float[Array, '...']): Gaussian exponent
#         n_samples (int): number of samples
#         random_key (jax.random.PRNGKey): random number generator
#     """
#     # uniform random samples
#     samples = jax.random.uniform(random_key, shape=(n_samples,))

#     # Compute the normalization
#     normalization = jnp.sqrt(jax.scipy.special.factorial(i) \
#                     / jax.scipy.special.factorial(2 * i))  # TODO: check this


#     return



# def sample_cartesian_gaussian(
#     ijk: Integer[Array, '...'],
#     alpha: Float[Array, '...'],
#     n_samples: int,
#     random_key: jax.random.PRNGKey):
#     """
#     Samples a Cartesian Gaussian basis function.
#     x^i y^j z^k exp(-alpha r^2)

#     Note the symmetry under permutations of i, j, and k.

#     Args:
#         ijk (int): angular momentum quantum numbers
#         alpha (Float[Array, '...']): Gaussian exponent
#         n_samples (int): number of samples
#         random_key (jax.random.PRNGKey): random number generator
#     """
#     samples = jax.random.normal(random_key, shape=(n_samples, 3))

#     # Compute the normalization
#     normalization = jnp.sqrt(jax.scipy.special.factorial(ijk) \
#                     / jax.scipy.special.factorial(2 * ijk))

#     # Compute the Gaussian
#     gaussian = jnp.exp(-alpha * jnp.sum(samples ** 2, axis=-1))

#     # Compute the Cartesian basis function
#     basis = normalization * c * gaussian

#     return basis, samples