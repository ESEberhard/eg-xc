import functools
import jax
import jax.numpy as jnp
import numpy as onp
import math
import pyscf
import scipy.linalg
from pyscf import dft, df

from mldft.grids import GridPreprocessor
from mldft.utils.typing import (
    MoleculeParams,
    MoleculeSolverParams,
    FockTensors,
    HostFockTensors,
    HostMoleculeSolverParams,
)
from mldft.scf.atomic_orbitals import make_gto_basis, make_gto_bases
from mldft.systems.elements import CHARGE_TO_PERIOD
from mldft.systems.grid import _PAD_POSITION, get_partition, precompute_atom_tab

from typing import Dict, Any, Tuple, Optional


@functools.cache
def aos_per_period(basis: str):
    atoms = [2, 10, 18]
    result = {}
    for i, a in enumerate(atoms):
        m = pyscf.gto.M(atom=[(a, (0, 0, 0))], basis=basis)
        result[i + 1] = m.nao
    return result


@functools.cache
def aux_aos_per_period(basis: str):
    atoms = [2, 10, 18]
    result = {}
    for i, a in enumerate(atoms):
        m = pyscf.gto.M(atom=[(a, (0, 0, 0))], basis=basis)
        auxmol = df.addons.make_auxmol(m, "weigend")
        result[i + 1] = auxmol.nao
    return result


@functools.cache
def quad_per_period(level: int = 1):
    return {
        p: int(x[-1].shape[-1] * 1.05) # some arbitrary buffer
        for p, x in precompute_atom_tab(level).items()
    }


def pad_periods(
    periods,
    atom_positions,
    occupancy,
    nuclear_charges,
    density_matrix,
    tensors,
    quadrature_points,
    quadrature_weights,
    basis: str,
    num_pad: int = 9,
):
    periods = onp.array(periods)
    unique_periods, period_counts = onp.unique(periods, return_counts=True)
    # unique periods is sorted ascending rather than descending, invert at the end!
    to_pad = (num_pad - period_counts % num_pad) % num_pad
    new_periods = []
    for p, pad in zip(unique_periods, to_pad):
        new_periods.append(onp.full(pad, p, dtype=int))
    new_periods = onp.concatenate(new_periods)
    mask = onp.ones_like(periods, dtype=bool)
    mask = onp.concatenate([mask, onp.zeros_like(new_periods, dtype=bool)])
    # Atoms
    out_periods = onp.concatenate([periods, new_periods])
    out_atom_order = onp.argsort(-out_periods, kind="stable")

    # Quadrature
    nquad_per_period = quad_per_period()
    n_out_quad = sum([nquad_per_period[p] for p in out_periods])

    # AOs
    _aos_per_period = aos_per_period(basis)
    n_new_aos = sum([_aos_per_period[p] for p in new_periods])
    ao_periods = onp.concatenate(
        [onp.full((_aos_per_period[p],), p) for p in out_periods]
    )
    out_ao_order = onp.argsort(-ao_periods, kind="stable")

    # AUX AOs
    _aux_per_period = aux_aos_per_period(basis)
    n_new_aux = sum([_aux_per_period[p] for p in new_periods])
    aux_periods = onp.concatenate(
        [onp.full((_aux_per_period[p],), p) for p in out_periods]
    )
    out_aux_order = onp.argsort(-aux_periods, kind="stable")
    
    # Padding everything
    # There should a mask for the atoms?!
    atom_positions = onp.concatenate(
        [atom_positions, onp.zeros((len(new_periods), 3))], axis=0
    )
    # TODO: fix with actual atoms?
    nuclear_charges = onp.concatenate(
        [nuclear_charges, onp.zeros(len(new_periods), dtype=nuclear_charges.dtype)]
    )
    atom_mask = onp.concatenate([
        onp.ones_like(periods, dtype=bool),
        onp.zeros_like(new_periods, dtype=bool)
    ])

    ao_mask = onp.concatenate([
        onp.ones(len(occupancy), dtype=bool),
        onp.zeros(n_new_aos, dtype=bool)
    ])
    occupancy = onp.concatenate(
        [occupancy, onp.zeros(n_new_aos, dtype=occupancy.dtype)]
    )
    density_matrix = scipy.linalg.block_diag(
        density_matrix, onp.zeros((n_new_aos, n_new_aos), dtype=density_matrix.dtype)
    )

    overlap = scipy.linalg.block_diag(
        tensors.overlap, onp.eye(n_new_aos, dtype=tensors.overlap.dtype)
    )
    # TODO: Is this right? - very high penalty for new AOs
    # we must pad non-identical eigenvalues to have an derivative of eigh
    h_core = scipy.linalg.block_diag(
        tensors.h_core, onp.eye(n_new_aos, dtype=tensors.h_core.dtype) * (100 + onp.arange(1, n_new_aos + 1))
    )
    ints_3c2e, ints_2c2e = tensors.df_tensor
    nao, _, naux = ints_3c2e.shape
    ints_3c2e = onp.concatenate(
        [ints_3c2e, onp.zeros((n_new_aos, nao, naux), ints_3c2e.dtype)], axis=0
    )
    ints_3c2e = onp.concatenate(
        [ints_3c2e, onp.zeros((nao + n_new_aos, n_new_aos, naux), ints_3c2e.dtype)],
        axis=1,
    )
    ints_3c2e = onp.concatenate(
        [
            ints_3c2e,
            onp.zeros((nao + n_new_aos, nao + n_new_aos, n_new_aux), ints_3c2e.dtype),
        ],
        axis=2,
    )
    aux_mask = onp.concatenate([
        onp.ones(naux, dtype=bool),
        onp.zeros(n_new_aux, dtype=bool)
    ])
    # TODO: I am not sure about this one tbh.
    # We need a decomposition of this matrix, so putting to zero is probably not the best idea
    ints_2c2e = scipy.linalg.block_diag(
        ints_2c2e, onp.eye(n_new_aux, dtype=ints_2c2e.dtype)
    )

    # Sorting everything correctly
    # Atoms
    periods = tuple(onp.array(out_periods)[out_atom_order])
    atom_positions = atom_positions[out_atom_order]
    nuclear_charges = nuclear_charges[out_atom_order]

    # AOs
    density_matrix = density_matrix[out_ao_order][:, out_ao_order]
    overlap = overlap[out_ao_order][:, out_ao_order]
    h_core = h_core[out_ao_order][:, out_ao_order]

    # AUX AOs
    ints_3c2e = ints_3c2e[out_ao_order][:, out_ao_order][:, :, out_aux_order]
    ints_2c2e = ints_2c2e[out_aux_order][:, out_aux_order]

    # Quadrature
    if quadrature_points is not None:
        n_quad = quadrature_weights.shape[0]
        quadrature_points = onp.concatenate(
            [
                quadrature_points,
                onp.full(
                    (n_out_quad - n_quad, 3), _PAD_POSITION, dtype=quadrature_points.dtype
                ),
            ],
            axis=0,
        )
        quadrature_weights = onp.concatenate(
            [
                quadrature_weights,
                onp.zeros((n_out_quad - n_quad,), dtype=quadrature_weights.dtype),
            ],
            axis=0,
        )
        quad_mask = onp.concatenate([
            onp.ones(n_quad, dtype=bool),
            onp.zeros(n_out_quad - n_quad, dtype=bool)
        ])
    else:
        quad_mask = None

    tensors = HostFockTensors(
        overlap,
        h_core,
        elect_rep_integrals=None,
        df_tensor=(ints_3c2e, ints_2c2e),
    )
    atom_mask = atom_mask[out_atom_order]
    ao_mask = ao_mask[out_ao_order]
    aux_mask = aux_mask[out_aux_order]
    return (
        periods,
        atom_positions,
        nuclear_charges,
        occupancy,
        density_matrix,
        tensors,
        quadrature_points,
        quadrature_weights,
        (atom_mask, ao_mask, aux_mask, quad_mask),
    )


def molecule_params_factory(
    molecule,
    molecule_id: int,
    grid_preprocessor: GridPreprocessor,
    hparams: Dict[str, Any],
    rng: Optional[onp.random.Generator],
    elect_rep_integrals: Optional[onp.ndarray],
    density_fitting_tensor: Optional[onp.ndarray],
    initial_density_matrix: Optional[onp.ndarray],
    interpolate_intial_density: bool,
    fixed_intial_density_interpolation: Optional[float],
    Z_to_e_xc: Optional[Dict[int, float]],
    dataset: str = "",
    pad_quadrature: bool = False,
) -> Tuple[MoleculeParams, HostMoleculeSolverParams]:
    precision = hparams["precision"]["general"]

    atom_positions = onp.array(molecule.atom_coords(), dtype=precision)
    nuclear_charges = onp.array(molecule.atom_charges(), dtype=onp.int16)

    molecule_params = MoleculeParams(
        molecule_id,
        atom_positions,
        molecule.nao,
        molecule.nelectron,
        nuclear_charges,
        dataset,
    )

    quadrature_points = None
    quadrature_weights = None
    ao_molecule = None
    molecule_ao_values = None
    atom_ao_values = None
    quadrature_points, quadrature_weights = grid_preprocessor.standard_integration_grid(
        molecule, return_ao=False
    )

    mean_field = dft.RKS(molecule, xc="")
    assert molecule.nelectron % 2 == 0
    N_occ = molecule.nelectron // 2
    occupancy = onp.array([2.0] * N_occ + [0.0] * (molecule.nao - N_occ), dtype="int16")

    S = onp.array(mean_field.get_ovlp(), dtype=onp.float64)
    H = onp.array(mean_field.get_hcore(), dtype=onp.float64)
    df_tensor = density_fitting_tensor

    if initial_density_matrix is None:
        P_0 = onp.array(mean_field.get_init_guess(key="minao"), dtype=onp.float64)
    else:
        if interpolate_intial_density:
            if fixed_intial_density_interpolation is None:
                # # FIXME: presently the random number sequence is the same for
                # # each worker in the multiprocessing case
                # p = (1 + rng.uniform()) / 2
                p = (1 + onp.random.uniform()) / 2
            else:
                p = fixed_intial_density_interpolation
            P_A = onp.array(mean_field.get_init_guess(key="minao"), dtype=onp.float64)
            P_B = initial_density_matrix.astype(precision)
            P_0 = (1 - p) * P_A + p * P_B
        else:
            P_0 = initial_density_matrix.astype(precision)
    density_matrix = P_0

    tensors = HostFockTensors(
        S,
        H,
        elect_rep_integrals,
        df_tensor=df_tensor,
    )
    atom_base_xc = None
    periods = tuple(CHARGE_TO_PERIOD[c] for c in nuclear_charges)
    # if pad_quadrature:
    #     quadrature_points = pad(quadrature_points, _PAD_POSITION)
    #     quadrature_weights = pad(quadrature_weights, 0)

    if pad_quadrature:
        (
            periods,
            atom_positions,
            nuclear_charges,
            occupancy,
            density_matrix,
            tensors,
            quadrature_points,
            quadrature_weights,
            masks,
        ) = pad_periods(
            periods=periods,
            atom_positions=atom_positions,
            occupancy=occupancy,
            nuclear_charges=nuclear_charges,
            density_matrix=density_matrix,
            tensors=tensors,
            quadrature_points=quadrature_points,
            quadrature_weights=quadrature_weights,
            basis=hparams["basis"],
        )
    else:
        masks = (
            onp.ones_like(nuclear_charges, dtype=bool),
            onp.ones_like(occupancy, dtype=bool),
            onp.ones(df_tensor[-1].shape[-1], dtype=bool),
        )
        if quadrature_points is not None:
            masks += (onp.ones_like(quadrature_weights, dtype=bool),)

    molecule_solver_params = HostMoleculeSolverParams(
        molecule_id,
        atom_positions,
        molecule.nelectron,
        molecule.energy_nuc(),
        occupancy,
        nuclear_charges,
        periods,
        density_matrix,
        molecule_ao_values,
        atom_ao_values,
        tensors,
        atom_base_xc,
        quadrature_points,
        None,
        quadrature_weights,
        ao_molecule,
        masks,
    )
    return molecule_params, molecule_solver_params


def __pad_gnn_input(
    params: HostMoleculeSolverParams,
    atom_ao_vals: jax.Array,
    max_number_of_atoms: Optional[int],
):
    N_atoms = params.atom_positions.shape[0]
    if max_number_of_atoms is None:
        padding_size = 0
    else:
        padding_size = max_number_of_atoms - N_atoms

    atom_pos = jnp.pad(params.atom_positions, ((0, padding_size), (0, 0)))
    nuc_charges = jnp.pad(jnp.asarray(params.nuclear_charges), (0, padding_size))
    atom_mask = jnp.array(
        [
            True,
        ]
        * N_atoms
        + [
            False,
        ]
        * padding_size
    )

    if atom_ao_vals is not None:
        ao_values = jnp.concatenate(
            [atom_ao_vals, jnp.tile(atom_ao_vals[0][None], (padding_size, 1, 1, 1, 1))],
            axis=0,
        )
    else:
        ao_values = None
    return atom_pos, nuc_charges, atom_mask, ao_values


def pad(x, val, chunk_size=1000):
    if x is None:
        return x
    if isinstance(x, onp.ndarray):
        xp = onp
    else:
        xp = jnp
    n_grid = x.shape[0]
    padding_size = chunk_size * math.ceil(n_grid / chunk_size) - n_grid
    return xp.concatenate(
        [x, val * xp.ones((padding_size, *x.shape[1:]), dtype=x.dtype)], axis=0
    )


def __pad_quadrature(
    positions: Optional[jax.Array | onp.ndarray],
    ao_vals: Optional[jax.Array | onp.ndarray],
    weights: Optional[jax.Array | onp.ndarray],
    chunk_size: int = 2_000,
) -> Tuple[jax.Array | onp.ndarray, jax.Array | onp.ndarray]:
    return jax.tree_util.tree_map(
        functools.partial(pad, chunk_size=chunk_size),
        (positions, ao_vals, weights),
        (_PAD_POSITION, 0.1, 0),
    )


def __preprocess_ao_values(
    params: HostMoleculeSolverParams, use_meta_gga: bool, hparams: Dict[str, Any]
):
    gnn_ao_gradients_required = (
        hparams["density_features"]["include_grad"]
        or hparams["density_features"]["include_kinetic_energy_density"]
    )

    if params.molecule_ao_values is not None:
        mol_ao_vals = jnp.array(params.molecule_ao_values)
        atm_ao_vals = jnp.array(params.atom_ao_values)
    else:
        mol_ao_vals = None
        atm_ao_vals = None

    quad_weights, quad_ao_vals, quad_positions = None, None, None
    if use_meta_gga:
        quad_positions = jnp.array(params.quadrature_points)
        quad_ao_vals = jnp.array(params.quadrature_ao_values)
        quad_weights = jnp.array(params.quadrature_weights)

    if params.molecule is None:
        return mol_ao_vals, atm_ao_vals, quad_positions, quad_weights, quad_ao_vals
    else:
        basis_fn = make_gto_basis(params.molecule)
        basis_and_grad_fn = make_gto_basis(params.molecule, deriv=1)

        basis_fn = jax.jit(basis_fn)
        basis_and_grad_fn = jax.jit(basis_and_grad_fn)

        mol_ao_vals = basis_fn(mol_ao_vals.reshape(-1, 3))[None, ...]

        atom_grid_coords = atm_ao_vals
        atm_list = []

        if gnn_ao_gradients_required:
            atm_ao_val_fn = basis_and_grad_fn
        else:
            atm_ao_val_fn = lambda r: basis_fn(r)[None, ...]

        for atom in range(atom_grid_coords.shape[0]):
            res_list = []
            for resolution in range(atom_grid_coords.shape[1]):
                coords = atom_grid_coords[atom, resolution]
                res_list.append(atm_ao_val_fn(coords.reshape(-1, 3)))
            atm_list.append(res_list)
        atm_ao_vals = jnp.array(atm_list)

        if use_meta_gga:
            quad_ao_vals = basis_and_grad_fn(quad_ao_vals)

        return mol_ao_vals, atm_ao_vals, quad_positions, quad_weights, quad_ao_vals


@functools.partial(jax.jit, static_argnums=(3, 4))
def get_ao_values(points, nuc_pos, nuc_charges, periods, basis, point_mask=None):
    ao_fns = {
        period: make_gto_bases(period, deriv=1, basis=basis) for period in set(periods)
    }

    order = onp.argsort(periods, kind="stable")
    inv_order = onp.argsort(order, kind="stable")
    periods = onp.array(periods)[order]
    nuc_pos = nuc_pos[order]
    nuc_charges = nuc_charges[order]
    ao_values = []
    for p in onp.unique(periods):
        mask = periods == p
        ao_fn = ao_fns[p]
        ao_values += list(
            jax.vmap(ao_fn, in_axes=(None, 0, 0))(
                points, nuc_pos[mask], nuc_charges[mask]
            )
        )
    ao_values = [ao_values[i] for i in inv_order]
    # 4 x n_points x n_ao
    # 4 is (val, deriv_x, deriv_y, deriv_z)
    result = jnp.transpose(jnp.concatenate(ao_values, axis=-1), (1, 0, 2))
    # for padded points we just set everything to 0.1 to avoid NaNs
    if point_mask is not None:
        result = jnp.where(
            point_mask[None, :, None], result, jnp.full_like(result, 0.1)
        )
    return result


@functools.partial(jax.jit, static_argnums=(1, 2, 3))
def preprocess_params(
    params: HostMoleculeSolverParams,
    hparams: Dict[str, Any],
    max_number_of_atoms: Optional[int],
    pad_quadrature_grid: bool,
) -> MoleculeSolverParams:
    tensors = params.tensors
    has_eri = tensors.elect_rep_integrals is not None
    initial_density_matrix = jnp.array(params.initial_density_matrix)

    atom_mask = params.masks[0]
    ao_mask = params.masks[1]
    aux_mask = params.masks[2]
    
    # Compute grid
    if params.quadrature_points is None:
        quadrature_points, quadrature_weights, quadrature_mask = get_partition(
            params.nuclear_charges,
            params.periods,
            params.atom_positions,
            atom_mask,
        )
        params = params.replace(
            quadrature_points=quadrature_points,
            quadrature_weights=quadrature_weights,
        )
    else:
        quadrature_mask = params.masks[-1]

    if isinstance(tensors.df_tensor, tuple):
        ints_3c2e, ints_2c2e = tensors.df_tensor
        nao, _, naux = ints_3c2e.shape
        ints_3c2e = ints_3c2e.reshape(nao * nao, naux)
        cho = jax.scipy.linalg.cholesky(ints_2c2e)
        df_tensor = jax.scipy.linalg.solve_triangular(
            cho.T, ints_3c2e.T, lower=True
        ).reshape(naux, nao, nao)
        df_tensor = df_tensor * ao_mask * ao_mask[:, None] * aux_mask[:, None, None]
        tensors = tensors.replace(df_tensor=df_tensor)

    # Compute AOs
    quadrature_ao_values = get_ao_values(
        params.quadrature_points,
        params.atom_positions,
        params.nuclear_charges,
        params.periods,
        hparams["basis"],
        quadrature_mask,
    ).astype(jnp.float32)
    quadrature_ao_values *= ao_mask
    params = params.replace(quadrature_ao_values=quadrature_ao_values)

    using_hcb = hparams["eri_calculation"]["using_host_callbacks"]

    fock_tensors = FockTensors(
        jnp.array(tensors.overlap),  # shape varies for different molecules
        jnp.array(tensors.h_core),  # shape varies for different molecules
        params.id if using_hcb else None,
        jnp.array(tensors.elect_rep_integrals)
        if has_eri
        else None,  # shape varies for different molecules
        jnp.array(tensors.df_tensor) if tensors.df_tensor is not None else None,
    )
    # use_metaGGA = hparams["model"]["use_metaGGA"]

    quad_positions = params.quadrature_points
    quad_weights = params.quadrature_weights
    quad_ao_vals = quadrature_ao_values

    atom_positions = params.atom_positions
    nuclear_charges = params.nuclear_charges
    # _atom_chunk = 4
    # atom_mask = pad(atom_mask, False, _atom_chunk)
    # atom_positions = pad(atom_positions, 0, _atom_chunk)
    # nuclear_charges = pad(nuclear_charges, 0, _atom_chunk)
    atom_ao_vals = None
    mol_ao_vals = None

    # mol_ao_vals, atom_ao_vals, quad_positions, quad_weights, quad_ao_vals = (
    #     __preprocess_ao_values(params, use_metaGGA, hparams)
    # )
    # atom_positions, nuclear_charges, atom_mask, atom_ao_vals = __pad_gnn_input(
    #     params, atom_ao_vals, max_number_of_atoms
    # )

    # We now pad outside
    # if pad_quadrature_grid:
    #     quad_positions, quad_ao_vals, quad_weights = __pad_quadrature(
    #         quad_positions, quad_ao_vals, quad_weights
    #     )

    out = MoleculeSolverParams(
        params.id,
        atom_positions,  # constant shape for all molecules due to padding
        atom_mask,
        params.n_electrons,
        jnp.array(params.e_nuclei, dtype=jnp.float32),
        jnp.array(params.occupancy),  # shape varies for different molecules
        nuclear_charges,  # constant shape for all molecules due to padding
        initial_density_matrix,  # shape varies for different molecules
        mol_ao_vals,  # shape varies for different molecules
        atom_ao_vals,  # constant shape for all molecules due to padding
        fock_tensors,  # shapes vary for different molecules
        jnp.array(params.atom_base_xc, dtype=jnp.float32)
        if params.atom_base_xc is not None
        else None,
        quad_positions,
        quad_ao_vals,
        quad_weights,
        ao_mask,
    )
    return out
