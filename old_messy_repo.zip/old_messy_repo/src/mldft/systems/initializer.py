import os
import yaml
import dill
import jax.numpy as jnp
import numpy as onp
from pyscf import gto, dft
from tqdm import tqdm

from mldft.systems.atom_densities import DensityFn, get_radial_density_fn
from mldft.systems.elements import ELEMENT_BY_SYMBOL, ATOMIC_NUM_BY_SYMBOL
from numpy.typing import ArrayLike
from typing import Dict, Optional, Any


CustomDatasetBase = Any


class ElementInitializer:
    """
    Class to compute the XC energy per atom for a given set of elements and
    to store the converged quantities (total energy and density matrix) for
    each element.
    """

    pyscf_mols = None

    def __init__(self, hparams: Dict[str, Any], atom_data_dir: str):
        self.elements = hparams["model"]["atoms"]["symbols"]
        self.n_elements = len(self.elements)
        self.basis = hparams["model"]["atoms"]["basis"]
        self.xc = hparams["model"]["atoms"]["xc"]
        self.cutoff = 15  # density below floating point precision after this distance
        self.n_radial = hparams["model"]["atoms"]["n_radial"]
        self.n_angular = hparams["model"]["atoms"]["n_angular"]
        self.n_resolutions = hparams["density_grids"]["n_resolutions"]
        self.precision = hparams["precision"]["general"]
        self.include_grad = hparams["density_features"]["include_grad"]
        self.regression = hparams["model"]["atoms"]["regression"]
        self.atom_data_dir = atom_data_dir
        os.makedirs(self.atom_data_dir, exist_ok=True, mode=0o777)
        self._compute_converged_quantities()

    def get_xc_energy_per_atom(
        self,
        dataset: Optional[CustomDatasetBase] = None,
        train_indices: Optional[ArrayLike] = None,
    ) -> Dict[int, float]:
        """
        Returns a dictionary mapping atomic numbers to the XC energy per atom.
        """
        print("Estimating the XC energy of individual atoms...")
        if self.regression:
            return self._xc_energy_per_atom_from_linear_regression(
                dataset, train_indices
            )
        else:
            return self._compute_xc_energy_per_atom()

    def _compute_converged_quantities(self) -> None:
        self.density_matrices = {}
        total_energy_path = os.path.join(
            self.atom_data_dir, self.basis, self.xc, "total_energies.yaml"
        )
        density_matrices_path = os.path.join(
            self.atom_data_dir, self.basis, self.xc, "density_matrices"
        )
        if os.path.exists(total_energy_path) and os.path.exists(
            density_matrices_path
        ):  # FIXME: might cause an error due to unitilialised self.pyscf_mols
            print("Loading converged quantities...")
            with open(total_energy_path, "r") as f:
                self.total_energies = yaml.safe_load(f)
            for e in self.elements:
                e_dm_path = os.path.join(density_matrices_path, e + ".npy")
                self.density_matrices[e] = onp.load(e_dm_path)
        else:
            os.makedirs(density_matrices_path, mode=0o777)
            self.total_energies = {}
            self.pyscf_mols = {}
            for e in self.elements:
                atom = ELEMENT_BY_SYMBOL[e]
                mf = atom.to_dft(self.basis, self.xc)
                self.pyscf_mols[e] = mf.mol
                mf.kernel()
                self.density_matrices[e] = mf.make_rdm1()
                e_dm_path = os.path.join(density_matrices_path, e + ".npy")
                onp.save(e_dm_path, self.density_matrices[e])
                self.total_energies[e] = float(mf.energy_tot())
            with open(total_energy_path, "w") as f:
                yaml.dump(self.total_energies, f)

    def _compute_xc_energy_per_atom(self) -> Dict[int, float]:
        """
        Compute the XC energy per atom using the converged total energies.
        """
        xc_per_atom_path = os.path.join(
            self.atom_data_dir, self.basis, self.xc, "xc_per_atom.yaml"
        )
        if os.path.exists(xc_per_atom_path):
            print("Loading XC energy per atom...")
            with open(xc_per_atom_path, "r") as f:
                xc_energy_per_atom = yaml.safe_load(f)
        else:
            print("Computing XC energy per atom...")
            xc_energy_per_atom = {}
            for e in self.elements:
                atom = ELEMENT_BY_SYMBOL[e]
                mf = atom.to_dft(self.basis, xc="")  # set xc to zero
                xc_energy = self.total_energies[e] - mf.energy_tot(
                    dm=self.density_matrices[e]
                )
                xc_energy_per_atom[ATOMIC_NUM_BY_SYMBOL[e]] = float(xc_energy)
                print(f"{e} {xc_energy:.6f} Ha")
            with open(xc_per_atom_path, "w") as f:
                yaml.dump(xc_energy_per_atom, f)
        return xc_energy_per_atom

    def _xc_energy_per_atom_from_linear_regression(
        self, dataset: CustomDatasetBase, train_indices: ArrayLike
    ) -> Dict[int, float]:
        """
        Compute the XC energy per atom using a linear regression over the
        whole training set.
        """
        regression_path = os.path.join(
            self.atom_data_dir, self.basis, self.xc, "xc_per_atom_regression.yaml"
        )
        if os.path.exists(regression_path):
            print("Loading XC energy per atom from linear regression...")
            with open(regression_path, "r") as f:
                xc_energy_per_atom = yaml.safe_load(f)
            return xc_energy_per_atom

        print("Computing XC energy per atom from linear regression...")
        n_molecules = len(train_indices)
        element_to_id = {e: i for i, e in enumerate(self.elements)}
        # assemble linear system of equations A x = b
        A = jnp.zeros((n_molecules, self.n_elements), dtype=jnp.int64)
        b = jnp.zeros(n_molecules, dtype=jnp.float64)
        for i, id in enumerate(tqdm(train_indices)):
            mol = gto.M(atom=dataset.get_molecule_string(id), basis=self.basis)
            # calculate XC energy per molecule
            mf = dft.RKS(mol, xc=self.xc)
            mf.kernel()
            P = mf.make_rdm1()
            e1 = mf.energy_tot(dm=P)
            mf.xc = ""
            e2 = mf.energy_tot(dm=P)
            b = b.at[i].set(e1 - e2)
            # count atom types
            mol_charges = mol.atom_charges()
            for e in self.elements:
                A = A.at[i, element_to_id[e]].set(
                    (mol_charges == ATOMIC_NUM_BY_SYMBOL[e]).sum()
                )
        # solve linear system of equations            atom_density_grids[e] = generate_atom_density_grid(

        xc_energy_per_atom, _, _, _ = jnp.linalg.lstsq(A, b)
        out = {}
        for e, i in element_to_id.items():
            out[ATOMIC_NUM_BY_SYMBOL[e]] = float(xc_energy_per_atom[i])
            print(f"{e} {xc_energy_per_atom[i]:.6f} Ha")

        with open(regression_path, "w") as f:
            yaml.dump(out, f)
        return out

    def get_radial_density_fns(self, backend="jax") -> Dict[int, DensityFn]:
        radial_density_function_path = os.path.join(
            self.atom_data_dir, self.basis, self.xc, "radial_density_functions.pkl"
        )
        if os.path.exists(radial_density_function_path):
            print("Loading radial density functions...")
            with open(radial_density_function_path, "rb") as f:
                atom_density_radial_fns = dill.load(f)
        else:
            atom_density_radial_fns = {}
            for e in self.elements:
                if self.pyscf_mols is None:
                    atom = ELEMENT_BY_SYMBOL[e]
                    mol = atom.to_pyscf(self.basis)
                else:
                    mol = self.pyscf_mols[e]
                P = self.density_matrices[e]
                density_fn = get_radial_density_fn(
                    mol, P, self.cutoff, self.n_radial, self.n_angular, backend=backend
                )
                atom_density_radial_fns[ATOMIC_NUM_BY_SYMBOL[e]] = density_fn

            with open(radial_density_function_path, "wb") as f:
                dill.dump(atom_density_radial_fns, f)

        return atom_density_radial_fns

    # def __get_density_grids(self,
    #                       grid_coords: ArrayLike) -> Dict[int, NDArray]:
    #     """
    #     TODO: This function is not used in the current implementation.
    #     Returns a dictionary mapping atomic symbols to the corresponding
    #     atom density grids.
    #     """
    #     atom_density_grids = {}
    #     for e in self.elements:
    #         mol = self.pyscf_mols[e]
    #         P = self.density_matrices[e]
    #         density_fn = get_radial_density_fn(
    #                         mol, P, self.cutoff, self.n_radial, self.n_angular)
    #         if self.include_grad:
    #             density_gradient_fn = get_radial_density_gradient_fn(
    #                         mol, P, self.cutoff, self.n_radial, self.n_angular)
    #         else:
    #             density_gradient_fn = None
    #         density_grid = atom_electron_density_on_grid(
    #                                     grid_coords,
    #                                     self.n_resolutions,
    #                                     density_fn,
    #                                     density_gradient_fn)
    #         atom_density_grids[ATOMIC_NUM_BY_SYMBOL[e]] = \
    #                     onp.array(density_grid).astype(self.precision)

    #     atom_density_grids[0] = onp.zeros_like(
    #         atom_density_grids[ATOMIC_NUM_BY_SYMBOL[self.elements[0]]])

    #     return atom_density_grids
