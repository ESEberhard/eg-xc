import functools
import jax
import jax.numpy as jnp
import numpy as np
import pyscf
from pyscf.dft import radi

# https://github.com/sail-sg/d4ft/blob/main/d4ft/integral/quadrature/grids.py#L118

_PAD_POSITION = 1000


def treutler_atomic_radii_adjust(charges, atomic_radii):
    rad = jnp.sqrt(jnp.asarray(atomic_radii)[charges]) + 1e-200
    rr = rad.reshape(-1, 1) * (1.0 / rad)
    a = 0.25 * (rr.T - rr)
    a = jnp.clip(a, -0.5, 0.5)

    def fadjust(i, j, g):
        g1 = g**2
        g1 -= 1.0
        g1 *= -a[i, j]
        g1 += g
        return g1

    return fadjust


def inter_distance(coords):
    rr = jnp.linalg.norm(coords.reshape(-1, 1, 3) - coords, axis=2)
    return rr.at[jnp.diag_indices(rr.shape[0])].set(0.0)


def original_becke(g):
    g = (3 - g**2) * g * 0.5
    g = (3 - g**2) * g * 0.5
    g = (3 - g**2) * g * 0.5
    return g


def precompute_atom_tab(level=1):
    periods = {
        1: np.arange(1, 3),
        2: np.arange(3, 11),
        3: np.arange(11, 19),
        4: np.arange(19, 37),
    }
    result = {}
    for period, charges in periods.items():
        coords_all = []
        weights_all = []
        masks_all = []
        for c in charges:
            m = pyscf.gto.M(atom=[[c, (0, 0, 0)]], spin=c % 2)
            coords, weights = next(
                iter(pyscf.dft.gen_grid.gen_atomic_grids(m, level=level).values())
            )
            coords_all.append(coords)
            weights_all.append(weights)
            masks_all.append(np.ones_like(weights, dtype=bool))
        max_items = max(len(x) for x in coords_all)
        # pad very far away
        coords_all = np.stack(
            [np.pad(x, ((0, max_items - x.shape[0]), (0, 0)), constant_values=_PAD_POSITION) for x in coords_all]
        )
        weights_all = np.stack(
            [np.pad(x, ((0, max_items - x.shape[0]),)) for x in weights_all]
        )
        masks_all = np.stack(
            [np.pad(x, ((0, max_items - x.shape[0]),)) for x in masks_all]
        )
        result[period] = coords_all, weights_all, masks_all
    return result


@functools.partial(jax.jit, static_argnums=(1, 5, 7, 8))
def get_partition(
    charges,
    periods,
    atom_coords,
    atom_mask=None,
    atom_grids_tab=None,
    radii_adjust=treutler_atomic_radii_adjust,
    atomic_radii=radi.BRAGG_RADII,
    becke_scheme=original_becke,
    concat=True,
):
    if atom_grids_tab is None:
        atom_grids_tab = precompute_atom_tab()
    natom = len(atom_coords)
    if callable(radii_adjust) and atomic_radii is not None:
        f_radii_adjust = radii_adjust(charges, atomic_radii)
    else:
        f_radii_adjust = None
    atm_dist = inter_distance(atom_coords)  # [natom, natom]

    def gen_grid_partition(coords):
        ngrids = coords.shape[0]
        dc = coords[None] - atom_coords[:, None]
        grid_dist = jnp.sqrt(jnp.einsum("ijk,ijk->ij", dc, dc))  # [natom, ngrid]
        pbecke = jnp.ones((natom, ngrids))  # [natom, ngrid]

        ix, jx = jnp.tril_indices(natom, k=-1)

        def pbecke_g(i, j):
            g = 1 / atm_dist[i, j] * (grid_dist[i] - grid_dist[j])
            if f_radii_adjust is not None:
                g = f_radii_adjust(i, j, g)
            g = becke_scheme(g)
            return g

        g = jax.vmap(pbecke_g)(ix, jx)
        pbecke = pbecke.at[ix].mul(0.5 * (1.0 - g))
        pbecke = pbecke.at[jx].mul(0.5 * (1.0 + g))
        return pbecke

    biases = {1: 1, 2: 3, 3: 11, 4: 19}

    coords_all = []
    weights_all = []
    masks_all = []
    for ia, p in enumerate(periods):
        coords, vol, mask = atom_grids_tab[p]
        idx = charges[ia] - biases[p]
        coords = jnp.asarray(coords)[idx]
        vol = jnp.asarray(vol)[idx]
        coords = coords + atom_coords[ia]  # [ngrid, 3]
        pbecke = gen_grid_partition(coords)  # [natom, ngrid]
        if atom_mask is not None:
            pbecke = jnp.where(atom_mask[:, None], pbecke, jnp.zeros_like(pbecke))
        weights = vol * pbecke[ia] * (1.0 / jnp.sum(pbecke, axis=0))
        mask = jnp.asarray(mask)[idx]
        # pad extra points
        coords = jnp.where(mask[:, None], coords, _PAD_POSITION)
        weights = jnp.where(mask, weights, 0.0)
        # mask filled atoms
        if atom_mask is not None:
            coords = jnp.where(atom_mask[ia], coords, _PAD_POSITION)
            weights = jnp.where(atom_mask[ia], weights, 0.0)
            mask = jnp.where(atom_mask[ia], mask, False)
        coords_all.append(coords)
        weights_all.append(weights)
        masks_all.append(mask)

    if concat:
        coords_all = jnp.vstack(coords_all)
        weights_all = jnp.hstack(weights_all)
        masks_all = jnp.hstack(masks_all)
    return coords_all, weights_all, masks_all
