import jax
import jax.numpy as jnp
import numpy as onp

from typing import Tuple, Callable, Union
from pyscf.gto import Mole
from numpy.typing import NDArray

DensityFn = Union[Callable[[NDArray], NDArray],
                   Callable[[jax.Array], jax.Array]]


def radial_grid(n_radial: int, n_angular: int, cutoff: float
                ) -> Tuple[NDArray, NDArray]:
    """Generate a radial grid for a given number of radial and angular points.

    Args:
        n_radial (int): number of radial points
        n_angular (int): number of angular points in phi
        cutoff (float): grid cutoff

    Returns:
        Tuple[NDArray, NDArray]: radial grid and angular grid
    """
    r = onp.linspace(0, cutoff, n_radial)
    phi = onp.linspace(0, 2*onp.pi, n_angular)
    theta = onp.linspace(0, onp.pi, n_angular // 2)

    e_x = (onp.sin(theta)[:, None] * onp.cos(phi)[None, :]).flatten()
    e_y = (onp.sin(theta)[:, None] * onp.sin(phi)[None, :]).flatten()
    e_z = (onp.cos(theta)[:, None] * onp.ones_like(phi)[None, :]).flatten()
    return r, onp.stack([e_x, e_y, e_z], axis=0).T


def radial_density(atom: Mole,
                   density_matrix: NDArray,
                   grid: Tuple[NDArray, NDArray],
                   ) -> NDArray:
    """
    Calculate the radial density averaged over a spherical shell of an atom
    centered at the origin.
    """
    r, angular_grid = grid

    if density_matrix.ndim == 3:
        density_matrix = density_matrix.sum(axis=0)

    def angular_mean(r):
        ao_values = onp.array(
                        atom.eval_gto('GTOval_sph',
                            r * angular_grid),
                    )

        density = onp.einsum('uv,iu,iv->i',
                            density_matrix,
                            ao_values,
                            ao_values)

        return density.mean()

    return onp.vectorize(angular_mean)(r)


def radial_density_gradient(mol: Mole,
                   density_matrix: NDArray,
                   grid: Tuple[NDArray, NDArray],
                   ) -> NDArray:
    """
    Calculate the radial density averaged gradient over a spherical shell of
    an atom centered at the origin.
    """
    r, angular_grid = grid

    if density_matrix.ndim == 3:
        density_matrix = density_matrix.sum(axis=0)

    def angular_mean(r):
        ao_values = onp.array(
                        mol.eval_gto('GTOval_sph_deriv1',
                            r * angular_grid),
                    )

        density_grad =  onp.einsum('uv,jiu,iv -> ij', # chain rule
                                    density_matrix,
                                    ao_values[1:],
                                    ao_values[0]) + \
                        onp.einsum('uv,iu,jiv -> ij',
                                    density_matrix,
                                    ao_values[0],
                                    ao_values[1:])

        d_r = (density_grad * angular_grid).sum(axis=1)

        return d_r.mean()

    return onp.vectorize(angular_mean)(r)


def get_radial_density_fn(
        mol: Mole,
        P: NDArray,
        cutoff: float,
        n_radial: int,
        n_angular: int,
        backend: str = 'numpy'
        ) -> DensityFn:
    """
    Returns a function that interpolates the radial density of an atom
    """
    grid = radial_grid(n_radial, n_angular, cutoff)
    radial_mean = radial_density(mol, P, grid)
    if backend == 'jax':
        out = lambda r: jnp.interp(r, grid[0], radial_mean)
    elif backend == 'numpy':
        out = lambda r: onp.interp(r, grid[0], radial_mean)
    else:
        raise ValueError(f"Backend {backend} not supported")
    return out


def get_radial_density_gradient_fn(
        mol: Mole,
        density_matrix: NDArray,
        cutoff: float,
        n_radial: int,
        n_angular: int) -> DensityFn:
    """
    Returns a function that interpolates the radial density gradient of an atom
    """
    grid = radial_grid(n_radial, n_angular, cutoff)
    radial_mean_gradient = radial_density_gradient(mol, density_matrix, grid)

    return lambda r: onp.interp(r, grid[0], radial_mean_gradient)
