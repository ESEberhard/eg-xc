# https://github.com/deepmind/ferminet/blob/jax/ferminet/utils/elements.py
# This file is largely taken from Spencer et al., 2020. and N. Gao
from pyscf import gto, dft


class Element:
    """
    Simple data class to manage basic information about elements.
    """

    def __init__(self, symbol, atomic_number, period, spin) -> None:
        self.symbol = symbol
        self.atomic_number = atomic_number
        self.period = period
        self.spin = spin

    def to_pyscf(self, basis: str) -> gto.Mole:
        mol = gto.M(atom=f"{self.atomic_number} 0 0 0", basis=basis, spin=self.spin)
        return mol

    def to_dft(self, basis: str, xc: str) -> dft.rks.RKS:
        """
        Returns a restricted Kohn-Sham solver
        """
        mol = self.to_pyscf(basis)
        mf = dft.RKS(mol, xc=xc)
        return mf


# Static array of all relevant elements.
_ELEMENTS = (
    Element(symbol="H", atomic_number=1, period=1, spin=1),
    Element(symbol="C", atomic_number=6, period=2, spin=2),
    Element(symbol="N", atomic_number=7, period=2, spin=3),
    Element(symbol="O", atomic_number=8, period=2, spin=2),
    Element(symbol="F", atomic_number=9, period=2, spin=1),
)

ELEMENT_BY_SYMBOL = {e.symbol: e for e in _ELEMENTS}
ELEMENT_BY_ATOMIC_NUM = {e.atomic_number: e for e in _ELEMENTS}
SYMBOL_BY_ATOMIC_NUM = {e.atomic_number: e.symbol for e in _ELEMENTS}
ATOMIC_NUM_BY_SYMBOL = {e.symbol: e.atomic_number for e in _ELEMENTS}
CHARGE_TO_PERIOD = {e.atomic_number: e.period for e in _ELEMENTS}

QM9_ELEMENTS = ["H", "C", "N", "O", "F"]
