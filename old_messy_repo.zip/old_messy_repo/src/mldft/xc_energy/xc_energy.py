import jax

from mldft.utils.typing import NnParams, MoleculeSolverParams, XcEnergyFn
from mldft.nn.model import AssembledModel
from typing import Dict, Callable, Optional


def get_xc_energy_fn(
        model: AssembledModel,
        hparams: Dict,
        mgga_feature_fn: Optional[Callable],
        gnn_feature_fn: Optional[Callable],
        ) -> XcEnergyFn:
    """
    Returns a function that computes the exchange-correlation energy
    """

    def xc_energy(  params: NnParams,
                    density_matrix: jax.Array,
                    msp: MoleculeSolverParams) -> jax.Array:
        """
        Returns the exchange-correlation energy for a given density matrix.
        """
        mgga_in_features = mgga_feature_fn(
                                density_matrix.astype(hparams["precision"]["metaGGA"]),
                                msp.quadrature_ao_values
                            ) if mgga_feature_fn is not None else None

        gnn_in_features = gnn_feature_fn(
                                density_matrix,
                                msp.atom_ao_values,
                                msp.nuclear_positions,
                                msp.nuclear_charges
                            ) if gnn_feature_fn is not None else None

        energy = model.apply(
                        params,
                        mgga_in_features,
                        gnn_in_features,
                        msp,
                        mutable=False
                    )

        if hparams["model"]["use_nuclei"] and \
            not hparams["model"]["use_metaGGA"]:
            energy += msp.atom_base_xc

        return energy

    return xc_energy

def get_mgga_xc_energy_fn(
        model: AssembledModel,
        hparams: Dict,
        mgga_feature_fn: Optional[Callable]
        ) -> XcEnergyFn:
    """
    Returns a function that computes the semi-local exchange-correlation energy
    """
    def xc_energy(  params: NnParams,
                    density_matrix: jax.Array,
                    msp: MoleculeSolverParams) -> jax.Array:
        """
        Returns the exchange-correlation energy for a given density matrix.
        """
        mgga_in_features = mgga_feature_fn(
                                density_matrix.astype(hparams["precision"]["metaGGA"]),
                                msp.quadrature_ao_values
                            ) if mgga_feature_fn is not None else None

        energy = model.apply(
                        params,
                        mgga_in_features,
                        msp.quadrature_weights,
                        mutable=False
                    )

        return energy

    return xc_energy