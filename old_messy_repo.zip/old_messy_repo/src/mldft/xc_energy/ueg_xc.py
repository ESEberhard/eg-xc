import jax
import jax.numpy as jnp

pi = jnp.pi


def _calc_r_s(n: jax.Array, epsilon: float = 0) -> jax.Array:
    """
    The Wigner-Seitz radius
    """
    return (3 / (4 * pi * n + epsilon))**(1 / 3)


def e_x_ueg(n: jax.Array) -> jax.Array:
    """
    The exchange energy per particle of the uniform electron gas.
    """
    return - (3 / 4) * (3 / pi)**(1 / 3) * n**(1 / 3)


def ec_LSDA1_fn(n: jax.Array,
                xi: jax.Array,
                use_RPA=False,
                modified=False) -> jax.Array:
    """
    The correlation energy of the uniform electron gas by
    Perdew and Wang (1992) (PW92).
    https://doi.org/10.1103/PhysRevB.45.13244,

    libxc reference implementation:
    https://github.com/ElectronicStructureLibrary/libxc/blob/master/src/lda_c_pw.c
    https://github.com/ElectronicStructureLibrary/libxc/blob/master/src/maple2c/lda_exc/lda_c_pw.c#L14
    https://github.com/ElectronicStructureLibrary/libxc/blob/master/maple/lda_exc/lda_c_pw.mpl
    https://github.com/ElectronicStructureLibrary/libxc/blob/master/maple/util.mpl
    """
    r_s = _calc_r_s(n)

    def analytic_base_from(p, A, a1, b1, b2, b3, b4) -> jax.Array:
        """
        p and A are constrained the remaining parameters were fitted (see ref)
        """
        beta_sum = b1 * r_s**(1 / 2) \
                 + b2 * r_s          \
                 + b3 * r_s**(3 / 2) \
                 + b4 * r_s**(p + 1)
        log_term = jnp.log1p(1 / (2 * A * beta_sum))
        return - 2 * A * (1 + a1 * r_s) * log_term

    A_unpolarized = 0.031091 if not modified else 0.0310907
    A_polarized   = 0.015545 if not modified else 0.01554535
    A_alpha_c     = 0.016887 if not modified else 0.0168869
    if use_RPA:
        # random-phase approximation (RPA)
        ec_unpolarized =analytic_base_from(p=0.75, A=A_unpolarized,
                            a1=0.082477, b1=5.1486, b2=1.6483, b3=0.2347,  b4=0.20614)
        ec_polarized =  analytic_base_from(p=0.75, A=A_polarized,
                            a1=0.035374, b1=6.4869, b2=1.3083, b3=0.15180, b4=0.082349)
        alpha_c =     - analytic_base_from(p=1,    A=A_alpha_c,
                            a1=0.028829, b1=10.357, b2=3.6231, b3=0.47990, b4=0.12279)
    else:
        ec_unpolarized =analytic_base_from(p=1, A=A_unpolarized,
                            a1=0.21370, b1=7.5957,  b2=3.5876, b3=1.6382,  b4=0.49294)
        ec_polarized =  analytic_base_from(p=1, A=A_polarized,
                            a1=0.20548, b1=14.1189, b2=6.1977, b3=3.3662,  b4=0.62517)
        alpha_c =     - analytic_base_from(p=1, A=A_alpha_c,
                            a1=0.11125, b1=10.357,  b2=3.6231, b3=0.88026, b4=0.49671)

    dd_f_zero = 1.709921 if not modified else 1.709920934161365617563962776245
    # alpha_c = dd_f_zero * (ec_polarized - ec_unpolarized)  # from another reference
    f_xi = ((1 + xi)**(4 / 3) + (1 - xi)**(4 / 3) - 2) / (2**(4 / 3) - 2)

    return ec_unpolarized + alpha_c * f_xi / dd_f_zero * (1 - xi**4) \
          + (ec_polarized - ec_unpolarized) * f_xi * xi**4