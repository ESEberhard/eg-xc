import jax
import jax.numpy as jnp
from pyscf import dft, gto
# typing:
from typing import Dict


# @jax.jit
# def x_energy_lda(density_on_grid: jnp.ndarray,
#                  grid_spacing: float) -> jnp.ndarray:
#     """
#     Returns the exchange energy for a given density matrix.
#     """
#     e_x = -3/4 * (3/jnp.pi)**(1/3) * jnp.sum(density_on_grid**(4 / 3)) * grid_spacing**3
#     return e_x


class PyscfXCFunctional:
    """
    A class that wraps the PySCF exchange-correlation functional.
    """
    def __init__(self, mol_str: str, xc: str, hparams: Dict):
        """
        Initializes the class with a given exchange-correlation functional.
        """
        mol = gto.M(atom=mol_str,
                    basis=hparams["basis"],
                    unit='Angstrom')

        self.dft = dft.RKS(mol, xc=xc)

    def get_xc_energy(self, density_matrix: jax.Array) -> jax.Array:
        """
        Returns a function that computes the exchange-correlation energy.
        """
        e_xc = self.dft.get_veff(self.dft.mol, density_matrix).exc
        return jnp.array(e_xc)

    def get_v_xc(self, density_matrix: jax.Array) -> jax.Array:
        """
        Returns a function that computes the exchange-correlation potential.
        """
        v_xc = self.dft.get_veff(self.dft.mol, density_matrix) \
                - self.dft.get_j(self.dft.mol, density_matrix)
        return jnp.array(v_xc)