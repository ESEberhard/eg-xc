import os
from copy import deepcopy
import math
import torch
from torch.utils import data
import numpy as onp

from mldft.systems.initializer import ElementInitializer

from mldft.dataloading.datasets import (
    CustomDatasetBase,
    QM9Dataset,
    MD17Dataset,
    Mace3BPA,
)

from numpy.typing import ArrayLike
from typing import Dict, Any, Tuple, List


def __collate_fn(x):
    return x


def get_debug_dataloader_and_dataset(
    data_params: Dict[str, Any],
    molecule_grid_coords: ArrayLike,
    base_grid_coords: ArrayLike,
    hyperparams: Dict[str, Any],
    return_mol=True,
) -> Tuple[data.DataLoader, CustomDatasetBase]:
    dataset = QM9Dataset(
        data_params,
        hyperparams,
        molecule_grid_coords,
        base_grid_coords,
        return_mol=return_mol,
    )

    dataloader = data.DataLoader(
        dataset, batch_size=None, num_workers=0, collate_fn=None
    )

    return dataloader, dataset


def get_dataloaders(
    data_params: Dict[str, Any],
    molecule_grid_coords: ArrayLike,
    base_grid_coords: ArrayLike,
    hyperparams: Dict[str, Any],
    element_initializer: ElementInitializer,
    multiprocessing_context: str = "spawn",
    return_test_set: bool = False,
) -> Tuple[
    data.DataLoader, data.DataLoader, data.DataLoader, CustomDatasetBase, List, List
]:
    dataset_args = (data_params, hyperparams, molecule_grid_coords, base_grid_coords)
    if data_params["dataset"] == "qm9":
        dataset = QM9Dataset(*dataset_args)
    elif data_params["dataset"] == "md17":
        dataset = MD17Dataset(data_params["mol_key"], *dataset_args, train=True)
    elif data_params["dataset"] == "3bpa":
        dataset = Mace3BPA(data_params["train_key_3bpa"], *dataset_args)
    else:
        raise ValueError(f"Unknown dataset: {data_params['dataset']}")

    generator = torch.Generator().manual_seed(data_params["random_seed"])
    split = deepcopy(data_params["split"])
    split[1] = int(len(dataset) * split[1])
    split[2] = int(len(dataset) * split[2])
    split[0] = len(dataset) - split[1] - split[2]

    assert math.isclose(split[0], len(dataset) * data_params["split"][0], abs_tol=1)

    if (
        data_params["dataset"] == "qm9"
        and data_params["qm9_train_heavy_limit"] is not None
    ):
        n_heavy = data_params["qm9_train_heavy_limit"]

        train_path = f"./mldft/data/qm9/splits/{n_heavy}_train.npy"
        val_path = f"./mldft/data/qm9/splits/{n_heavy}_val.npy"

        if os.path.exists(train_path) and os.path.exists(val_path):
            train_indices = onp.load(train_path)
            val_indices = onp.load(val_path)
        else:
            train_indices = []
            for i in range(1, n_heavy + 1):
                train_indices.append(
                    onp.load(f"./mldft/data/qm9/{i}_heavy_atoms_indices.npy")
                )

            train_indices = onp.concatenate(train_indices)
            train_indices = onp.random.permutation(train_indices)
            val_indices = train_indices[: int(len(train_indices) * 0.1)]
            train_indices = train_indices[int(len(train_indices) * 0.1) :]

            # save split for reproducibility
            onp.save(train_path, train_indices)
            onp.save(val_path, val_indices)

        if data_params["qm9_n_test"] is None:
            test_indices = []
            for i in range(n_heavy + 1, 10):
                test_indices.append(
                    onp.load(f"./mldft/data/qm9/{i}_heavy_atoms_indices.npy")
                )
            test_indices = onp.concatenate(test_indices)
        else:
            test_path = f"./mldft/data/qm9/splits/{n_heavy}_test_{data_params['qm9_n_test']}.npy"
            if os.path.exists(test_path):
                test_indices = onp.load(test_path)
            else:
                test_indices = []
                for i in range(n_heavy + 1, 10):
                    test_indices.append(
                        onp.load(f"./mldft/data/qm9/{i}_heavy_atoms_indices.npy")
                    )
                test_indices = onp.concatenate(test_indices)
                test_indices = onp.random.permutation(test_indices)
                test_indices = test_indices[: data_params["qm9_n_test"]]

                onp.save(test_path, test_indices)

        if not data_params["qm9_with_flourine"]:
            flourine_indices = onp.load("./mldft/data/qm9/flourine_indices.npy")
            train_indices = onp.setdiff1d(train_indices, flourine_indices)
            val_indices = onp.setdiff1d(val_indices, flourine_indices)
            test_indices = onp.setdiff1d(test_indices, flourine_indices)

        train_set = data.Subset(dataset, train_indices)
        val_set = data.Subset(dataset, val_indices)
        test_set = data.Subset(dataset, test_indices)
    else:
        train_set, val_set, test_set = data.random_split(
            dataset, split, generator=generator
        )

    if data_params["dataset"] == "md17":
        test_set = MD17Dataset(data_params["mol_key"], *dataset_args, train=False)
        test_set.test = True

    if data_params["dataset"] == "3bpa":
        test_set = Mace3BPA(data_params["test_keys_3bpa"][0], *dataset_args)
        for i in range(1, len(data_params["test_keys_3bpa"])):
            test_set += Mace3BPA(data_params["test_keys_3bpa"][i], *dataset_args)

    test_set.fixed_interpolation = 1

    print("train, val, test sizes:", len(train_set), len(val_set), len(test_set))

    if hyperparams["model"]["use_nuclei"]:
        Z_to_e_xc = element_initializer.get_xc_energy_per_atom(
            dataset=dataset, train_indices=train_set.indices
        )
        dataset.set_Z_to_e_xc(Z_to_e_xc)

    mp_c = multiprocessing_context if data_params["num_workers"][0] > 0 else None
    persistent_workers = True if data_params["num_workers"][0] > 0 else False
    training_data = data.DataLoader(
        train_set,
        batch_size=None,
        shuffle=data_params["shuffle"],
        num_workers=data_params["num_workers"][0],
        persistent_workers=persistent_workers,
        collate_fn=__collate_fn,
        multiprocessing_context=mp_c,
        prefetch_factor=data_params["prefetch_factor"]
        if data_params["num_workers"][0] > 0
        else None,
    )

    mp_c = multiprocessing_context if data_params["num_workers"][1] > 0 else None
    val_data = data.DataLoader(
        val_set,
        batch_size=None,
        num_workers=data_params["num_workers"][1],
        persistent_workers=persistent_workers,
        collate_fn=__collate_fn,
        multiprocessing_context=mp_c,
        prefetch_factor=data_params["prefetch_factor"]
        if data_params["num_workers"][1] > 0
        else None,
    )

    if return_test_set:
        test_set.fixed_interpolation = 1
        mp_c = multiprocessing_context if data_params["num_workers"][2] > 0 else None
        if hyperparams["model"]["use_nuclei"]:
            test_set.set_Z_to_e_xc(Z_to_e_xc)
        test_data = data.DataLoader(
            test_set,
            batch_size=None,
            shuffle=False,
            num_workers=data_params["num_workers"][2],
            persistent_workers=persistent_workers,
            collate_fn=__collate_fn,
            multiprocessing_context=mp_c,
            prefetch_factor=data_params["prefetch_factor"]
            if data_params["num_workers"][2] > 0
            else None,
        )
    else:
        test_data = None

    return (
        training_data,
        val_data,
        test_data,
        dataset,
        train_set.indices,
        val_set.indices,
    )
