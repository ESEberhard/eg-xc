from copy import deepcopy
import functools
import os
import abc
import numpy as onp
import pyscf
import re
import hashlib
from torch.utils import data
from torch_geometric.datasets import QM9, MD17

from mldft.grids import GridPreprocessor
from mldft.systems.molecule_params import molecule_params_factory
from mldft.scf.fock_matrix import get_host_j_fn

from mldft.systems import constants
from mldft.systems.elements import ATOMIC_NUM_BY_SYMBOL
from mldft.utils.typing import MoleculeParams, HostMoleculeSolverParams
from mldft.utils import initial_density_generation, mol_tensor_generator
from numpy.typing import ArrayLike
from jax import Array
from typing import Dict, Any, Tuple, Union, Optional
from pyscf.gto import Mole
from mldft.dataloading.utils import np_array_to_pyscf_string, DataDir

Energy = float
Density = Optional[Array]
Sample = Union[
    Tuple[Energy, Density, MoleculeParams, HostMoleculeSolverParams],
    Tuple[Energy, Density, MoleculeParams, HostMoleculeSolverParams, Mole],
]


def np_load_cached(path: str):
    from filelock import FileLock, Timeout
    key = hashlib.sha256(path.encode()).hexdigest()
    file_path = f'/tmp/{key}.npy'
    lock_path = f'/tmp/{key}.npy.lock'
    lock = FileLock(lock_path, mode=0o777, timeout=60)
    try:
        with lock:
            if os.path.exists(file_path):
                try:
                    return onp.load(file_path, allow_pickle=True)
                except:
                    os.remove(file_path)
                    return np_load_cached(path)
            else:
                data = onp.load(path, allow_pickle=True)
                onp.save(file_path, data, allow_pickle=True)
                return data
    except Timeout:
        print(f'Failed to acquire lock for {path}')
        os.remove(file_path)
        os.remove(lock_path)
        return np_load_cached(path)

class CustomDatasetBase(data.Dataset):
    fixed_interpolation = None
    test = False

    def __init__(
        self,
        dataparams: Dict[str, Any],
        hyperparams: Dict[str, Any],
        molecule_grid_coords: ArrayLike,
        base_grid_coords: ArrayLike,
        return_mol: bool,
    ):
        self.dataparams = dataparams
        self.hyperparams = hyperparams
        self.pad_quadrature = self.dataparams["pad_quadrature_grid"]
        if self.dataparams["initial_density"]["random_interpolation"]:
            self.rng = onp.random.default_rng(dataparams["random_seed"])
        else:
            self.rng = None
        self.start_idx = dataparams["start_idx"]
        self.return_mol = return_mol

        self.grid_preprocessor = GridPreprocessor(
            hyperparams,
            dataparams,
            molecule_grid_coords,
            base_grid_coords,
            precision=hyperparams["precision"]["general"],
        )
        self.perform_precycles = dataparams["initial_density"]["precycles"] > 0
        # attributes to be set in subclasses
        self.data = None
        self.xc_energy_atom_regression = None
        self.dataset_name = ""

    @functools.cache
    def get_pyscf(self, idx: int, basis: str):
        return pyscf.gto.M(atom=self.get_molecule_string(idx), basis=basis)
 
    @functools.cache
    def get_aux_mol(self, idx: int, basis: str):
        mol = self.get_pyscf(idx, basis)
        return pyscf.df.addons.make_auxmol(mol, "weigend")

    def __getitem__(self, idx: int) -> Sample:
        idx += self.start_idx

        mol_params, mol_solver_params = self.get_mol_solver_params(idx)
        target_energy = onp.array(self.get_target_energy(idx), dtype=onp.float32)
        # TODO: handel optional target density
        out = (target_energy, None, mol_params, mol_solver_params)

        if self.return_mol:
            mol_str = self.get_molecule_string(idx)
            molecule = pyscf.gto.M(atom=mol_str, basis=self.hyperparams["basis"])
            out += (molecule,)
        return out

    def get_mol_solver_params(
        self, idx: int
    ) -> Tuple[MoleculeParams, HostMoleculeSolverParams]:
        mol = self.get_pyscf(idx, self.hyperparams["basis"])
        aux_mol = self.get_aux_mol(idx, self.hyperparams["basis"])
        df_tensors = mol_tensor_generator.fast_df_pyscf(mol, aux_mol, lib='jax')
        use_nuclei = False

        init_dens = None
        # if self.perform_precycles:
        #     init_dens = self.load_initial_density_matrix(idx)

        mol_params, mol_solver_params = molecule_params_factory(
            mol,
            idx,
            self.grid_preprocessor,
            self.hyperparams,
            self.rng,
            None,
            df_tensors,
            init_dens,
            self.dataparams["initial_density"]["random_interpolation"],
            self.fixed_interpolation,
            self._Z_to_e_xc if use_nuclei else None,
            dataset=self.dataset_name,
            pad_quadrature=self.pad_quadrature,
        )
        return mol_params, mol_solver_params

    def __len__(self):
        if self.dataparams["max_molecules"] is not None:
            return self.dataparams["max_molecules"]
        else:
            return len(self.data)

    @abc.abstractmethod
    def get_molecule_string(self, idx: int) -> str:
        pass

    @abc.abstractmethod
    def get_target_energy(self, idx: int) -> float:
        pass

    def set_Z_to_e_xc(self, Z_to_e_xc: Dict[int, float]):
        self._Z_to_e_xc = Z_to_e_xc

    def initialize_tensors(self, dir: str) -> None:
        return
        if self.dataparams["eri_tensor_dir"] is not None:
            if self.hyperparams["eri_calculation"]["density_fitting"]:
                self.eri_dir = None
                self.df_dir = os.path.join(
                    dir, self.hyperparams["basis"], "density_fitting"
                )
                # self.init_density_fitting_tensor()
            else:
                self.eri_dir = os.path.join(dir, self.hyperparams["basis"])
                self.df_dir = None
                # self.init_elec_rep_tensor()
        else:
            self.eri_dir = None
            self.df_dir = None

    def init_elec_rep_tensor(self) -> None:
        return
        if not os.path.exists(self.eri_dir):
            print(f"Creating electron repulsion tensor data set in {self.eri_dir}")
            os.makedirs(self.eri_dir, mode=0o777)
            mol_tensor_generator.generate_data_set_tensors(
                "eri",
                self.eri_dir,
                self,
                self.dataparams["eri_tensor_sub_dir_size"],
                self.hyperparams["basis"],
            )

    def init_density_fitting_tensor(self) -> None:
        return
        if not os.path.exists(self.df_dir):
            print(f"Creating electron repulsion tensor data set in {self.df_dir}")
            os.makedirs(self.df_dir, mode=0o777)
            mol_tensor_generator.generate_data_set_tensors(
                "density_fitting",
                self.df_dir,
                self,
                self.dataparams["eri_tensor_sub_dir_size"],
                self.hyperparams["basis"],
            )

    def load_elec_rep_tensor(self, idx: int) -> onp.ndarray:
        """
        Load the electron repulsion tensor for the idx-th molecule and adds
        missing files to the electron repulsion tensor directory.
        """
        raise NotImplementedError()
        sub_dir_size = self.dataparams["eri_tensor_sub_dir_size"]

        n_dir = str(sub_dir_size * (idx // sub_dir_size))
        os.makedirs(os.path.join(self.eri_dir, n_dir), exist_ok=True, mode=0o777)
        path_str = os.path.join(self.eri_dir, n_dir, f"mol_{idx}.npy")

        if not os.path.exists(path_str):
            print(
                f"Electron repulsion tensor for molecule {idx} not found. Generating it..."
            )
            mol_tensor_generator.generate_eri_mol_str(
                path_str, self.get_molecule_string(idx), self.hyperparams["basis"]
            )
        return onp.load(path_str).astype(self.hyperparams["precision"]["general"])

    def load_density_fitting_tensor(self, idx: int) -> Tuple[onp.ndarray, onp.ndarray]:
        """
        Load the density fitting tensors for the idx-th molecule and adds
        missing files to the density fitting tensors directory.
        """
        return mol_tensor_generator.fast_df(
            self.get_molecule_string(idx), self.hyperparams["basis"]
        )
        sub_dir_size = self.dataparams["eri_tensor_sub_dir_size"]

        n_dir = str(sub_dir_size * (idx // sub_dir_size))
        os.makedirs(os.path.join(self.df_dir, n_dir), exist_ok=True, mode=0o777)
        path_str = os.path.join(self.df_dir, n_dir, f"mol_{idx}_df_tensor.npy")

        if not os.path.exists(path_str):
            print(
                f"Density fitting tensors for molecule {idx} not found. Generating it..."
            )
            mol_tensor_generator.generate_df_mol_str(
                path_str, self.get_molecule_string(idx), self.hyperparams["basis"], idx
            )
        try:
            return onp.load(path_str).astype(self.hyperparams["precision"]["general"])
        except Exception:
            print(f"Error loading {path_str}. Regenerating")
            mol_tensor_generator.generate_df_mol_str(
                path_str, self.get_molecule_string(idx), self.hyperparams["basis"], idx
            )
            return onp.load(path_str).astype(self.hyperparams["precision"]["general"])

    def init_initial_density_data(self, dir_suffix=None) -> None:
        return
        if self.dataparams["initial_density"]["root_dir"] is not None:
            self.density_dir = self.dataparams["initial_density"]["root_dir"]
        else:
            params_str = (
                f"{self.dataparams['initial_density']['xc']}"
                + f"_{self.hyperparams['basis']}"
                + f"_{self.dataparams['initial_density']['precycles']}"
            )
            density_dir = os.path.join("aux", "initial_density", params_str)
            density_dir = os.path.join(self.root_dir, density_dir)
            self.density_dir = density_dir
        if dir_suffix is not None:
            self.density_dir = os.path.join(self.density_dir, dir_suffix)

        if not os.path.exists(self.density_dir):
            print(f"Creating initial density data set in {self.density_dir}")
            os.makedirs(self.density_dir, mode=0o777)
            # initial_density_generation.compute_initial_densities_for_data_set(
            #     self.density_dir, self, self.dataparams, self.hyperparams
            # )

    def load_initial_density_matrix(self, idx: int) -> onp.ndarray:
        """
        Load the initial density for the idx-th molecule and adds
        missing files to the initial density directory.
        """
        return None
        sub_dir_size = self.dataparams["initial_density"]["sub_dir_size"]

        if sub_dir_size is None:
            path_str = os.path.join(self.density_dir, f"mol_{idx}.npy")
        else:
            n_dir = str(sub_dir_size * (idx // sub_dir_size))
            path_str = os.path.join(self.density_dir, n_dir, f"mol_{idx}.npy")
            os.makedirs(
                os.path.join(self.density_dir, n_dir), exist_ok=True, mode=0o777
            )

        if not os.path.exists(path_str):
            print(f"Initial density for molecule {idx} not found. Generating it...")
            initial_density_generation.save_initial_density_of_molecule(
                path_str,
                {
                    "molecule": self.get_molecule_string(idx),
                    "basis": self.hyperparams["basis"],
                    "precycles": self.dataparams["initial_density"]["precycles"],
                    "xc": self.dataparams["initial_density"]["xc"],
                },
            )
        return np_load_cached(path_str).astype(self.hyperparams["precision"]["general"])

    def get_j_fns(self):
        # FIXME: This is incompatible with pytorch mp data loading
        j_fn_list = []
        for idx in range(self.__len__()):
            molecule_str = self.get_molecule_string(idx)
            j_fn = get_host_j_fn(
                molecule_str,
                self.hyperparams["basis"],
                self.hyperparams["eri_calculation"]["use_numpy_in_host_callbacks"],
            )
            j_fn_list.append(j_fn)
        return j_fn_list


class QM9Dataset(CustomDatasetBase):
    def __init__(
        self,
        data_params: Dict[str, Any],
        hyperparams: Dict[str, Any],
        molecule_grid_coords: ArrayLike,
        base_grid_coords: ArrayLike,
        return_mol: bool = False,
        root_dir: str = ".src/mldft/data/qm9/",
    ):
        super().__init__(
            data_params, hyperparams, molecule_grid_coords, base_grid_coords, return_mol
        )
        assert not self.dataparams["include_density"]
        self.root_dir = root_dir
        self.data = QM9(root_dir)
        # if self.perform_precycles:
        #     self.init_initial_density_data()
        # self.initialize_tensors(self.dataparams["eri_tensor_dir"])

    def get_molecule_string(self, idx: int) -> str:
        sample = self.data[idx]
        atoms = onp.concatenate((sample["z"][:, None], sample["pos"]), axis=1)
        return np_array_to_pyscf_string(atoms)

    def get_target_energy(self, idx: int) -> float:
        sample = self.data[idx]
        return sample["y"][0, 7].item() * constants.EV_TO_HARTREE


class MD17Dataset(CustomDatasetBase):
    def __init__(
        self,
        name: str,
        data_params: Dict[str, Any],
        hyperparams: Dict[str, Any],
        molecule_grid_coords: ArrayLike,
        base_grid_coords: ArrayLike,
        return_mol: bool = False,
        root_dir: str = "./src/mldft/data/md17/",
        train: bool = True,
    ):
        super().__init__(
            data_params, hyperparams, molecule_grid_coords, base_grid_coords, return_mol
        )
        self.root_dir = root_dir
        self.data = MD17(root_dir, train=train, name=name)

        # if train:
        #     eri_dir = self.dataparams["eri_tensor_dir"]
        #     density_dir_suffix = None
        # else:
        #     eri_dir = os.path.join(self.dataparams["eri_tensor_dir"], "test")
        #     density_dir_suffix = "test"
        # if self.perform_precycles:
        #     self.init_initial_density_data(density_dir_suffix)
        # self.initialize_tensors(eri_dir)

    def get_molecule_string(self, idx: int) -> str:
        sample = self.data[idx]
        atoms = onp.concatenate((sample["z"][:, None], sample["pos"]), axis=1)
        return np_array_to_pyscf_string(atoms)

    def get_target_energy(self, idx: int) -> float:
        sample = self.data[idx]
        return sample["energy"][0].item() * constants.KCAL_PER_MOL_TO_HATREE


class Mace3BPA(CustomDatasetBase):
    def __init__(
        self,
        name: str,
        data_params: Dict[str, Any],
        hyperparams: Dict[str, Any],
        molecule_grid_coords: ArrayLike,
        base_grid_coords: ArrayLike,
        return_mol: bool = False,
        root_dir: str = "./src/mldft/data/3bpa/",
    ):
        data_params = deepcopy(data_params)
        data_params["eri_tensor_dir"] = data_params["eri_tensor_dir"].format(key=name)
        data_params["initial_density"]["root_dir"] = data_params["initial_density"][
            "root_dir"
        ].format(key=name)
        super().__init__(
            data_params, hyperparams, molecule_grid_coords, base_grid_coords, return_mol
        )
        self.dataset_name = name
        self.root_dir = root_dir

        path = os.path.join(root_dir, "preprocessed", name)

        def symbol_to_atomic_number(symbol):
            return ATOMIC_NUM_BY_SYMBOL[symbol]

        self.data = []

        if True:
            os.makedirs(os.path.join(path, "mol"), mode=0o777, exist_ok=True)
            with open(os.path.join(root_dir, "raw", f"{name}.xyz")) as f:
                data = f.readlines()

            block_length = int(data[0]) + 2
            energies = []
            for i in range(0, len(data), block_length):
                pos = onp.loadtxt(data[i + 2 : i + block_length], usecols=(1, 2, 3))
                charges = onp.loadtxt(
                    data[i + 2 : i + block_length], usecols=0, dtype=str
                )
                charges = onp.vectorize(symbol_to_atomic_number)(charges)
                atoms = onp.concatenate((charges[:, None], pos), axis=1)
                self.data.append(atoms)
                #     onp.save(os.path.join(path, "mol", f"{i//block_length}.npy"), atoms)
                energy = float(re.search(r"energy=([-\d.]+)", data[i + 1]).group(1))
                energies.append(energy * constants.EV_TO_HARTREE)
            # onp.save(os.path.join(path, "energies.npy"), onp.array(energies))
            self.energies = onp.array(energies)

        # self.energies = onp.load(os.path.join(path, "energies.npy"))

        # if self.perform_precycles:
        #     self.init_initial_density_data()
        # self.initialize_tensors(self.dataparams["eri_tensor_dir"])

    def get_molecule_string(self, idx: int) -> str:
        atoms = self.data[idx]
        return np_array_to_pyscf_string(atoms)

    def get_target_energy(self, idx: int) -> float:
        return self.energies[idx]
