import os
import numpy as np
from typing import Tuple, Any

Sample = Tuple[Any]


class DataDir:
    def __init__(self, path: str):
        self.path = os.path.join(path, "mol")

    def __getitem__(self, idx: int) -> Sample:
        return np.load(os.path.join(self.path, f"{idx}.npy"))

    def __len__(self):
        return len(os.listdir(self.path))


def np_array_to_pyscf_string(atoms: np.ndarray) -> str:
    """
    Takes a numpy array of atoms and converts it to a string that can be used
    to initialize a PySCF molecule.
    """
    return [(int(z), x) for z, *x in atoms]
    mol_str = (
        str(atoms)
        .replace("\n", ";")
        .replace("[", "")
        .replace("]", "")
        .replace(".00000000e+00", " ")
        .replace(". ", " ")
    )
    return mol_str
