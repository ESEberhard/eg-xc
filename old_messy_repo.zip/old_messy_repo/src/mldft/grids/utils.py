import jax
import jax.numpy as jnp
import numpy as onp

from mldft.grids import Grid
from mldft.grids.generation import generate_atom_grid_coords
from mldft.utils.typing import AoValues, HostAoValues

from typing import Callable, Tuple, Optional
from numpy.typing import NDArray
from pyscf.gto import Mole


def density_on_grid(
    ao_values: AoValues, density_matrix: jax.Array, grid_shape: Optional[Tuple]
) -> jax.Array:
    """
    returns the density on the grid for a given density matrix
    """
    density = jnp.einsum("uv,iu,iv->i", density_matrix, ao_values[0], ao_values[0])
    if grid_shape is not None:
        Nx, Ny, Nz = grid_shape
        density = density.reshape((Nx, Ny, Nz))
    return density


def density_gradient_on_grid(
    ao_values: AoValues, density_matrix: jax.Array, grid_shape: Optional[Tuple]
) -> jax.Array:
    """
    returns the density gradient on the grid for a given density matrix
    """
    density_grad = (
        jnp.einsum(
            "uv,jiu,iv -> ij",  # chain rule
            density_matrix,
            ao_values[1:],
            ao_values[0],
        )
        + jnp.einsum("uv,iu,jiv -> ij", density_matrix, ao_values[0], ao_values[1:])
    )
    if grid_shape is not None:
        Nx, Ny, Nz = grid_shape
        density_grad = density_grad.reshape((Nx, Ny, Nz, 3))
    return density_grad


def kinetic_energy_density_on_grid(
    ao_values: AoValues, density_matrix: jax.Array, grid_shape: Optional[Tuple]
) -> jax.Array:
    """
    returns the kinetic energy density on the grid for a given density matrix
    """
    tau = 0.5 * jnp.einsum(
        "uv,jiu,jiv->i", density_matrix, ao_values[1:], ao_values[1:]
    )
    if grid_shape is not None:
        Nx, Ny, Nz = grid_shape
        tau = tau.reshape((Nx, Ny, Nz))
    return tau


def atomic_orbital_values_on_grid(
    molecule: Mole, grid_coords: NDArray, derivative: int, precision: str
) -> HostAoValues:
    """
    Evaluate the atomic orbitals on a given grid.
    TODO: consider changing the shape of the ao_values to (n_features, Nx, Ny, Nz, n_basis_functions)

    Args:
        molecule (pyscf.gto.Mole): molecule
        grid_coords (NDArray): grid coordinates
        derivative (int): derivative order

    Returns:
        HostAoValues: evaluation of basis functions and their derivatives
                        on the grid
                        shape: (1 or 4 depending of whether grad is required,
                                n_grid_points, n_basis_functions)
    """
    if derivative == 0:
        gto_op = "GTOval_sph"
    elif derivative == 1:
        gto_op = "GTOval_sph_deriv1"
    else:
        raise NotImplementedError("Higher order derivatives not implemented.")
    ao_values = onp.array(
        molecule.eval_gto(gto_op, grid_coords.reshape(-1, 3)), dtype=precision
    )
    if derivative == 0:
        ao_values = ao_values[None, :]
    return ao_values


def host_eval_fn_on_grid(
    fn: Callable[[NDArray], NDArray], grid_coords: NDArray, radial: bool = False
):
    coords = grid_coords
    if radial:
        coords = onp.linalg.norm(coords, axis=-1)
    return fn(coords)


def atom_electron_density_on_grid(
    base_grid_coords: Grid,
    n_resolutions: int,
    radial_density_fn: Callable,
    radial_density_gradient_fn: Optional[Callable],
) -> NDArray:
    """
    Args:
        base_grid_coords (Grid): the base grid coordinates shape (Nx, Ny, Nz, 3)
        n_resolutions (int): the number of resolutions
        radial_density_fn (Callable): the radial density function
        radial_density_gradient_fn (Optional[Callable]): the radial density gradient function

    Returns the electron density on the grid for a given atom.
    output shape (n_resolutions, Nx, Ny, Nz, 1) or
    (n_resolutions, Nx, Ny, Nz, 2) if gradient is provided
    """

    atom_grid_coords = generate_atom_grid_coords(
        onp.zeros((1, 3)), base_grid_coords, n_resolutions
    )  # shape (1, n_resolutions, Nx, Ny, Nz, 3)

    out = host_eval_fn_on_grid(radial_density_fn, atom_grid_coords, radial=True)[0]
    if radial_density_gradient_fn is not None:
        density_grad = host_eval_fn_on_grid(
            radial_density_gradient_fn, atom_grid_coords, radial=True
        )
        out = onp.stack([out, density_grad], axis=-1)
    else:
        out = out[..., None]
    return out


# @partial(jax.jit, static_argnames=('grid_shape',
#                                    'include_grad',
#                                    'include_kinetic_energy_density'))
# def density_on_grid(ao_values: AoValues,
#                     density_matrix: jax.Array,
#                     grid_shape: Tuple,
#                     include_grad: bool,
#                     include_kinetic_energy_density: bool) -> jax.Array:
#     """
#     Returns the density on the grid for a given density matrix.
#     TODO: check if downcasting is performed correctly
#     """
#     Nx, Ny, Nz = grid_shape
#     density = jnp.einsum('uv,iu,iv->i',
#                          density_matrix,
#                          ao_values[0],
#                          ao_values[0])

#     density = density.reshape((Nx, Ny, Nz))[..., None]
#     if include_grad:
#         density_grad =  jnp.einsum('uv,jiu,iv -> ij', # chain rule
#                                     density_matrix,
#                                     ao_values[1:],
#                                     ao_values[0]) + \
#                         jnp.einsum('uv,iu,jiv -> ij',
#                                     density_matrix,
#                                     ao_values[0],
#                                     ao_values[1:])

#         density_grad = density_grad.reshape((Nx, Ny, Nz, 3))

#         density = jnp.concatenate([density, density_grad], axis=-1)
#     if include_kinetic_energy_density:
#         tau = 0.5 * jnp.einsum('uv,jiu,jiv->i',
#                                density_matrix,
#                                ao_values[1:],
#                                ao_values[1:])
#         tau = tau.reshape((Nx, Ny, Nz))[..., None]
#         density = jnp.concatenate([density, tau], axis=-1)
#     return density
