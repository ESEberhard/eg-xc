import jax
import jax.numpy as jnp
from functools import partial

from mldft import grids

from typing import Tuple, Callable, Dict, Optional, Any
from mldft.utils.typing import AoValues, DensityMatrix
from mldft.xc_energy.scan import e_xc_scan
from mldft.systems.atom_densities import DensityFn

NucPos = jax.Array
NucCharges = jax.Array


EPSILON = 1e-15


def s_fn(density, abs_density_grad) -> jax.Array:
    return abs_density_grad / (
        2 * (3 * jnp.pi**2) ** (1 / 3) * density ** (4 / 3) + EPSILON
    )


def alpha_fn(density, abs_density_grad, tau) -> jax.Array:
    tau_w = abs_density_grad**2 / (8 * density + EPSILON)
    tau_unif = (3 / 10) * (3 * jnp.pi**2) ** (2 / 3) * density ** (5 / 3)
    alpha = (tau - tau_w) / (tau_unif + EPSILON)
    return alpha


def _get_superposition_of_atom_densities_fn(
    element_density_radial_fns: Dict[int, Callable[[jax.Array], jax.Array]],
    base_atom_grid_coords: Tuple[int, int, int],
    resolutions: int,
    grid_type="atom",
) -> Callable[[NucPos, NucCharges], jax.Array]:
    """
    Returns a function that computes the superposition of atom densities.
    """
    charges = element_density_radial_fns.keys()

    @partial(jax.jit, static_argnames=("charge",))
    def grid_densities(charge: int, pos: jax.Array, coords: jax.Array) -> jax.Array:
        """
        pos: shape(n_atoms, 3)
        coords: shape(n_atoms, n_resolutions, Nx, Ny, Nz, 3)

        returns
            for atom_grids:
                array where (i, j, r, k, l, m) = rho_i(r_grid_point_jrklm) due to charge at i
            for molecule_grids:
                array where (i, k, l, m) = rho_i(r_grid_point_klm) due to charge at i
        """
        if grid_type == "atom":
            rel_displacement = coords[None] - pos[:, None, None, None, None, None, :]
        elif grid_type == "molecule":
            rel_displacement = coords[None] - pos[:, None, None, None, :]
        else:
            raise ValueError(f"grid_type must be 'atom' or 'molecule', got {grid_type}")
        rel_distance = jnp.linalg.norm(
            rel_displacement, axis=-1
        )  # shape(n_atoms, n_atoms, n_resolutions, Nx, Ny, Nz)
        # rel_distance (i, j, res, k, l, m) = |r_nucleus_i - r_grid_point_klm|
        radial_fn = element_density_radial_fns[charge]
        return radial_fn(rel_distance)

    def superposition_of_atom_densities_fn(
        nuclei_positions: jax.Array, nuclei_charges: jax.Array
    ) -> jax.Array:
        grid_coords = grids.generate_atom_grid_coords(
            nuclei_positions, base_atom_grid_coords, resolutions
        )
        grid_shape = grid_coords.shape[:-1]
        out = jnp.zeros(grid_shape)
        for c in charges:
            mask = nuclei_charges == c
            rho_c = grid_densities(c, nuclei_positions, grid_coords)
            out += jnp.einsum("i..., i", rho_c, mask)
        return out

    return superposition_of_atom_densities_fn


class FeatureFnFactory:
    clip_valid = True

    def __init__(
        self,
        hparams: Dict[str, Any],
        base_atom_grid: grids.Grid,
        element_density_radial_fns: Optional[Dict[int, DensityFn]] = None,
    ):
        self.grid_shape = base_atom_grid.shape
        self.general_precision = hparams["precision"]["general"]

        fparams = hparams["density_features"]
        self.incl_dens = fparams["include_density"]
        self.incl_grad = fparams["include_grad"]
        self.incl_kin = fparams["include_kinetic_energy_density"]
        self.incl_scan = fparams["include_scan"]

        self.density_keys = fparams["density_transform"]
        self.grad_keys = fparams["gradient_transform"]
        self.kin_keys = fparams["kinetic_transform"]
        self.scan_keys = fparams["scan_transform"]
        self.scan_precision = fparams["scan_precision"]

        self.div_by_atom_dens = fparams["divide_by_atom_density"]

        if element_density_radial_fns is not None:
            self.atoms_density_fn = _get_superposition_of_atom_densities_fn(
                element_density_radial_fns,
                base_atom_grid.coords,
                hparams["density_grids"]["n_resolutions"],
            )
        else:
            self.atoms_density_fn = None

        self.use_metaGGA = hparams["model"]["use_metaGGA"]
        self.metaGGA_type = hparams["model"]["metaGGA"]["type"]
        self.metaGGA_precision = hparams["precision"]["metaGGA"]
        self.__consistency_check()

    def get_meta_gga_feature_fn(self) -> Callable[[DensityMatrix, AoValues], jax.Array]:
        print("########### WARNING: Statically assings xi to zero")
        if self.metaGGA_type == "Nagai2020":
            self.mgga_density_keys = []
            self.mgga_grad_keys = ["canonical"]
            self.mgga_kin_keys = []  # tau
        elif self.metaGGA_type == "Dick2021":
            self.mgga_density_keys = []
            self.mgga_grad_keys = ["canonical"]
            self.mgga_kin_keys = ["canonical"]  # alpha
        elif self.metaGGA_type == "DeepMind2021":
            self.mgga_density_keys = []
            self.mgga_grad_keys = []
            self.mgga_kin_keys = []  # tau
        elif self.metaGGA_type == "Nagai2022":
            self.mgga_density_keys = []
            self.mgga_grad_keys = ["canonical"]
            self.mgga_kin_keys = ["canonical"]  # alpha
        elif self.metaGGA_type == "LDA":
            self.mgga_density_keys = []
            self.mgga_grad_keys = []
            self.mgga_kin_keys = []  # alpha
        else:
            raise NotImplementedError

        def feature_fn(density_matrix: DensityMatrix, ao_values: AoValues) -> jax.Array:
            """
            Args:
                ao_values (AoValues): atomic orbital values on the grid.
                density_matrix (DensityMatrix): density matrix.

            Returns:
                jax.Array: grid features shape (N_grid, 4)
            """
            channels = []

            density = grids.density_on_grid(ao_values, density_matrix, None)
            channels.append(self.__density_transform(self.mgga_density_keys)(density))

            xi = jnp.zeros_like(density)  # TODO:
            channels.append(xi)

            density_grad = grids.density_gradient_on_grid(
                ao_values, density_matrix, None
            )
            abs_density_grad = jnp.linalg.norm(density_grad, axis=-1)

            channels.append(
                self.__abs_grad_transform(self.mgga_grad_keys)(
                    density, abs_density_grad
                )
            )

            tau = grids.kinetic_energy_density_on_grid(ao_values, density_matrix, None)
            channels.append(
                self.__kin_transform(self.mgga_kin_keys)(density, abs_density_grad, tau)
            )

            return jnp.stack(channels, axis=-1, dtype=self.metaGGA_precision)

        return feature_fn

    def get_gnn_feature_fn(
        self,
    ) -> Callable[[DensityMatrix, AoValues, NucPos, NucCharges], jax.Array]:
        # vmap twice to vectorize over number of atoms and resolutions
        density_fn = jax.vmap(
            jax.vmap(grids.density_on_grid, in_axes=(0, None, None)),
            in_axes=(0, None, None),
        )
        density_gradient_fn = jax.vmap(
            jax.vmap(grids.density_gradient_on_grid, in_axes=(0, None, None)),
            in_axes=(0, None, None),
        )
        kinetic_energy_density_fn = jax.vmap(
            jax.vmap(grids.kinetic_energy_density_on_grid, in_axes=(0, None, None)),
            in_axes=(0, None, None),
        )

        def feature_fn(
            density_matrix: DensityMatrix,
            ao_values: AoValues,
            nuclear_positions: NucPos,
            nuc_charges: NucCharges,
        ) -> jax.Array:
            """
            Args:
                ao_values (AoValues): atomic orbital values on the grid.
                density_matrix (DensityMatrix): density matrix.

            Returns:
                jax.Array: grid features shape
                            (n_atoms, n_resolutions, Nx, Ny, Nz, n_channels)
            """
            channels = []

            density = density_fn(ao_values, density_matrix, self.grid_shape)

            if self.incl_dens:
                channels.append(self.__density_transform(self.density_keys)(density))

            if self.div_by_atom_dens:
                channels.append(
                    density / self.atoms_density_fn(nuclear_positions, nuc_charges) - 1
                )

            if self.incl_grad:
                density_grad = density_gradient_fn(
                    ao_values, density_matrix, self.grid_shape
                )
                abs_density_grad = jnp.linalg.norm(density_grad, axis=-1)
                channels.append(
                    self.__abs_grad_transform(self.grad_keys)(density, abs_density_grad)
                )

            if self.incl_kin:
                tau = kinetic_energy_density_fn(
                    ao_values, density_matrix, self.grid_shape
                )
                channels.append(
                    self.__kin_transform(self.kin_keys)(density, abs_density_grad, tau)
                )

            if self.incl_scan:
                channels.append(self.__scan(density, abs_density_grad, tau))

            return jnp.stack(channels, axis=-1, dtype=self.general_precision)

        return feature_fn

    def compute_out_shape(self):
        pass

    def __density_transform(self, keys) -> Callable[[jax.Array], jax.Array]:
        """
        n: shape (n_atoms, n_resolutions, Nx, Ny, Nz)
        """

        def transform(n: jax.Array) -> jax.Array:
            if self.clip_valid:
                n = jnp.clip(n, 0)
            if "canonical" in keys:
                return n ** (1 / 3)
            elif "s_dick_transform" in keys:
                return jnp.log(n ** (1 / 3) + 1e-5)
            elif "log_x_p1" in keys:
                return jnp.log1p(n)
            else:
                return n

        return transform

    def __abs_grad_transform(self, keys) -> Callable[[jax.Array], jax.Array]:
        def transform(n, abs_density_grad) -> jax.Array:
            if "canonical" in keys or "s_dick_transform" in keys:
                s = s_fn(n, abs_density_grad)
                if self.clip_valid:
                    s = jnp.clip(s, 0)
                if "canonical" in keys:
                    return s
                else:
                    return -jnp.expm1(-(s**2)) * jnp.log1p(s)
            elif "log_x_p1" in keys:
                return jnp.log1p(abs_density_grad)
            else:
                return abs_density_grad

        return transform

    def __kin_transform(self, keys) -> Callable[[jax.Array], jax.Array]:
        def transform(n, abs_density_grad, tau):
            if "canonical" in keys or "s_dick_transform" in keys:
                alpha = alpha_fn(n, abs_density_grad, tau)
                if self.clip_valid:
                    alpha = jnp.clip(alpha, 0)
                if "canonical" in keys:
                    return alpha
                else:
                    return jnp.log1p(alpha) - jnp.log(2)
            elif "log_x_p1" in keys:
                return jnp.log1p(tau)
            else:
                return tau

        return transform

    @property
    def __scan(self) -> Callable[[jax.Array], jax.Array]:
        def evaluate(n, abs_density_grad, tau):
            s = s_fn(n, abs_density_grad)
            alpha = alpha_fn(n, abs_density_grad, tau)
            if self.clip_valid:
                s = jnp.clip(s, 0)
                alpha = jnp.clip(alpha, 0)
            e_xc = e_xc_scan(
                n.astype(self.scan_precision),
                s.astype(self.scan_precision),
                0,
                alpha.astype(self.scan_precision),
            )
            e_xc = e_xc.astype(self.general_precision)
            if "times_density" in self.scan_keys:
                return e_xc * n
            else:
                return e_xc

        return evaluate

    def __consistency_check(self):
        # check keys:
        for collection in [self.density_keys, self.grad_keys, self.kin_keys]:
            for key in collection:
                assert key in ["canonical", "s_dick_transform", "log_x_p1"]

        if self.incl_kin:
            assert self.incl_grad  # kinetic energy density requires gradients

        if self.incl_scan:
            assert self.incl_grad
            assert self.incl_kin

        if self.div_by_atom_dens:
            assert self.atoms_density_fn is not None
