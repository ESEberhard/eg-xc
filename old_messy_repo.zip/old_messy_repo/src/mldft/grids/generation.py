import numpy as onp

from flax.struct import dataclass
from numpy.typing import NDArray
from typing import Optional


@dataclass
class Grid:
    """
    A dataclass for cartesian grids.

    Args:
        coords (onp.ndarray): the coordinates of the grid points
            shape: (Nx, Ny, Nz, 3)
        grid_spacing (float): the grid spacing
        cutoff_radius (float): the cutoff radius around the nuclei
        shape (tuple): the shape of the grid
    """
    coords: NDArray
    grid_spacing: float
    cutoff: Optional[float]
    shape: tuple

    def __hash__(self):
        return hash(self.shape)


def generate_base_grid( grid_spacing: float,
                        cutoff: float) -> Grid:
    # Generate the grid points
    h = grid_spacing
    linear_grid = onp.arange(-cutoff, cutoff + h / 2, h)

    assert len(linear_grid) % 2 == 1

    # Create the 3D grid using meshgrid
    shape = (len(linear_grid),) * 3
    coords = onp.stack(onp.meshgrid(linear_grid, linear_grid, linear_grid), axis=-1)
    coords = onp.swapaxes(coords, 0, 1)
    return Grid(coords, grid_spacing, cutoff, shape)


def generate_atom_grid_coords(nuclei_positions: NDArray,
                              base_grid_coords: NDArray,
                              n_resolutions: int) -> NDArray:
    """
    Generates the atom grid coordinates for given nuclei positions on the CPU.
    The returned array has shape (n_atoms, n_resolutions, Nx, Ny, Nz, 3).
    """
    factors = 1 / onp.exp2(onp.arange(0, n_resolutions))
    factors = factors[None, :, None, None, None, None]                  # shape (1, n_resolutions, 1, 1, 1, 1)
    nuclei_positions = nuclei_positions[:, None, None, None, None, :]   # shape (N_nuc, 1, 1, 1, 1, 3)
    base_grid = base_grid_coords[None, None]                            # shape (1, 1, Nx, Ny, Nz, 3)

    return base_grid * factors + nuclei_positions
