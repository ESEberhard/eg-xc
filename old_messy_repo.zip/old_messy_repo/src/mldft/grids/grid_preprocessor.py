import jax
import numpy as onp
import pyscf
from pyscf import dft

from mldft.grids.utils import atomic_orbital_values_on_grid
from mldft.grids.generation import generate_atom_grid_coords

from mldft.utils.typing import HostAoValues
from numpy.typing import NDArray
from typing import Tuple, Dict, Any, Union


class GridPreprocessor:
    def __init__(self,
                 hparams: Dict[str, Any],
                 data_params: Dict[str, Any],
                 molecule_grid_coords: jax.Array,
                 base_grid_coords: jax.Array,
                 precision: str):
        self.hparams = hparams

        self.molecule_grid_coords = onp.array(molecule_grid_coords)
        self.mol_grid_shape = molecule_grid_coords.shape[:-1]
        self.base_grid_coords = onp.array(base_grid_coords)
        self.base_grid_shape = base_grid_coords.shape[:-1]

        self.precision = precision

        self.ao_gradients_required = \
            self.hparams["density_features"]["include_grad"] \
            or self.hparams["density_features"]["include_kinetic_energy_density"]
        self.data_derivative = data_params["derivative"]
        if data_params["include_density"]:
            self.data_basis = data_params["data_basis"]

    def target_density(self,
                       molecule_str: str,
                       target_density_matrix: NDArray) -> NDArray:

        molecule = pyscf.gto.M(atom=molecule_str, basis=self.data_basis)
        ao_values = atomic_orbital_values_on_grid(molecule,
                                                  self.molecule_grid_coords,
                                                  self.data_derivative,
                                                  self.precision)

        density = self.__target_density_on_grid(ao_values,
                                                target_density_matrix)
        return density

    def standard_integration_grid(self,
            molecule: pyscf.gto.Mole,
            return_ao: bool) -> Tuple[Union[NDArray, HostAoValues], NDArray]:
        mf = dft.RKS(molecule)
        mf.grids.level = self.hparams["model"]["metaGGA"]["integration_grid_level"]
        mf.grids.build()

        grid_coords = mf.grids.coords
        weights = mf.grids.weights.astype(self.precision)

        if not return_ao:
            return grid_coords.astype(self.precision), weights

        ao_values = atomic_orbital_values_on_grid(
                        molecule,
                        grid_coords,
                        derivative=True,
                        precision=self.precision)

        return ao_values, weights

    def atom_grid_coords(self, molecule: pyscf.gto.Mole) -> NDArray:
        out = generate_atom_grid_coords(
                                molecule.atom_coords(),
                                self.base_grid_coords,
                                self.hparams["density_grids"]["n_resolutions"]
                            )
        return out


    def atomic_orbital_values_on_atom_grids(self,
                                   molecule: pyscf.gto.Mole) -> HostAoValues:

        atom_grid_coords = self.atom_grid_coords(molecule)

        ao_values = []
        for atom in range(atom_grid_coords.shape[0]):
            atom_ao_values = []
            for resolution in range(atom_grid_coords.shape[1]):
                coords = atom_grid_coords[atom, resolution]
                atom_ao_values.append(
                        atomic_orbital_values_on_grid(
                            molecule,
                            coords,
                            self.ao_gradients_required,
                            self.precision
                        )
                    )
            ao_values.append(atom_ao_values)
        return onp.array(ao_values, dtype=self.precision)

    def molecule_grid_atomic_orbital_values(
            self,
            molecule: pyscf.gto.Mole) -> HostAoValues:
        return atomic_orbital_values_on_grid(
                    molecule,
                    self.molecule_grid_coords,
                    self.data_derivative,
                    self.precision
                )

    def __target_density_on_grid(self,
                                 ao_values: HostAoValues,
                                 density_matrix: NDArray) -> NDArray:
        """
        Returns the density on the grid for a given density matrix.
        """
        Nx, Ny, Nz = self.mol_grid_shape
        density = onp.einsum('uv,iu,iv->i',
                            density_matrix,
                            ao_values[0],
                            ao_values[0])

        density = density.reshape((Nx, Ny, Nz))[..., None]
        if self.data_derivative > 0:
            density_grad =  onp.einsum('uv,jiu,iv -> ij', # chain rule
                                        density_matrix,
                                        ao_values[1:],
                                        ao_values[0]) + \
                            onp.einsum('uv,iu,jiv -> ij',
                                        density_matrix,
                                        ao_values[0],
                                        ao_values[1:])

            density_grad = density_grad.reshape((Nx, Ny, Nz, 3))
            density = onp.concatenate([density, density_grad], axis=-1)
        if self.data_derivative > 1:
            raise NotImplementedError('Higher order derivatives \
                                       for target density not implemented.')
        return density.astype(self.precision)