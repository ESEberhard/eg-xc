import os

from seml.experiment import Experiment
import numpy as np


EXPERIMENT_NAME = "ml-powered-dft"

ex = Experiment(EXPERIMENT_NAME)


def set_loss_weights(return_last_n: int, factor: int):
    # weights inspired by http://arxiv.org/abs/2106.04481
    weights = np.square(np.arange(0, return_last_n, 1) / return_last_n)
    return (factor * weights / return_last_n).tolist()


# def set_loss_weights(return_last_n: int, factor: int):
#     weights = np.arange(1.0, return_last_n + 1, 1)**2
#     weights /= weights.sum()
#     return (factor * weights).tolist()


@ex.named_config
def mgga():
    local_readout = False
    global_readout = False
    use_mgga_model = True


@ex.config
def config():
    slurm_master = True
    seed = 0
    irreps = "0e+1o+2e"
    ggxc_model = "nequip"
    local_readout = True
    global_readout = True
    use_mgga_model = True
    feature_dim = 32

    debug_params = {
        "disable_jit": False,
        "enable_x64": True,
        "debug_nans": False,
    }

    test = True
    dataset = "3bpa"  # "qm9", "md17", "3bpa"
    train_key_3bpa = "train_300K"  # "train_mixedT"
    test_keys_3bpa = [
        "test_300K",
        "test_600K",
        "test_1200K",
        "test_dih_beta120",
        "test_dih_beta150",
        "test_dih_beta180",
    ]
    mol_key = "ethanol CCSD(T)"  # used for MD17
    basis = "6-31G(d)"  # 'sto-6g', '6-31G(d)' '6-31G(2df,p)' '6-311++G(3df,2pd)'
    precycles = 15
    precycle_xc = "LDA"
    db_collection = None

    name = f"{db_collection}_{dataset}_{mol_key}"

    log_params = {
        "dir": os.path.expanduser(f"~/mldft_logs/{name}"),
        "experiment_name": EXPERIMENT_NAME,
        "model_name": "default_model",
        "run_purpose": "default",
        "complete_log_every": 1000,  # steps
        "make_checkpoints": True,
        "checkpoint_every": 250,  # steps
        "checkpoint_dir": os.path.expanduser("~/mldft_logs/checkpoints"),
        "aim_repo": os.path.expanduser("~/mldft_logs/") if slurm_master else None,
        "name": name,
    }

    if slurm_master:
        atom_data_dir = {
            "qm9": "/ceph/hdd/students/eberhare/qm9/atom_data/",
            "md17": f"/ceph/hdd/students/eberhare/md17/atom_data/{mol_key}/",
            "3bpa": f"/ceph/hdd/students/eberhare/3bpa/atom_data/{train_key_3bpa}/",
        }
        eri_dir = {
            "qm9": "/ceph/hdd/students/eberhare/eri_tensors",
            "md17": f"/ceph/hdd/students/eberhare/md17/eri_tensors/{mol_key}/",
            "3bpa": "/ceph/hdd/students/eberhare/3bpa/eri_tensors/{key}/",
        }
        initial_density_dir = {
            "qm9": f"/nfs/students/eberhare/initial_densities/{precycle_xc}_{basis}_{precycles}",
            "md17": f"/ceph/hdd/students/eberhare/md17/initial_densities/{mol_key}/{precycle_xc}_{basis}_{precycles}/",
            "3bpa": f"/ceph/hdd/students/eberhare/3bpa/initial_densities/{{key}}/{precycle_xc}_{basis}_{precycles}/",
        }
    else:
        atom_data_dir = {
            "qm9": "src/mldft/data/qm9/aux/atom_data/",
            "md17": f"src/mldft/data/md17/{mol_key}/atom_data/",
        }
        eri_dir = {
            "qm9": "src/mldft/data/qm9/aux/eri/",
            "md17": f"src/mldft/data/md17/{mol_key}/eri/",
        }
        initial_density_dir = {
            "qm9": "src/mldft/data/qm9/aux/init_dens/",
            "md17": f"src/mldft/data/md17/{mol_key}/initial_densities/{precycle_xc}_{basis}_{precycles}/",
        }
    pad_quadrature_grid = {"qm9": True, "md17": False, "3bpa": False}
    max_number_of_atoms = {"qm9": 29, "md17": None, "3bpa": None}
    split = {  # train, val, test
        "qm9": [0.6, 0.2, 0.2],
        "md17": [0.95, 0.05, 0.0],
        "3bpa": [0.95, 0.05, 0.0],
    }
    validation_subsample_fraction = {
        "qm9": 1,  # TODO: removed for now
        "md17": 1,
        "3bpa": 1,
    }
    sub_dir_size = {
        "qm9": 5000,
        "md17": 5000,
        "3bpa": None,
    }
    data_params = {
        "dataset": dataset,
        "mol_key": mol_key,
        "train_key_3bpa": train_key_3bpa,
        "test_keys_3bpa": test_keys_3bpa,
        "include_density": False,
        "derivative": 0,
        "shuffle": True,
        "num_workers": [2] * 3 if test else [*[2] * 2, 0],  # train, val, test
        "prefetch_factor": 2,
        "start_idx": 0,
        "pad_quadrature_grid": pad_quadrature_grid[dataset],
        "qm9_train_heavy_limit": 4,  # overwrites train val test split setting above
        "qm9_with_flourine": False,
        "qm9_n_test": None,
        "max_molecules": None,
        "random_seed": seed,
        "split": split[dataset],
        "validation_subsample_fraction": validation_subsample_fraction[dataset],
        "atom_data_dir": atom_data_dir[dataset],
        "eri_tensor_dir": eri_dir[dataset],
        "eri_tensor_sub_dir_size": 5000,
        "initial_density": {
            "precycles": precycles,  # maximum number of iterations for the initial guess
            "xc": precycle_xc,
            "root_dir": initial_density_dir[dataset],
            "sub_dir_size": sub_dir_size[dataset],
            "random_interpolation": True,
        },
        "max_number_of_atoms": max_number_of_atoms[dataset],  # per molecule
    }

    return_last_n = 3

    hparams = {
        # "jit_step": dataset in ("md17", "3bpa"),
        "jit_step": True,
        "test": test,
        # scf parameters
        "basis": basis,
        "restricted": True,
        "steps": 15,
        "diis": True,
        # training parameters
        "epochs": 100_000,
        "early_stopping_patience": 50,  # number of epochs
        "optimizer": {
            "name": "adam",  # "prodigy", "adam"
            "weight_decay": 0,
            "schedule": {
                "type": "linear",  # "constant", "linear", "reduce_on_plateau"
                "learning_rate": 0.01,
                "warmup_steps": 100,
                "decay_steps": 50_000,
                "minimum_learning_rate": 1e-7,
                "reduce_on_plateau": {
                    "factor": 0.25,
                    "patience": 5,
                    "cooldown": 3,
                    "accumulation_size": 950,
                },
            },
            "grad_clip_max_norm": 1,
            "apply_ever_k": 1,  # accumulates the parameter updates over k steps
            "skip_nan": True,
        },
        "precision": {
            "general": "float32",
            "metaGGA": "float64",
            "solver": "float64",
        },
        # loss parameters
        "return_last_n": return_last_n,
        "energy_weights": set_loss_weights(return_last_n, 1),
        "density_weights": set_loss_weights(return_last_n, 0),
        # density features
        "density_features": {
            "include_density": True,
            "include_grad": False,
            "include_kinetic_energy_density": False,
            "include_scan": False,
            "density_transform": ["log_x_p1"],  # "s_dick_transform"
            "gradient_transform": ["log_x_p1"],  # s or |grad n|
            "kinetic_transform": ["log_x_p1"],  # alpha or |grad tau|
            "scan_transform": ["times_density"],
            "scan_precision": "float64",
            "divide_by_atom_density": False,
        },
        "density_grids": {
            "molecule_grid_spacing": 0.5,  # Angstrom  TODO: check units (AU?)
            "molecule_cutoff": 10,  # Angstrom TODO: check units (AU?)
            "atom_max_grid_spacing": 0.4,
            "atom_max_cutoff": 4,  # Angstrom TODO: check units (AU?)
            "n_resolutions": 4,
        },
        "ao_values_on_GPU": False,
        "eri_calculation": {
            "density_fitting": True,
            "using_host_callbacks": False,  # FIXME: presently incompatible with
            # pytorch mp data loading
        },
        "model": {
            "seed": seed,
            "use_nuclei": False,
            "use_schnet": False,
            "use_painn": False,
            "filter_features": False,
            "use_metaGGA": True,
            "atoms": {
                "use_nuclei_charge_embedding": False,
                # specifies the parameters used for the atom-wise calculations,
                # such as density and xc energy per atom
                "regression": False,  # calculate xc energy per atom via
                # regression or from dft calculations of
                # individual atoms
                "basis": basis,
                "xc": precycle_xc,
                "symbols": ["H", "C", "N", "O", "F"],
                "n_radial": 1000,
                "n_angular": 100,  # NOT equal to the total number of grid points
            },
            "SchNet": {
                "n_features": 128,
                "n_interaction": 3,
                # Filter parameters:
                "cutoff_dist": 6,  # Angstrom
                "n_gaussian": 60,
                "gamma": 0.1,
            },
            "PaiNN": {
                "atom_features": 128,
                "cutoff_dist": 6,  # Angstrom
                "n_basis": 20,
                "n_layers": 3,
            },
            "Embedding": {
                "use_pre_painn": False,  # FIXME: ablations
                "pre_painn": {
                    "atom_features": 32,
                    "cutoff_dist": 6,  # Angstrom
                    "n_basis": 20,
                    "n_layers": 3,
                },
                "invariant": {
                    "n_layers": 6,  # TODO: 6
                    "n_channels": [2, 3, 4, 6, 8],
                    "res_block_depth": 1,
                    "n_res_blocks": 0,
                    "block_params": {
                        "stride": 1,
                        "padding": "VALID",
                        "base": {
                            "kernel_size": 5,
                            "n_base_kernels": 12,
                            "global_radial_filter_params": {
                                "n_basis": 20,
                                "gamma": 700,  # in units of relative grid length
                                "layers": 1,  # layers for filter generator
                            },
                        },
                    },
                },
                "equivariant": {  # only used in GNNs with equivariant input fields
                    "n_layers": 2,
                    "n_channels": [1],
                    "res_block_depth": 1,
                    "n_res_blocks": 0,
                    "block_params": {
                        "stride": 1,
                        "padding": "SAME",  # TODO: does that make sense?
                        "base": {
                            "kernel_size": 3,
                            "n_base_kernels": 8,
                            "global_radial_filter_params": {
                                "n_basis": 20,
                                "gamma": 700,  # in units of relative grid length
                                "layers": 1,  # layers for filter generator
                            },
                        },
                    },
                },
            },
            "RadialMasks": {
                "n_basis": 20,
                "gamma": 700,  # in units of fractional grid length
            },
            "metaGGA": {
                "type": "Dick2021",  # Nagai2020, DeepMind2021, Dick2021, Nagai2022
                "integration_grid_level": 1,
                "pretraining": {
                    "dir_name": "product_edging_2024_08_14_11:49:04_pretrain",
                    "load": True,
                    "epochs": 100,
                    "early_stopping_patience": 5,  # number of epochs
                    "optimizer": {
                        "name": "adam",  # "prodigy", "adam"
                        "weight_decay": 0,
                        "schedule": {
                            "type": "linear",  # "constant", "linear", "reduce_on_plateau"
                            "learning_rate": 0.01,
                            "warmup_steps": 100,
                            "decay_steps": 50_000,
                            "minimum_learning_rate": 1e-7,
                            "reduce_on_plateau": {
                                "factor": 0.25,
                                "patience": 5,
                                "cooldown": 3,
                                "accumulation_size": 950,
                            },
                        },
                        "grad_clip_max_norm": None,
                        "apply_ever_k": 1,  # accumulates the parameter updates over k steps
                        "skip_nan": True,
                    },
                },
            },
        },
    }
