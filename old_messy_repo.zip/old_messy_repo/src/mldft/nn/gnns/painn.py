import jax
import jax.numpy as jnp
import flax.linen as nn

from mldft.nn.embedding import InvariantEmbedding, EquivariantEmbedding

from jax import Array
from typing import Tuple, Dict, Any


def cosine_cutoff(x: Array, cutoff: float) -> Array:
    """Behler-style cosine cutoff function"""
    x = 0.5 * (jnp.cos((jnp.pi / cutoff) * x) + 1)
    return jnp.where(x < cutoff, x, 0)


class ScalarFilter(nn.Module):
    cutoff_dist: float
    n_features: int
    n_basis: int = 20

    def setup(self) -> None:
        n = jnp.arange(1, self.n_basis + 1)
        self.prefactors = n * jnp.pi / self.cutoff_dist

    @nn.compact
    def __call__(self, x: Array) -> Array:
        """
        input: interatomic distances shape (N_atoms, N_atoms)
        output: scalar filter shape (N_atoms, N_atoms, 3 * n_features)
        """
        x = jnp.sin(
            x[..., None] * self.prefactors[None, None, :]
        )  # shape (N_atoms, N_atoms, n_basis)
        x = nn.Dense(3 * self.n_features)(x)
        return x


class MessageBlock(nn.Module):
    n_features: int
    cutoff_dist: float

    @nn.compact
    def __call__(
        self, s: Array, v: Array, dr: Array, atom_mask: Array
    ) -> Tuple[Array, Array]:
        """
        Computes messages between atoms.
        Feature-wise updates across atoms.
        # TODO: consider masking self messages

        Args:
            s (Array): scalar atom features (N_atoms, n_features)
            v (Array): equivariant atom features (N_atoms, n_features, 3)
            dr (Array): distance vectors between atoms (N_atoms, N_atoms, 3)
            atom_mask (Array): padding mask for atoms

        Returns:
            ds_msg (Array): scalar messages
            dv_msg (Array): equivariant messages
        """
        distances = jnp.linalg.norm(dr, axis=-1)

        phi = nn.Dense(self.n_features)(s)
        phi = nn.silu(phi)
        phi = nn.Dense(3 * self.n_features)(phi)
        f_cut = cosine_cutoff(distances, self.cutoff_dist)  # shape (N_atoms, N_atoms)
        W = (
            ScalarFilter(self.cutoff_dist, self.n_features)(distances)
            * f_cut[..., None]
        )
        msg = jnp.einsum(
            "jf, ijf, j -> ijf", phi, W, atom_mask
        )  # shape (N_atoms, N_atoms, 3 * n_features)
        # TODO: check if the mask is applied correctly
        # scalar messages
        ds_msg = msg[..., : self.n_features].sum(axis=1)

        # equivariant messages
        msg_vv = msg[..., self.n_features : 2 * self.n_features]
        msg_vs = msg[..., 2 * self.n_features :]
        e_r_save = dr / (distances + 1e-9)[..., None]
        dv_msg = jnp.einsum("jfv,  ijf -> ifv", v, msg_vv) + jnp.einsum(
            "ijv,  ijf -> ifv", e_r_save, msg_vs
        )
        return ds_msg, dv_msg


class UpdateBlock(nn.Module):
    n_features: int

    @nn.compact
    def __call__(self, s: Array, v: Array):
        """
        Updates the atom features.
        Atom-wise updates across features.

        Args:
            s (Array): scalar atom features (N_atoms, n_features)
            v (Array): equivariant atom features (N_atoms, n_features, 3)

        Returns:
            ds_up (Array): scalar updates
            dv_up (Array): equivariant updates
        """
        # learnable linear combinations of equivariant vectors
        Vv = nn.Einsum(
            (self.n_features, self.n_features), "ifv, gf -> igv", use_bias=False
        )(v)  # shape (N_atoms, n_features, 3)
        Uv = nn.Einsum(
            (self.n_features, self.n_features), "ifv, gf -> igv", use_bias=False
        )(v)  # shape (N_atoms, n_features, 3)
        norm_Vv = jnp.linalg.norm(Vv, axis=-1)
        # print(Vv.shape, Uv.shape, norm_Vv.shape)
        # print(jnp.abs(Vv).max(), jnp.abs(Uv).max(), jnp.abs(norm_Vv).max())
        scalar_prod_Vv_Uv = (Vv * Uv).sum(axis=-1)

        scalar_features = jnp.concatenate(
            [s, norm_Vv], axis=-1
        )  # shape (N_atoms, 2 * n_features)
        atm_rep = nn.Dense(self.n_features)(scalar_features)
        atm_rep = nn.silu(atm_rep)
        atm_rep = nn.Dense(3 * self.n_features)(
            atm_rep
        )  # shape (N_atoms, 3 * n_features)

        ds_up = (
            atm_rep[..., : self.n_features]
            + atm_rep[..., self.n_features : 2 * self.n_features] * scalar_prod_Vv_Uv
        )
        dv_up = atm_rep[..., 2 * self.n_features :, None] * Uv
        return ds_up, dv_up


class PrePaiNN(nn.Module):
    """
    Implementation of polarizable atom interaction neural network by Schütt et al.
    https://doi.org/10.48550/arXiv.2102.03150
    """

    atom_features: int  # F: number of features per atom
    cutoff_dist: float
    n_basis: int
    n_layers: int

    @nn.compact
    def __call__(self, atom_pos: jax.Array, atom_mask: jax.Array) -> jax.Array:
        """
        atom_pos: shape (N_atoms, 3)

        Returns: scalar and vector atom features
        """
        s_0 = self.param(
            "initial",
            nn.initializers.normal(),
            (self.atom_features,),
            dtype=jnp.float32,
        )
        s = jnp.tile(s_0, (atom_mask.shape[0], 1))
        v = jnp.zeros((atom_mask.shape[0], self.atom_features, 3), dtype=jnp.float32)
        dr = atom_pos[:, None, :] - atom_pos[None, :, :]

        for _ in range(self.n_layers):
            ds_msg, dv_msg = MessageBlock(self.atom_features, self.cutoff_dist)(
                s, v, dr, atom_mask
            )
            s += ds_msg
            v += dv_msg

            ds_up, dv_up = UpdateBlock(self.atom_features)(s, v)
            s += ds_up
            v += dv_up
        return s, v


class PaiNN(nn.Module):
    """
    Implementation of polarizable atom interaction neural network by Schütt et al.
    https://doi.org/10.48550/arXiv.2102.03150
    """

    atom_features: int  # F: number of features per atom
    cutoff_dist: float
    n_basis: int
    n_layers: int

    embedding_params: Dict[str, Any]
    use_bias: bool = False

    # def initialize_equivariant_representations(self, n_atoms: int) -> Array:
    #     """
    #     Initializes the equivariant representations of the atoms to zero.
    #     output shape: (n_atoms, embedding_dim, 3)
    #     """
    #     return jnp.zeros((n_atoms, self.atom_features, 3), dtype=jnp.float32)

    @nn.compact
    def __call__(
        self,
        electron_density_features: jax.Array,
        atom_pos: jax.Array,
        atom_mask: jax.Array,
        nuclear_charges: jax.Array,
    ) -> jax.Array:
        """
        electron_density_features:
            shape (N_atoms, N_resolutions, Nx_grid, Nx_grid, Nx_grid, grid_channels)
        atom_pos: shape (N_atoms, 3)

        Returns: predicted scalar target value
        """
        if self.embedding_params["use_pre_painn"]:
            pre_s, pre_v = PrePaiNN(**self.embedding_params["pre_painn"])(
                atom_pos, atom_mask
            )
        else:
            pre_s = pre_v = None

        s = InvariantEmbedding(
            **self.embedding_params["invariant"],
            n_features=self.atom_features,
            n_resolutions=self.embedding_params["n_resolutions"],
            use_atom_features=self.embedding_params["use_pre_painn"],
        )(electron_density_features, pre_s, pre_v, nuclear_charges)

        v = EquivariantEmbedding(
            **self.embedding_params["equivariant"],
            n_features=self.atom_features,
            n_resolutions=self.embedding_params["n_resolutions"],
            use_atom_features=self.embedding_params["use_pre_painn"],
        )(electron_density_features, pre_s, pre_v)

        dr = atom_pos[:, None, :] - atom_pos[None, :, :]

        for _ in range(self.n_layers):
            ds_msg, dv_msg = MessageBlock(self.atom_features, self.cutoff_dist)(
                s, v, dr, atom_mask
            )

            s += ds_msg
            v += dv_msg

            ds_up, dv_up = UpdateBlock(self.atom_features)(s, v)
            s += ds_up
            v += dv_up

        s = nn.Dense(self.atom_features, use_bias=self.use_bias)(s)
        s = nn.silu(s)
        s = nn.Dense(1, use_bias=self.use_bias)(s)
        out = (s * atom_mask[:, None]).sum()
        # jax.debug.print("output {out}", out=out)
        return out


def residual(x, y):
    if x.shape == y.shape:
        return (x + y) / jnp.sqrt(2)
    return y


class MyPaiNN(nn.Module):
    """
    Implementation of polarizable atom interaction neural network by Schütt et al.
    https://doi.org/10.48550/arXiv.2102.03150
    """

    atom_features: int  # F: number of features per atom
    cutoff_dist: float
    n_basis: int
    n_layers: int

    @nn.compact
    def __call__(
        self,
        inv_features: jax.Array,
        equiv_features: jax.Array,
        atom_pos: jax.Array,
        atom_mask: jax.Array,
        nuclear_charges: jax.Array,
    ) -> jax.Array:
        s = inv_features
        v = equiv_features
        dr = atom_pos[:, None, :] - atom_pos[None, :, :]
        s = nn.LayerNorm()(s)
        v_norms = jnp.linalg.norm(v, axis=-1)
        v = v * (nn.LayerNorm()(v_norms) / (v_norms + 1e-9))[..., None]

        for _ in range(self.n_layers):
            ds_msg, dv_msg = MessageBlock(self.atom_features, self.cutoff_dist)(
                s, v, dr, atom_mask
            )

            s += ds_msg
            s = nn.LayerNorm()(s)
            v += dv_msg
            v_norms = jnp.linalg.norm(v, axis=-1)
            v = v * (nn.LayerNorm()(v_norms) / (v_norms + 1e-9))[..., None]

            ds_up, dv_up = UpdateBlock(self.atom_features)(s, v)
            s += ds_up
            s = nn.LayerNorm()(s)
            v += dv_up
            v_norms = jnp.linalg.norm(v, axis=-1)
            v = v * (nn.LayerNorm()(v_norms) / (v_norms + 1e-9))[..., None]

        return s, v
