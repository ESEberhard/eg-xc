"""
SchNet model https://doi.org/10.48550/arXiv.1706.08566
"""

import jax
import jax.numpy as jnp
import flax.linen as nn

from mldft.nn.embedding import InvariantEmbedding
from mldft.nn.activation_fns import shifted_softplus
from mldft.nn.gnns.painn import PrePaiNN
from typing import Dict, Any


class AtomWiseLayer(nn.Module):
    n_features: int
    initializer: nn.initializers.Initializer = nn.initializers.lecun_normal()

    @nn.compact
    def __call__(self, x: jax.Array):
        """
        x: shape (N_atoms, n_features)
        """
        x = nn.Dense(self.n_features,
                     kernel_init=self.initializer)(x)
        return x


class FilterGeneratingNN(nn.Module):
    gamma: float
    cutoff_dist: float
    n_gaussians: int
    n_features: int

    @nn.compact
    def __call__(self, dist: jax.Array):
        mu = jnp.linspace(0, self.cutoff_dist, self.n_gaussians, dtype=jnp.float32)
        gaussian_basis = jnp.exp(- self.gamma * \
                            jnp.square(
                                dist[..., None] - mu[None, None, :]
                            )
                        ) # shape (n_atoms, n_atoms, n_gaussians)

        f = nn.Dense(self.n_features)(gaussian_basis)
        # f: shape (n_atoms, n_atoms, n_features)
        f = shifted_softplus(f)
        f = nn.Dense(self.n_features)(f)
        f = shifted_softplus(f)
        return f


class InteractionBlock(nn.Module):
    n_features: int

    cutoff_dist: float
    n_gaussian: int
    gamma: float

    @nn.compact
    def __call__(self, x: jax.Array, dist: jax.Array, atom_mask: jax.Array):
        """
            x: shape (N_atoms, n_features)
        """

        residual = AtomWiseLayer(self.n_features)(x)

        filter = FilterGeneratingNN(self.gamma,
                                    self.cutoff_dist,
                                    self.n_gaussian,
                                    self.n_features)(dist)
        # filter: shape(N_atoms, N_atoms, n_features)
        # residual: (N_atoms, n_features)
        residual = jnp.einsum('jk, ijk, j -> ik', residual, filter, atom_mask)

        residual = AtomWiseLayer(self.n_features)(residual)
        residual = shifted_softplus(residual)
        residual = AtomWiseLayer(self.n_features)(residual)

        x += residual

        return jnp.einsum('jk, ijk -> ik', x, filter)


class Distances(nn.Module):
    def __call__(self, atom_pos: jax.Array):
        """
        atom_pos: shape (N_atoms, 3)
        """
        r_i = atom_pos[:, None, :]
        r_j = atom_pos[None, :, :]
        pairwise_dist = jnp.linalg.norm(r_i - r_j, axis=-1)
        return pairwise_dist


class SchNet(nn.Module):
    n_features: int
    n_interaction: int

    cutoff_dist: float
    n_gaussian: int
    gamma: float

    embedding_params: Dict[str, Any]

    @nn.compact
    def __call__(self,
                 electron_density_features: jax.Array,
                 atom_pos: jax.Array,
                 atom_mask: jax.Array,
                 nuclear_charges: jax.Array) -> jax.Array:
        """
        electron_density_features:
            shape (N_atoms, N_resolutions, Nx_grid, Nx_grid, Nx_grid, grid_channels)
        atom_pos: shape (N_atoms, 3)

        Returns: predicted scalar target value
        """
        if self.embedding_params["use_pre_painn"]:
            pre_s, pre_v = PrePaiNN(
                                **self.embedding_params["pre_painn"]
                            )(atom_pos, atom_mask)
        else:
            pre_s = pre_v = None

        x = InvariantEmbedding(
                    **self.embedding_params["invariant"],
                    n_features=self.n_features,
                    n_resolutions=self.embedding_params["n_resolutions"],
                    use_atom_features=self.embedding_params["use_pre_painn"]
                )(electron_density_features, pre_s, pre_v, nuclear_charges)

        dist = Distances()(atom_pos)

        for _ in range(self.n_interaction):
            x = InteractionBlock(self.n_features,
                                 self.cutoff_dist,
                                 self.n_gaussian,
                                 self.gamma)(x, dist, atom_mask)

        x = AtomWiseLayer(n_features=self.n_features // 2)(x)
        x = shifted_softplus(x)
        x = AtomWiseLayer(n_features=1,
                          initializer=nn.initializers.zeros_init())(x)  # shape: (n_atoms, 1)

        return (x * atom_mask[:, None]).sum()  # sum pooling



