from typing import Callable, Optional, Tuple

import e3nn_jax as e3nn
import flax.linen as nn
import jax
import jax.numpy as jnp

from .message_passing import MessagePassingConvolution
from .symmetric_contraction import SymmetricContraction


class LinearNodeEmbeddingBlock(nn.Module):
    num_species: int
    irreps_out: e3nn.Irreps

    @nn.compact
    def __call__(self, node_specie: jnp.ndarray) -> e3nn.IrrepsArray:
        irreps_out = e3nn.Irreps(self.irreps_out).filter("0e").regroup()
        w = self.param(
            "embeddings",
            jax.nn.initializers.normal(stddev=1.0),
            (self.num_species, irreps_out.dim),
            jnp.float32,
        )
        return e3nn.IrrepsArray(self.irreps_out, w[node_specie])


class LinearReadoutBlock(nn.Module):
    output_irreps: e3nn.Irreps

    @nn.compact
    def __call__(self, x: e3nn.IrrepsArray) -> e3nn.IrrepsArray:
        # x = [n_nodes, irreps]
        return e3nn.flax.Linear(self.output_irreps)(x)  # [n_nodes, output_irreps]


class NonLinearReadoutBlock(nn.Module):
    hidden_irreps: e3nn.Irreps
    output_irreps: e3nn.Irreps
    activation: Optional[Callable] = None
    gate: Optional[Callable] = None

    @nn.compact
    def __call__(self, x: e3nn.IrrepsArray) -> e3nn.IrrepsArray:
        # x = [n_nodes, irreps]
        num_vectors = self.hidden_irreps.filter(
            drop=["0e", "0o"]
        ).num_irreps  # Multiplicity of (l > 0) irreps
        x = e3nn.flax.Linear(
            (self.hidden_irreps + e3nn.Irreps(f"{num_vectors}x0e")).simplify()
        )(x)
        x = e3nn.gate(x, even_act=self.activation, even_gate_act=self.gate)
        return e3nn.flax.Linear(self.output_irreps)(x)  # [n_nodes, output_irreps]


class RadialEmbeddingBlock:
    def __init__(
        self,
        *,
        r_max: float,
        avg_r_min: Optional[float] = None,
        basis_functions: Callable[[jnp.ndarray], jnp.ndarray],
        envelope_function: Callable[[jnp.ndarray], jnp.ndarray],
    ):
        self.r_max = r_max
        self.avg_r_min = avg_r_min
        self.basis_functions = basis_functions
        self.envelope_function = envelope_function

    def __call__(
        self,
        edge_lengths: jnp.ndarray,  # [n_edges]
    ) -> e3nn.IrrepsArray:  # [n_edges, num_basis]
        def func(lengths):
            basis = self.basis_functions(lengths / self.r_max)  # [n_edges, num_basis]
            cutoff = self.envelope_function(lengths / self.r_max)  # [n_edges]
            return basis * cutoff[:, None]  # [n_edges, num_basis]

        with jax.ensure_compile_time_eval():
            if self.avg_r_min is None:
                factor = 1.0
            else:
                samples = jnp.linspace(
                    self.avg_r_min, self.r_max, 1000, dtype=jnp.float64
                )
                factor = jnp.mean(func(samples) ** 2).item() ** -0.5

        embedding = factor * jnp.where(
            (edge_lengths == 0.0)[:, None], 0.0, func(edge_lengths)
        )  # [n_edges, num_basis]
        return e3nn.IrrepsArray(f"{embedding.shape[-1]}x0e", embedding)


class EquivariantProductBasisBlock(nn.Module):
    target_irreps: e3nn.Irreps
    correlation: int
    num_species: int
    symmetric_tensor_product_basis: bool = True
    off_diagonal: bool = False

    @nn.compact
    def __call__(
        self,
        node_feats: e3nn.IrrepsArray,  # [n_nodes, feature * irreps]
        node_specie: jnp.ndarray,  # [n_nodes, ] int
    ) -> e3nn.IrrepsArray:
        symmetric_contractions = SymmetricContraction(
            keep_irrep_out={ir for _, ir in self.target_irreps},
            correlation=self.correlation,
            num_species=self.num_species,
            gradient_normalization="element",  # NOTE: This is to copy mace-torch
            symmetric_tensor_product_basis=self.symmetric_tensor_product_basis,
            off_diagonal=self.off_diagonal,
        )
        node_feats = node_feats.mul_to_axis().remove_nones()
        node_feats = symmetric_contractions(node_feats, node_specie)
        node_feats = node_feats.axis_to_mul()
        return e3nn.haiku.Linear(self.target_irreps)(node_feats)


class InteractionBlock(nn.Module):
    target_irreps: e3nn.Irreps
    avg_num_neighbors: float
    max_ell: int
    activation: Callable

    @nn.compact
    def __call__(
        self,
        vectors: e3nn.IrrepsArray,  # [n_edges, 3]
        node_feats: e3nn.IrrepsArray,  # [n_nodes, irreps]
        radial_embedding: jnp.ndarray,  # [n_edges, radial_embedding_dim]
        senders: jnp.ndarray,  # [n_edges, ]
        receivers: jnp.ndarray,  # [n_edges, ]
    ) -> Tuple[e3nn.IrrepsArray, e3nn.IrrepsArray]:
        assert node_feats.ndim == 2
        assert vectors.ndim == 2
        assert radial_embedding.ndim == 2

        node_feats = e3nn.flax.Linear(node_feats.irreps, name="linear_up")(node_feats)

        node_feats = MessagePassingConvolution(
            self.avg_num_neighbors, self.target_irreps, self.max_ell, self.activation
        )(vectors, node_feats, radial_embedding, senders, receivers)

        node_feats = e3nn.flax.Linear(self.target_irreps, name="linear_down")(
            node_feats
        )

        assert node_feats.ndim == 2
        return node_feats  # [n_nodes, target_irreps]


class ScaleShiftBlock(nn.Module):
    scale: float
    shift: float

    @nn.compact
    def __call__(self, x: e3nn.IrrepsArray) -> e3nn.IrrepsArray:
        return self.scale * x + self.shift

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(scale={self.scale:.6f}, shift={self.shift:.6f})"
        )
