import jax
import jax.numpy as jnp
import flax.linen as nn

from mldft.xc_energy.ueg_xc import e_x_ueg, ec_LSDA1_fn as e_c_ueg
from mldft.xc_energy.scan import e_x_scan, e_c_scan
from typing import Tuple


class BaseMetaGGA(nn.Module):
    general_precision: str

    def __call__(self, x: jax.Array, weights: jax.Array) -> jax.Array:
        """
        Args:
            x (jax.Array): (N_grid_points, 4)
            weights (jax.Array): (N_grid_points)

        Returns:
            jax.Array: E_xc energy
        """
        n = x[..., 0]
        e_xc = self.exchange_correlation_energy_density(x)
        out = jnp.where(weights != 0, weights * n * e_xc, 0).sum()
        return out.astype(self.general_precision)

    def exchange_correlation_energy_density(self, x: jax.Array) -> jax.Array:
        raise NotImplementedError


class Nagai2020(BaseMetaGGA):
    """
    Following the publication by
    Nagai, Ryo, Ryosuke Akashi, and Osamu Sugino.
    “Completing Density Functional Theory by Machine Learning Hidden Messages from Molecules.”
    Npj Computational Materials 6, no. 1 (May 5, 2020): 1–8.
    https://doi.org/10.1038/s41524-020-0310-0.

    TODO: add non-local features?
    FIXME: I had to add a small constant to the input transformation to avoid log(0),
    what did they do?
    """

    general_precision: str

    def setup(self) -> None:
        self.xc_net = nn.Sequential(
            [
                nn.Dense(100),
                nn.elu,
                nn.Dense(100),
                nn.elu,
                nn.Dense(100),
                nn.elu,
                nn.Dense(1),
                nn.elu,  # TODO: check if this is correct
            ]
        )

    @staticmethod
    def input_transform(x: jax.Array) -> jax.Array:
        x0 = x[..., 0] ** (1 / 3)
        x1 = (1 / 2) * ((1 + x[..., 1]) ** (4 / 3) + (1 - x[..., 1]) ** (4 / 3))
        x2 = x[..., 2]
        x3 = x[..., 3] / (
            x0**5 * ((1 + x[..., 1]) ** (5 / 3) + (1 - x[..., 1]) ** (5 / 3))
        )
        return jnp.log(jnp.stack([x0, x1, x2, x3], axis=-1) + 1e-8)

    def exchange_correlation_energy_density(self, x: jax.Array) -> jax.Array:
        n = x[..., 0]
        xi = x[..., 1]
        prefactor = (
            -(n ** (1 / 3)) * (1 / 2) * ((1 + xi) ** (4 / 3) + (1 - xi) ** (4 / 3))
        )
        x = self.input_transform(x)
        x = self.xc_net(x)[:, 0]
        x = prefactor * (1 + x)
        return x


def I_transform(x: jax.Array, a: float) -> jax.Array:
    ex = jnp.exp(x)
    return a / (1 + (a - 1) * ex) - 1


class MyMGGA(nn.Module):
    general_precision: str

    @nn.compact
    def __call__(
        self, x: jax.Array, global_inp: jax.Array, weights: jax.Array
    ) -> jax.Array:
        n = x[..., 0]
        e_xc = self.exchange_correlation_energy_density(x, global_inp)
        out = jnp.where(weights != 0, weights * n * e_xc, 0).sum()
        return out.astype(self.general_precision)

    @staticmethod
    def input_transform(x: jax.Array) -> jax.Array:
        x0 = x[..., 0] ** (1 / 3)
        x1 = (1 / 2) * ((1 + x[..., 1]) ** (4 / 3) + (1 - x[..., 1]) ** (4 / 3))
        x2 = x[..., 2]
        x3 = x[..., 3]

        eps_log = 1e-5

        x0 = jnp.log(x0 + eps_log)
        x1 = jnp.log(x1 + eps_log)
        x2 = -jnp.expm1(-(x2**2)) * jnp.log1p(x2)
        x3 = jnp.log1p(x3) - jnp.log(2)
        return jnp.stack([x0, x1, x2, x3], axis=-1)

    def exchange_correlation_energy_density(
        self, x: jax.Array, global_inp: jax.Array
    ) -> jax.Array:
        n = x[..., 0]
        xi = x[..., 1]
        x = self.input_transform(x)
        x = jnp.concatenate([x, global_inp], axis=-1)

        e_x = self.exchange_energy_density(x, n)
        e_c = self.correlation_energy_density(x, n, xi)
        return e_x + e_c

    def exchange_energy_density(self, x, n) -> jax.Array:
        from mldft.nn.model import MLP

        ueg_limit_factor = x[..., 2] + jnp.tanh(x[..., 3]) ** 2

        NNx = MLP([16, 16, 1])(x[..., 2:])

        Fx = 1 + I_transform(NNx[:, 0] * ueg_limit_factor, 1.147)

        return Fx * e_x_ueg(n)

    def correlation_energy_density(self, x, n, xi) -> jax.Array:
        from mldft.nn.model import MLP

        ueg_limit_factor = x[..., 2] + jnp.tanh(x[..., 3]) ** 2

        NNc = MLP([16, 16, 1])(x)

        Fc = 1 + I_transform(NNc[:, 0] * ueg_limit_factor, 2)

        return Fc * e_c_ueg(n, xi)


class Dick2021(BaseMetaGGA):
    """
    Following the publication by
    Dick, Sebastian, and Marivi Fernandez-Serra.
    “Highly Accurate and Constrained Density Functional
    Obtained with Differentiable Programming.”
    Physical Review B 104, no. 16 (October 12, 2021): L161109.
    https://doi.org/10.1103/PhysRevB.104.L161109.
    """

    def setup(self) -> None:
        self.x_net = nn.Sequential(
            [
                nn.Dense(16),
                nn.gelu,
                nn.Dense(16),
                nn.gelu,
                nn.Dense(16),
                nn.gelu,
                nn.Dense(1),
            ]
        )
        self.c_net = nn.Sequential(
            [
                nn.Dense(16),
                nn.gelu,
                nn.Dense(16),
                nn.gelu,
                nn.Dense(16),
                nn.gelu,
                nn.Dense(1),
            ]
        )

    @staticmethod
    def input_transform(x: jax.Array) -> jax.Array:
        x0 = x[..., 0] ** (1 / 3)
        x1 = (1 / 2) * ((1 + x[..., 1]) ** (4 / 3) + (1 - x[..., 1]) ** (4 / 3))
        x2 = x[..., 2]
        x3 = x[..., 3]

        eps_log = 1e-5

        x0 = jnp.log(x0 + eps_log)
        x1 = jnp.log(x1 + eps_log)
        x2 = -jnp.expm1(-(x2**2)) * jnp.log1p(x2)
        x3 = jnp.log1p(x3) - jnp.log(2)
        return jnp.stack([x0, x1, x2, x3], axis=-1)

    def exchange_correlation_energy_density(self, x: jax.Array) -> jax.Array:
        n = x[..., 0]
        xi = x[..., 1]
        x = self.input_transform(x)

        e_x = self.exchange_energy_density(x, n)
        e_c = self.correlation_energy_density(x, n, xi)
        return e_x + e_c

    def exchange_energy_density(self, x, n) -> jax.Array:
        ueg_limit_factor = x[..., 2] + jnp.tanh(x[..., 3]) ** 2

        NNx = self.x_net(x[..., 2:])

        Fx = 1 + I_transform(NNx[:, 0] * ueg_limit_factor, 1.147)

        return Fx * e_x_ueg(n)

    def correlation_energy_density(self, x, n, xi) -> jax.Array:
        ueg_limit_factor = x[..., 2] + jnp.tanh(x[..., 3]) ** 2

        NNc = self.c_net(x)

        Fc = 1 + I_transform(NNc[:, 0] * ueg_limit_factor, 2)

        return Fc * e_c_ueg(n, xi)


def set_zeros(x: jax.Array, indices: Tuple[int]) -> jax.Array:
    return x.at[..., indices].set(0)


def set_ones(x: jax.Array, indices: Tuple[int]) -> jax.Array:
    return x.at[..., indices].set(1)


def l_intp(x):
    return jnp.tanh((x**2).sum(axis=-1, keepdims=True))


def phi(x):
    return jnp.log1p(jnp.exp(2 * x * jnp.log(2))) - jnp.log(2)


class Nagai2022(BaseMetaGGA):
    """
    Follows the publication by
    Nagai, Ryo, Ryosuke Akashi, and Osamu Sugino.
    “Machine-Learning-Based Exchange Correlation Functional
    with Physical Asymptotic Constraints.”
    Physical Review Research 4, no. 1 (February 11, 2022): 013106.
    https://doi.org/10.1103/PhysRevResearch.4.013106.
    """

    hidden: int = 16

    def setup(self) -> None:
        self.x_net1 = nn.Sequential(
            [
                nn.Dense(self.hidden),
                nn.gelu,
                nn.Dense(self.hidden),
                nn.gelu,
            ]
        )
        self.x_net2 = nn.Sequential([nn.Dense(self.hidden), nn.gelu, nn.Dense(1)])
        self.c_net1 = nn.Sequential(
            [
                nn.Dense(self.hidden),
                nn.gelu,
                nn.Dense(self.hidden),
                nn.gelu,
            ]
        )
        self.c_net2 = nn.Sequential([nn.Dense(self.hidden), nn.gelu, nn.Dense(1)])

    @staticmethod
    def input_transform(x: jax.Array) -> jax.Array:
        x0 = x[..., 0] ** (1 / 3)
        x1 = (1 / 2) * ((1 + x[..., 1]) ** (4 / 3) + (1 - x[..., 1]) ** (4 / 3))
        x2 = x[..., 2]
        x3 = x[..., 3]
        return jnp.tanh(jnp.stack([x0, x1, x2, x3], axis=-1))

    def exchange_correlation_energy_density(self, x: jax.Array) -> jax.Array:
        n = x[..., 0]
        xi = x[..., 1]
        s = x[..., 2]
        alpha = x[..., 3]
        x = self.input_transform(x)

        x_features = x[..., 2:]
        c_features = x

        e_x = self.exchange_energy_density(x_features, n, s, alpha)
        e_c = self.correlation_energy_density(c_features, n, s, xi, alpha)
        return e_x + e_c

    def exchange_energy_density(self, x, n, s, alpha) -> jax.Array:
        x_net = lambda x: self.x_net2(self.x_net1(x))
        Fx = x_net(x)

        xX3 = jnp.zeros_like(x)
        thetaX3 = 1 + Fx - x_net(xX3)
        xX4 = set_ones(x, (0,))
        thetaX4 = 1 + Fx - x_net(xX4)
        Fx = l_intp(x - xX4) / l_intp(xX3 - xX4) * thetaX3
        Fx += l_intp(x - xX3) / l_intp(xX4 - xX3) * thetaX4
        return phi(Fx[..., 0]) * e_x_scan(n, s, alpha)

    def correlation_energy_density(self, x, n, s, xi, alpha) -> jax.Array:
        print("T C1")

        def c_net(x):
            h2x = self.x_net1(x[..., 2:])
            h2c = self.c_net1(x)
            # print(x.shape, h2x.shape, h2c.shape,
            #       jnp.concatenate([h2x, h2c], axis=-1).shape)
            return self.c_net2(jnp.concatenate([h2x, h2c], axis=-1))
            # return self.c_net2(h2x + h2c)

        Fc = c_net(x)
        print("T C2")
        xC1 = set_zeros(x, (2, 3))
        thetaC1 = 1 + Fc - c_net(xC1)
        print("T C3 ")
        fC3 = c_net(set_zeros(x, (1,))) - c_net(set_zeros(x, (0, 1)))
        xC2 = set_zeros(x, (0,))
        thetaC2 = 1 + Fc - c_net(xC2) + fC3  # includes C3
        xC4 = set_ones(x, (0,))
        thetaC4 = 1 + Fc - c_net(xC4)

        print("T C4")
        Fc = (
            l_intp(x - xC2)
            * l_intp(x - xC4)
            / (l_intp(xC1 - xC2) * l_intp(xC1 - xC4))
            * thetaC1
        )
        print("T C5")
        Fc += (
            l_intp(x - xC1)
            * l_intp(x - xC4)
            / (l_intp(xC2 - xC1) * l_intp(xC2 - xC4))
            * thetaC2
        )
        Fc += (
            l_intp(x - xC1)
            * l_intp(x - xC2)
            / (l_intp(xC4 - xC1) * l_intp(xC4 - xC2))
            * thetaC4
        )
        print("T C6")
        out = phi(Fc[..., 0]) * e_c_scan(n, s, xi, alpha)
        print("T Final")
        return out


# @jax.custom_jvp
# def save_exp(x: jax.Array) -> jax.Array:
#     return jnp.exp(x)

# @save_exp.defjvp
# def save_exp_jvp(primals, tangents):
#     x, = primals
#     x_dot, = tangents
#     x = jnp.minimum(x, 5)
#     return jnp.exp(x), jnp.exp(x) * x_dot

# class DeepMind2021(BaseMetaGGA):
#     """
#     Local range-separated hybrid functional
#     # TODO: add HF features
#     """
#     def setup(self) -> None:
#         self.e_xc_net = nn.Sequential([
#                             nn.Dense(256),
#                             nn.tanh,
#                             nn.Dense(256),
#                             nn.elu,
#                             nn.LayerNorm(),
#                             nn.Dense(256),
#                             nn.elu,
#                             nn.LayerNorm(),
#                             nn.Dense(256),
#                             nn.elu,
#                             nn.LayerNorm(),
#                             nn.Dense(256),
#                             nn.elu,
#                             nn.LayerNorm(),
#                             nn.Dense(256),
#                             nn.elu,
#                             nn.LayerNorm(),
#                             nn.Dense(256),
#                             nn.elu,
#                             nn.Dense(3)

#                         ])

#     @staticmethod
#     def input_transform(x: jax.Array) -> jax.Array:
#         return jnp.log(jnp.abs(x) + 1e-4)

#     def exchange_energie_densities(self,
#             x: jax.Array) -> Tuple[jax.Array, jax.Array, jax.Array]:
#         # TODO: implement
#         e_LDA = 0
#         e_HF = 0
#         e_wHF = 0

#         return e_LDA, e_HF, e_wHF


def lda_xc_claude(rho):
    """
    Compute the LDA exchange-correlation energy density.
    
    Args:
    rho (jnp.ndarray): Electron density

    Returns:
    tuple: (e_x, e_c) where e_x is the exchange energy density and e_c is the correlation energy density
    """
    # Constants
    A = 0.0311
    B = -0.048
    C = 0.002
    D = -0.0116
    gamma = -0.1423
    beta1 = 1.0529
    beta2 = 0.3334

    # Avoid division by zero
    mask = rho > 1e-10
    # we might get numerical problems for very small values
    # here we instead fill in a 1 which should work well and then
    # set the result to zero.
    rho = jnp.where(mask, rho, 1)

    # Wigner-Seitz radius
    rs = (3 / (4 * jnp.pi * rho))**(1/3)

    # Exchange energy
    e_x = -3/(4*jnp.pi) * (3*jnp.pi**2)**(1/3) * rho**(1/3)

    # Correlation energy
    rs_sqrt = jnp.sqrt(rs)
    e_c = jnp.where(
        rs >= 1,
        gamma / (1 + beta1 * rs_sqrt + beta2 * rs),
        A * jnp.log(rs) + B + C * rs * jnp.log(rs) + D * rs
    )

    result = e_x + e_c
    return jnp.where(mask, result, 0)


class LDA(BaseMetaGGA):
    """
    Local density approximation
    """

    def exchange_correlation_energy_density(self, x: jax.Array) -> jax.Array:
        return lda_xc_claude(x[..., 0])
