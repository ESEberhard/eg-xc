import e3nn_jax as e3nn
import jax
import jax.numpy as jnp
import flax.linen as nn
import numpy as np
from copy import deepcopy

from .learnable_mGGA import LDA, Dick2021, MyMGGA, Nagai2020, Nagai2022, BaseMetaGGA
from .gnns.schnet import SchNet
from .gnns.painn import MyPaiNN, PaiNN
from .gnns.mace import MACE
from .nequip import NEQUIPESCNLayerFlax, default_radial_basis
from .embedding.feature_mask import RadialMask

from mldft.utils.typing import MoleculeSolverParams
from mldft.systems.constants import ANGSTROM_TO_BOHR
from typing import Literal, Sequence, Tuple, Dict, Any, Callable, Optional


class EquiLayerNorm(nn.Module):
    @nn.compact
    def __call__(self, irreps: e3nn.IrrepsArray):
        result = []
        for x in irreps.chunks:
            norms = jnp.linalg.norm(x, axis=-1)
            out_norms = nn.LayerNorm()(norms)
            saclings = jnp.where(
                norms.sum(-1, keepdims=True) == 0, 1.0, out_norms / norms
            )
            result.append((x * saclings[..., None]).reshape(*x.shape[:-2], -1))
        return e3nn.IrrepsArray(irreps.irreps, jnp.concatenate(result, axis=-1))


class MLP(nn.Module):
    dims: Sequence[int]

    @nn.compact
    def __call__(self, x):
        for dim in self.dims[:-1]:
            x = nn.Dense(dim)(x)
            x = nn.silu(x)
        x = nn.Dense(self.dims[-1])(x)
        return x


class EnergyOut(nn.Module):
    dims: Sequence[int]

    @nn.compact
    def __call__(self, x):
        x = e3nn.flax.Linear(self.dims[0] * e3nn.Irreps("0e"))(x)
        x = jax.nn.silu(x.array)
        return MLP(self.dims[1:])(x)


class NequIP(nn.Module):
    cutoff: float = 1
    irreps: str = "0e + 1o + 2e"
    feature_dim: int = 256

    @nn.compact
    def __call__(self, positions, node_features, mask):
        n = positions.shape[0]
        adjacency = np.ones((n, n), dtype=bool)
        adjacency = adjacency & ~np.eye(n, dtype=bool)
        senders, receivers = np.where(adjacency)
        vectors = (positions[:, None] - positions) / self.cutoff
        vectors = jnp.where(
            mask[:, None, None] & mask[None, :, None],
            vectors,
            jnp.ones_like(vectors),  # beyond the cutoff
        )
        vectors = e3nn.IrrepsArray("1o", vectors[adjacency])
        # node_features = EquiLayerNorm()(node_features)
        energy_out = EnergyOut([256, 256, 1])(node_features)

        density_out = e3nn.flax.Linear(16 * e3nn.Irreps(self.irreps))(node_features)
        for _ in range(3):
            node_features = NEQUIPESCNLayerFlax(
                0.1 * 8 * 8 * 8 * 3 / 4 * np.pi,  # typical density 0.1nuclei/A^3
                output_irreps=self.feature_dim * e3nn.Irreps(self.irreps),
                n_radial_basis=8,
            )(vectors, node_features, None, senders, receivers)
            # node_features = EquiLayerNorm()(node_features)
            energy_out += EnergyOut([256, 256, 1])(node_features)
            density_out += e3nn.flax.Linear(16 * e3nn.Irreps(self.irreps))(
                node_features
            )

        return (density_out * mask[:, None]) / 3, (energy_out * mask[:, None]) / 3


class MyMace(nn.Module):
    cutoff: float = 1
    irreps: str = "0e + 1o + 2e"
    feature_dim: int = 256

    @nn.compact
    def __call__(self, positions, node_features):
        vectors = (positions[:, None] - positions).reshape(-1, 3) / self.cutoff
        vectors = e3nn.IrrepsArray("1o", vectors)
        senders, receivers = np.where(
            np.ones((positions.shape[0], positions.shape[0]), dtype=bool)
        )
        node_features = EquiLayerNorm()(node_features)

        out = MACE(16 * e3nn.Irreps(self.irreps) + 1 * e3nn.Irreps("0e"))(
            vectors,
            node_features,
            senders,
            receivers,
        )  # [n_nodes, n_interactions, 16*irreps + 256*0e]
        out = e3nn.mean(out, axis=1)
        density_out, energy_out = out[..., :-1], out[..., -1:]
        return density_out, energy_out



def safe_norm(x, axis=-1, keepdims=True):
    x = (jnp.conj(x) * x).sum(axis=axis, keepdims=keepdims)
    zero_mask = x == 0
    x_safe = jnp.where(zero_mask, 1.0, x)
    x_safe = jnp.sqrt(x)
    return jnp.where(zero_mask, 0.0, x_safe)

class PartitionDensity(nn.Module):
    @nn.compact
    def __call__(self, q_positions, n_positions, mask):
        sigma = self.param("sigma", jax.nn.initializers.constant(1), (), jnp.float32)

        nq_diffs = n_positions[:, None] - q_positions
        nq_dists = safe_norm(nq_diffs, axis=-1, keepdims=False)
        nq_pdf = jnp.exp(-nq_dists / jnp.abs(sigma))
        nq_pdf = nq_pdf * mask[:, None]  # mask out all the fake nuclei
        normalizer = nq_pdf.sum(0, keepdims=True)
        nq_weights = nq_pdf / (normalizer + 1e-8)
        return nq_weights


class NewModel(nn.Module):
    mgga_model: Optional[BaseMetaGGA]
    cutoff: float = 5 * ANGSTROM_TO_BOHR  # taken from mace - nequip has default 4
    density_cutoff: float = 8  # bohr radius
    irreps: str = "0e + 1o + 2e"
    global_model: Literal["nequip", "painn", "mace"] = "nequip"
    global_readout: bool = True
    local_readout: bool = True
    feature_dim: int = 256

    @nn.compact
    def __call__(
        self,
        mgga_in_features: jax.Array,
        gnn_in_features: jax.Array,
        msp: MoleculeSolverParams,
    ):
        if not self.local_readout and not self.global_readout:
            return self.mgga_model(mgga_in_features, msp.quadrature_weights)
        q_density = mgga_in_features[..., 0]
        q_positions = msp.quadrature_points / self.cutoff
        q_weights = msp.quadrature_weights
        n_positions = msp.nuclear_positions / self.cutoff

        # N x Q x 3
        nq_diffs = n_positions[:, None] - q_positions
        # N x Q
        nq_dists = safe_norm(nq_diffs, axis=-1, keepdims=False)
        nq_dir = nq_diffs / (nq_dists[..., None] + 1e-8)
        # N x Q x F
        nq_rbf = default_radial_basis(nq_dists * self.cutoff / self.density_cutoff, 16)

        # compute spherical harmonics
        nq_harmonics = e3nn.spherical_harmonics(
            self.irreps, nq_dir, normalize=True, normalization="norm"
        )
        nq_weights = PartitionDensity()(
            q_positions * self.cutoff, n_positions * self.cutoff, msp.atom_mask
        )
        n_features = jnp.einsum(
            "nqf,nqh,q,q,nq->nfh",
            nq_rbf,
            nq_harmonics.array,
            q_density,
            q_weights,
            nq_weights,
        )
        n_features = e3nn.IrrepsArray(self.irreps, n_features)
        n_features = n_features.axis_to_irreps().regroup()

        # Global message passing
        xc = 0
        if self.global_model == "nequip":
            n_feature_density, xc_global = NequIP(1, self.irreps, self.feature_dim)(
                n_positions, n_features, msp.atom_mask
            )
            if self.global_readout:
                xc += xc_global.sum()
        elif self.global_model == "mace":
            n_feature_density, xc_global = MyMace(1, self.irreps, self.feature_dim)(
                n_positions, n_features
            )
            if self.global_readout:
                xc += xc_global.array.sum()
        elif self.global_model == "painn":
            n_features = e3nn.flax.Linear(256 * e3nn.Irreps("0e+1o"))(n_features)
            inv_features = n_features.filter("0e").mul_to_axis().array[..., 0]
            equi_features = n_features.filter("1o").mul_to_axis().array
            n_features, equi_features = MyPaiNN(256, 1, 16, 4)(
                inv_features,
                equi_features,
                n_positions,
                msp.atom_mask,
                msp.nuclear_charges,
            )
            n_feature_density = e3nn.flax.Linear(16 * e3nn.Irreps(self.irreps))(
                e3nn.concatenate(
                    [
                        e3nn.IrrepsArray("0e", n_features[..., None]),
                        e3nn.IrrepsArray("1o", equi_features),
                    ],
                    axis=-1,
                ).axis_to_irreps()
            )
            if self.global_readout:
                xc = MLP([256, 256, 1])(n_features).sum()
        else:
            raise ValueError("Unknown global model")
        if self.global_readout:
            xc *= self.param("xc_scale", jax.nn.initializers.zeros, (), jnp.float32)
        # Feature density
        q_feats = [jnp.log1p(mgga_in_features).astype(jnp.float32)]
        inv_features = n_feature_density.filter("0e").array  # .array[..., 0]
        for nq_h, n_h in zip(nq_harmonics.chunks, n_feature_density.chunks):
            nq_h = nq_h.squeeze(-2)
            rbf_to_f = MLP([256, 256, nq_rbf.shape[-1] * n_h.shape[-2]])(
                inv_features
            ).reshape(-1, nq_rbf.shape[-1], n_h.shape[-2]) / jnp.sqrt(nq_rbf.shape[-1])
            q_feats.append(
                jnp.einsum(
                    "nqd,nfd,nqr,nrf,nq->qf",
                    nq_h,
                    n_h,
                    nq_rbf,
                    rbf_to_f,
                    nq_weights,
                )
            )
        # Local readout
        q_feat = jnp.concatenate(q_feats, axis=-1)
        if self.mgga_model is not None:
            if self.local_readout:
                q_weight = MLP([16, 16, 1])(q_feat).squeeze(-1)
                q_weight = q_weight * self.param(
                    "mgga_scale", jax.nn.initializers.zeros, (), jnp.float32
                ) + self.param("mgga_shift", jax.nn.initializers.ones, (), jnp.float32)
            else:
                q_weight = 1
            # TODO: scale different for X and C
            xc += self.mgga_model(mgga_in_features, q_weight * msp.quadrature_weights)
        elif self.local_readout:
            xc += MyMGGA(q_feat.dtype)(mgga_in_features, q_feat, msp.quadrature_weights)
        else:
            assert self.global_readout, "No model"
        return xc


class AssembledModel(nn.Module):
    mgga_model: Optional[BaseMetaGGA]
    gnn: Optional[nn.Module]
    filter_params: Optional[Dict]

    @nn.compact
    def __call__(
        self,
        mgga_in_features: jax.Array,
        gnn_in_features: jax.Array,
        msp: MoleculeSolverParams,
    ) -> jax.Array:
        out = 0.0
        if self.mgga_model is not None:
            out += self.mgga_model(mgga_in_features, msp.quadrature_weights)
        if self.gnn is not None:
            if self.filter_params is not None:
                input_shape = gnn_in_features.shape
                feature_mask = RadialMask(**self.filter_params, shape=input_shape)()
                gnn_in_features = gnn_in_features * feature_mask[None]

            out += self.gnn(
                gnn_in_features,
                msp.nuclear_positions,
                msp.atom_mask,
                msp.nuclear_charges,
            )
        return out


def init_model(
    model: nn.Module,
    init_sample: MoleculeSolverParams,
    mgga_feature_fn: Optional[Callable],
    gnn_feature_fn: Optional[Callable],
    seed: int,
) -> Tuple[AssembledModel, Dict[str, Any]]:
    """
    Initializes a model with a given grid.
    Returns the model, its parameters.
    """
    if init_sample.quadrature_weights is not None:
        print(
            "Number of quadrature points of intial sample:",
            init_sample.quadrature_weights.shape[0],
        )

    gnn_in_features = (
        gnn_feature_fn(
            init_sample.initial_density_matrix,
            init_sample.atom_ao_values,
            init_sample.nuclear_positions,
            init_sample.nuclear_charges,
        )
        if gnn_feature_fn is not None
        else None
    )

    mgga_in_features = (
        mgga_feature_fn(
            init_sample.initial_density_matrix, init_sample.quadrature_ao_values
        )
        if mgga_feature_fn is not None
        else None
    )

    params = model.init(
        jax.random.PRNGKey(seed), mgga_in_features, gnn_in_features, init_sample
    )

    return model, params


def _params_consistency_check(hparams: Dict[str, Any]):
    """
    Check if the parameters are consistent with the model.
    """
    if hparams["model"]["use_schnet"] and hparams["model"]["use_painn"]:
        raise ValueError("Cannot use both SchNet and PaiNN at the same time.")
    if not hparams["model"]["use_schnet"] and not hparams["model"]["use_painn"]:
        if hparams["model"]["use_metaGGA"]:
            print("Warning: using semi-local model only")
        else:
            raise ValueError("Must use either SchNet, PaiNN or MetaGGA.")


def get_mgga_model(hparams: Dict[str, Any]) -> BaseMetaGGA:
    mparams = hparams["model"]
    if mparams["use_metaGGA"]:
        if mparams["metaGGA"]["type"] == "Dick2021":
            mgga_model = Dick2021(hparams["precision"]["general"])
        elif mparams["metaGGA"]["type"] == "Nagai2020":
            mgga_model = Nagai2020(hparams["precision"]["general"])
        elif mparams["metaGGA"]["type"] == "Nagai2022":
            mgga_model = Nagai2022(hparams["precision"]["general"])
        elif mparams["metaGGA"]["type"] == "LDA":
            mgga_model = LDA(hparams["precision"]["general"])
        else:
            raise NotImplementedError
    else:
        mgga_model = None
    return mgga_model


def get_model(hparams: Dict[str, Any]) -> AssembledModel:
    _params_consistency_check(hparams)

    mparams = hparams["model"]
    grid_params = hparams["density_grids"]

    embedding_params = deepcopy(hparams["model"]["Embedding"])
    embedding_params["n_resolutions"] = grid_params["n_resolutions"]
    embedding_params["invariant"]["use_nuclei_charge_embedding"] = mparams["atoms"][
        "use_nuclei_charge_embedding"
    ]
    embedding_params["invariant"]["element_symbols"] = mparams["atoms"]["symbols"]
    embedding_params["invariant"]["block_params"]["grid_spacing"] = grid_params[
        "atom_max_grid_spacing"
    ]

    # Select GNN
    if mparams["use_schnet"]:
        gnn = SchNet(**mparams["SchNet"], embedding_params=embedding_params)
    elif mparams["use_painn"]:
        embedding_params["equivariant"]["block_params"]["grid_spacing"] = grid_params[
            "atom_max_grid_spacing"
        ]
        embedding_params["equivariant"]["atom_max_cutoff"] = grid_params[
            "atom_max_cutoff"
        ]
        gnn = PaiNN(**mparams["PaiNN"], embedding_params=embedding_params)
    else:
        gnn = None

    # Optional input feature filter
    if mparams["filter_features"]:
        filter_params = mparams["RadialMask"]
    else:
        filter_params = None

    mgga_model = get_mgga_model(hparams)
    model = AssembledModel(mgga_model, gnn, filter_params)

    return model
