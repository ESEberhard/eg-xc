import jax
import jax.numpy as jnp
import flax.linen as nn
from typing import Optional


class LocalFeatureAggregate(nn.Module):
    """
    A simple CNN based embedding for atoms.
    """
    n_layers: int
    n_channels: int

    n_resolutions: int
    grid_spacing: float

    use_feature_mask: bool

    @nn.compact
    def __call__(self,
                 electron_density_features: jax.Array,
                 atom_mask: jax.Array,
                 feature_mask: Optional[jax.Array]):
        """
        electron_density_features:
            (N_atoms, N_resolutions, Nx, Ny, Nz, N_channels),
        atom_mask: indicates existing atoms
        feature_mask: (optional) (N_resolutions, Nx, Ny, Nz, N_channels)
        """
        out = []
        for r in range(self.n_resolutions):
            x_r = electron_density_features[:, r]  # treat each resolution separately
            for _ in range(self.n_layers - 1):
                x_r = nn.Conv(self.n_channels, (1,1,1), padding='VALID')(x_r)
                x_r = nn.gelu(x_r)
            x_r = nn.Conv(1,(1,1,1),
                          padding='VALID',
                          kernel_init=nn.initializers.zeros_init())(x_r)

            if self.use_feature_mask:
                x_r = jnp.einsum('aijkc, a, ijkc', x_r, atom_mask, feature_mask[r])
            else:
                x_r = jnp.einsum('a..., a', x_r, atom_mask)

            out.append(x_r.sum())

        return jnp.array(out).sum()