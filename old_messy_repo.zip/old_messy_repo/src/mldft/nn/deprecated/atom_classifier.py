import jax
import jax.numpy as jnp
import flax.linen as nn


class AtomClassifier(nn.Module):
    n_atom_types: int  # number of classes

    hidden_features: int
    n_layers: int  # number of hidden layers

    grid_spacing: float
    n_resolutions: int

    @nn.compact
    def __call__(self, electron_density: jax.Array):
        """
        Args:
            electron_density:
                shape (N_atoms, N_resolutions, Nx_grid, Nx_grid, Nx_grid)#
        Returns:
            unnormalized log probabilities for each atom type
        """
        resolution_factors = jnp.exp2(-jnp.arange(0, self.n_resolutions))
        x = electron_density.sum(axis=(2,3,4)) \
            * (self.grid_spacing * resolution_factors[None, :])**3
        for _ in range(self.n_layers):
            x = nn.Dense(self.hidden_features)(x)
            x = nn.softplus(x)
        x = nn.Dense(self.n_atom_types)(x)
        return x