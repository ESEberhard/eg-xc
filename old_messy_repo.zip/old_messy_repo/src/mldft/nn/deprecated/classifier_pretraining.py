import jax
import jax.numpy as jnp
import flax.linen as nn
import optax
from pyscf import gto, dft
from mldft.grids import features

from mldft.dataloading import CustomDatasetBase
from mldft.utils.typing import NnParams, AoValues
from typing import Dict, Any, List, Tuple
from tqdm import tqdm


def calculate_density_features(
                    mol_str: str,
                    hparams: Dict,
                    atom_ao_values: AoValues,
                    grid_shape: Tuple[int, int, int]) -> jax.Array:
    mol = gto.M(atom=mol_str,
                basis=hparams["basis"])
    mf = dft.RKS(mol)
    mf.xc = hparams["pretraining"]["xc"]
    mf.kernel()
    P = mf.make_rdm1()

    atom_grid_features_fn = features.get_atom_grid_features_fn(
                                hparams["density_features"],  # explicitly exclude scan
                                grid_shape)

    return atom_grid_features_fn(atom_ao_values, P)


def charges_to_labels(target_charges: jax.Array) -> jax.Array:
    charges = []
    for c in target_charges:
        if c == 1:
            charges.append(0)
        if c == 6:
            charges.append(1)
        if c == 7:
            charges.append(2)
        if c == 8:
            charges.append(3)
    return jnp.array(charges)


def run_pretraining(classifier: nn.Module,
                    params: NnParams,
                    hparams: Dict[str, Any],
                    dataset: CustomDatasetBase,
                    train_indices: List[int],
                    val_indices: List[int],
                    base_atom_grid_shape: Tuple[int, int, int]) -> NnParams:
    pretrainig_params = hparams["pretraining"]

    optimizer = optax.chain(
                    optax.adamw(
                        learning_rate=pretrainig_params["learning_rate"],
                        weight_decay=0,
                        b1=0.9  # momentum
                    )
                )
    opt_state = optimizer.init(params)

    def loss_fn(params: NnParams,
                labels: jax.Array,
                density_features: jax.Array) -> jax.Array:

        x = classifier.apply(params, density_features)
        loss = optax.softmax_cross_entropy_with_integer_labels(x, labels).mean()

        if pretrainig_params["include_energy_loss"]:
            pred_energy = jnp.einsum('ij,j->i', nn.softmax(x), dataset.xc_energy_per_atom)
            target_energy = jnp.einsum('ij,j->i', jax.nn.one_hot(labels, 4), dataset.xc_energy_per_atom)
            loss += ((pred_energy - target_energy)**2).sum()

        return loss

    loss_grad_fn = jax.value_and_grad(loss_fn, argnums=0)

    @jax.jit
    def step(params: NnParams,
             opt_state: optax.OptState,
             target_charges: jax.Array,
             density_features: jax.Array):

        loss, grads = loss_grad_fn(params, target_charges, density_features)
        updates, opt_state = optimizer.update(grads, opt_state, params)
        params = optax.apply_updates(params, updates)
        return params, opt_state, loss

    density_dict = {}
    def density_lookup(mol_str: str,
                       atom_ao_values: AoValues):
        try:
            density_features =  density_dict[mol_str]
        except:
            density_features = calculate_density_features(
                                        mol_str,
                                        hparams,
                                        atom_ao_values,
                                        base_atom_grid_shape
                                    )[..., 0]
            density_dict[mol_str] = density_features
        return density_features

    print("Starting pretraining")
    for i in range(pretrainig_params["epochs"]):
        print(f'############# EPOCH {i} #############')
        for j in tqdm(train_indices):
            mol_str = dataset.get_molecule_string(j)
            (_, _, train_mol_params, train_mol_solver_params) = dataset[j]

            atom_ao_values = jnp.array(train_mol_solver_params.atom_ao_values)
            density_features = density_lookup(mol_str, atom_ao_values)
            labels = charges_to_labels(train_mol_params.nuclear_charges)

            params, opt_state, loss = step(params,
                                           opt_state,
                                           labels,
                                           density_features)

            print("train loss: ", loss)

        for j in tqdm(val_indices):
            mol_str = dataset.get_molecule_string(j)
            (_, _, train_mol_params, train_mol_solver_params) = dataset[j]

            atom_ao_values = jnp.array(train_mol_solver_params.atom_ao_values)
            density_features = density_lookup(mol_str, atom_ao_values)
            labels = charges_to_labels(train_mol_params.nuclear_charges)

            loss = loss_fn(params, labels, density_features)

            print("validation loss: ", loss)

    return params