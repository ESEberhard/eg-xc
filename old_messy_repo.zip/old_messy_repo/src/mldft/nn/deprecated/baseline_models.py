import jax
import flax.linen as nn


class MLP(nn.Module):
    """
    A simple MLP with two hidden layers.
    """

    hidden_size: int
    output_size: int

    @nn.compact
    def __call__(self, x):
        x = x.flatten()
        x = nn.Dense(self.hidden_size)(x)
        x = nn.relu(x)
        x = nn.Dense(self.hidden_size)(x)
        x = nn.relu(x)
        x = nn.Dense(self.output_size)(x)
        return x


class SmallCNN(nn.Module):
    """
    A simple CNN with two hidden layers.
    """

    output_size: int

    @nn.compact
    def __call__(self, x):
        x = x[None, ...] # add batch dimension
        x = nn.Conv(features=1, kernel_size=(3,3,3))(x)
        x = nn.softplus(x)
        x = nn.Conv(features=1, kernel_size=(3,3,3), strides=2)(x)
        x = nn.softplus(x)
        x = nn.Conv(features=1, kernel_size=(3,3,3), strides=2)(x)
        x = nn.softplus(x)
        x = x.flatten()
        x = nn.Dense(self.output_size)(x)
        return x


class MediumCNN(nn.Module):
    """
    A simple CNN with two hidden layers.
    """
    output_size: int

    @nn.compact
    def __call__(self, x):
        x = x[None, ...] # add batch dimension
        # x = nn.Conv(features=4, kernel_size=(3,3,3))(x)
        # x = nn.softplus(x)
        x = nn.Conv(features=4, kernel_size=(5,5,5), strides=2)(x)
        x = nn.softplus(x)
        x = nn.Conv(features=4, kernel_size=(5,5,5), strides=2)(x)
        x = nn.softplus(x)
        x = nn.Conv(features=1, kernel_size=(5,5,5), strides=2)(x)
        x = nn.softplus(x)
        x = x.flatten()
        x = nn.Dense(self.output_size)(x)
        return x


class LargeCNN(nn.Module):
    """
    A simple CNN with two hidden layers.
    """

    output_size: int = 1

    @nn.compact
    def __call__(self, x):
        x = x[None, ...] # add batch dimension
        x = nn.Conv(features=16, kernel_size=(5,5,5))(x)
        x = nn.softplus(x)
        x = nn.Conv(features=32, kernel_size=(5,5,5))(x)
        x = nn.softplus(x)
        x = nn.Conv(features=64, kernel_size=(5,5,5), strides=2)(x)
        x = nn.softplus(x)
        x = nn.Conv(features=128, kernel_size=(5,5,5), strides=2)(x)
        x = nn.softplus(x)
        x = x.flatten()
        x = nn.Dense(64)(x)
        x = nn.softplus(x)
        x = nn.Dense(self.output_size)(x)
        return x


class NodeDensityEmbeddingCNN(nn.Module):
    """
    A simple CNN with two hidden layers.
    """
    embedding_dim: int
    n_layers: int
    n_channels: int
    stride: int

    @nn.compact
    def __call__(self, x: jax.Array):
        """
        input:
            x: shape (N_atoms, Nx_grid, Nx_grid, Nx_grid, grid_channels)
        """
        for _ in range(self.n_layers - 1):
            x = nn.Conv(features=self.n_channels,
                        kernel_size=(5,5,5),
                        strides=self.stride)(x)
            x = nn.softplus(x)

        x = nn.Conv(features=self.embedding_dim,
                    kernel_size=(1,1,1),
                    strides=1)(x)
        x = nn.softplus(x)
        # x = jnp.reshape(x, (x.shape[0], -1))
        # x = nn.Dense(self.embedding_dim)(x)
        x = x.sum(axis=(1,2,3))
        x = nn.softplus(x)
        # x = nn.Dense(self.embedding_dim)(x)
        # x = nn.softplus(x)
        return x


class LocalEmbeddingNet(nn.Module):

    latent_size: int
    embedding_layers: int
    embedding_channels: int
    embedding_stride: int
    head_layers: int

    @nn.compact
    def __call__(self, x):
        x = NodeDensityEmbeddingCNN(
                embedding_dim=self.latent_size,
                n_layers=self.embedding_layers,
                n_channels=self.embedding_channels,
                stride=self.embedding_stride
            )(x)
        x = x.sum(axis=0)
        for _ in range(self.head_layers):
            x = nn.Dense(self.latent_size)(x)
            x = nn.softplus(x)
        x = nn.Dense(1)(x)
        return x

