import jax
import jax.numpy as jnp
import flax.linen as nn
from typing import Tuple


def shifted_softplus(x):
    # TODO: use natural logarithm?
    return jnp.logaddexp2(x, 0) - 1


def test_function(x: jax.Array):
    """
    Smooth activation function that is zero for x < 1e-9
    """
    mask = x > 0
    term1 = jnp.exp(-1.0 / (jnp.abs(x) + 1e-2))
    return jnp.where(mask, term1, 0.0)

def custom_activation(x: jax.Array, a:float = 10.0, n: int = 2):
    """
    n times continuously differentiable function that is zero for x < 0.
    a parameterizes how quickly the function picks up from x = 0.
    """
    x = jnp.where(x < 0, 0.0, x)
    out = x * (1 - jnp.exp(-a * x))**n
    return out

class ResolutionGroupedConv(nn.Module):
    """
    A group of convolutions that are applied to different resolutions.
    """
    features: int
    kernel_size: Tuple[int, int, int]
    strides: Tuple[int, int, int]
    n_resolutions: int
    kernel_init: nn.initializers.Initializer = nn.initializers.xavier_uniform()

    def setup(self):
        # Define a list of convolutional layers for each resolution
        self.conv_layers = [
            nn.Conv(features=self.features,
                    kernel_size=self.kernel_size,
                    strides=self.strides,
                    use_bias=False,
                    kernel_init=self.kernel_init)
            for _ in range(self.n_resolutions)
        ]

    @nn.compact
    def __call__(self, x: jax.Array):
        """
        x: shape (N_atoms, N_resolutions, Nx_grid, Nx_grid, Nx_grid, grid_channels)
        """

        out = []  # TODO: vmap this!
        for resolution in range(self.n_resolutions):
            out.append(self.conv_layers[resolution](x[:, resolution]))

        x = jnp.stack(out, axis=1)
        return x


class LocalFeatureAggregate(nn.Module):
    """
    A simple CNN based embedding for atoms.
    """
    n_layers: int
    n_channels: int

    n_resolutions: int
    grid_spacing: float

    @nn.compact
    def __call__(self,
                 electron_density_features: jax.Array,
                 atom_pos: jax.Array):
        """
        # TODO: split for x and c energy separately?
        # TODO: which constraints can we fulfill -> probably none at all I guess?

        input:
            x: shape (N_atoms, N_resolutions, Nx_grid, Nx_grid, Nx_grid, grid_channels)
        """
        x = electron_density_features
        # e_scan = electron_density_features[..., -1]
        for _ in range(self.n_layers - 1):
            x = ResolutionGroupedConv(  features=self.n_channels,
                                        kernel_size=(1,1,1),
                                        strides=1,
                                        n_resolutions=self.n_resolutions
                                        )(x)
            x = custom_activation(x)
        x = ResolutionGroupedConv(  features=1,
                                    kernel_size=(1,1,1),
                                    strides=1,
                                    n_resolutions=self.n_resolutions,
                                    kernel_init=nn.initializers.zeros_init()
                                    )(x)

        # TODO: multiply by grid_spacing**3
        # The mean is stupid here, since larger molecules should have larger energies
        # density = electron_density_features[..., 0, None]
        return (x).sum(axis=tuple(range(x.ndim - 1)))