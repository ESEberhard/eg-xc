import jax
import flax.linen as nn

from mldft.nn.embedding.cnn import BaseEmbedding
from mldft.systems.elements import ATOMIC_NUM_BY_SYMBOL

from typing import Optional, List, Dict, Any


class InvariantEmbedding(nn.Module):
    """
    CNN based rotation invariant embedding for atoms.
    """
    n_layers: int
    n_features: int
    n_resolutions: int

    n_channels: List[int]
    res_block_depth: int
    n_res_blocks: int
    block_params: Dict[str, Any]
    use_atom_features: bool

    use_nuclei_charge_embedding: bool
    element_symbols: Optional[jax.Array] = None

    def setup(self):
        if self.use_nuclei_charge_embedding:
            assert self.element_symbols is not None
            charges = [ATOMIC_NUM_BY_SYMBOL[s] for s in self.element_symbols]

            self.embedding_layer = nn.Embed(max(charges) + 1, # TODO: remove unused embeddings
                                            self.n_features)

    @nn.compact
    def __call__(self,
                 x: jax.Array,
                 s: jax.Array,
                 v: jax.Array,
                 nuclear_charges: jax.Array):
        """
        Embeds the atoms into a higher dimensional feature space.
        The atoms are treated in parallel as a batch of size N_atoms.

        input shape: (N_atoms, N_res, Nx, Ny, Nz, N_channels)
        output shape: (N_atoms, N_feats
        """

        x = BaseEmbedding(
                n_layers=self.n_layers - 1,
                n_channels=self.n_channels,
                res_block_depth=self.res_block_depth,
                n_res_blocks=self.n_res_blocks,
                block_params=self.block_params,
                use_atom_features=self.use_atom_features
            )(x, s, v)

        x = x.reshape((x.shape[0], self.n_resolutions, -1))
        x = nn.Einsum((self.n_resolutions, x.shape[-1], self.n_features),
                      'ari, rio -> ao',
                      use_bias=False)(x)  # (N_atoms, N_feats)
        x = nn.silu(x)  # shape: (N_atoms, N_feats)

        if self.use_nuclei_charge_embedding:
            x += self.embedding_layer(nuclear_charges)

        return x
