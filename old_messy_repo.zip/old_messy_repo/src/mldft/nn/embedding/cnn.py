import jax
import jax.numpy as jnp
import flax.linen as nn

from mldft.grids.generation import generate_base_grid
from mldft.nn.embedding.radial_conv import RadConv
from typing import List, Dict, Any


class FilterNN(nn.Module):
    n_basis: int
    gamma: float   # in units of relative grid length
    layers: int  # layers for filter generator

    in_channels: int
    out_channels: int
    n_resolutions: int

    use_bias: bool = True

    def setup(self):
        self.mu = jnp.linspace(-0.05, 1, self.n_basis, dtype=jnp.float32)  # TODO: think about this

    @nn.compact
    def __call__(self, dist: jax.Array) -> jax.Array:
        """
        input:
            dist: distance grid
        returns: filter of shape dist.shape + (n_resolutions, in_channels, out_channels)
        """
        x = jnp.exp(- self.gamma * \
                            jnp.square(
                                dist[..., None] - self.mu[None, None, None, :]
                            )
                        ).astype(jnp.float32) # shape (N, N, N, n_basis)

        if self.use_bias:
            constant_base = jnp.where(dist < 1, 1, 0)[..., None]
            x = jnp.concatenate([x, constant_base], axis=-1)

        n_filters = self.in_channels * self.out_channels * self.n_resolutions

        for _ in range(self.layers - 1):
            x = nn.Dense(n_filters, use_bias=False)(x)
            x = nn.silu(x)

        x =  nn.Dense(n_filters, use_bias=False)(x)

        if self.use_bias:
            x += constant_base
        x = x.reshape(dist.shape + (self.n_resolutions, self.in_channels, self.out_channels))
        return x


class GlobalRadialFilter(nn.Module):
    filter_params: Dict[str, Any]

    n_xyz: int
    in_channels: int
    out_channels: int
    n_resolutions: int

    use_atom_features: bool

    def setup(self):
        points_per_unit_length = (self.n_xyz - 1) // 2
        h = 1 / points_per_unit_length
        self.grid = generate_base_grid(h, 1).coords.astype("float32")
        self.grid_dist = jnp.linalg.norm(self.grid, axis=-1)  # (N, N, N)

    @nn.compact
    def __call__(self, x: jax.Array, s: jax.Array, v: jax.Array) -> jax.Array:
        """
        x: (N_atoms, N_resolutions, N, N, N, C_in)
        s: scalar features (N_atoms, F_pre_paiNN)
        v: vector features (N_atoms, F_pre_paiNN, 3)
        """
        filters = FilterNN(  # isotropic filter
                        **self.filter_params,
                        in_channels=self.in_channels,
                        out_channels=self.out_channels,
                        n_resolutions=self.n_resolutions
                    )(self.grid_dist)
        filters = jnp.swapaxes(filters, 0, 3)[None] # shape (1, N_resolutions, N, N, N, C_in, C_out)

        if self.use_atom_features:
            # learn anisotropic filter correction
            v = nn.Einsum((s.shape[1], x.shape[1], x.shape[-1], self.out_channels),
                        'afs, frio -> arios', use_bias=False)(v)
            Wm_1 = FilterNN(
                        **self.filter_params,
                        in_channels=self.in_channels,
                        out_channels=self.out_channels,
                        n_resolutions=self.n_resolutions,
                        use_bias=False
                    )(self.grid_dist) # (N, N, N, N_resolutions, C_in, C_out)
            norm_v = jnp.linalg.norm(v, axis=-1)
            Wm_2 = FilterNN(
                        **self.filter_params,
                        in_channels=1,
                        out_channels=1,
                        n_resolutions=1,
                        use_bias=False
                    )(norm_v)[..., 0, 0, 0] # (N_atoms, N_resolutions, C_in, C_out)
            filters += jnp.einsum('xyzs, arios, xyzrio, ario -> arxyzio',
                                  self.grid / (self.grid_dist[..., None] + 1e-7),
                                  v / (norm_v[..., None] + 1e-7),
                                  Wm_1, Wm_2)  # (N_atoms, N_resolutions, N, N, N, C_out
            # filters += jnp.einsum('xyzs, arios -> arxyzio',
            #                       self.grid / (self.grid_dist[..., None] + 1e-7),
            #                       v / (norm_v[..., None] + 1e-7))  # (N_atoms, N_resolutions, N, N, N, C_out
            # s = nn.Einsum((s.shape[1], x.shape[1], x.shape[-1], self.out_channels),
            #               'af, frio -> ario', use_bias=False)(s)
            # return jnp.einsum('arxyzi, ario, arxyzio -> arxyzo', x, s, filters)  # TODO: think about / self.in_channels
        return jnp.einsum('arxyzi, arxyzio -> arxyzo', x, filters)

class EmbeddingBlock(nn.Module):
    out_channels: int

    stride: int
    padding: str

    grid_spacing: float

    base: Dict[str, Any]
    use_atom_features: bool

    @nn.compact
    def __call__(self, x: jax.Array, s: jax.Array, v: jax.Array) -> jax.Array:
        """
        in: (N_atoms, N_resolutions, N, N, N, C_in)
        """
        x = GlobalRadialFilter(
                filter_params=self.base["global_radial_filter_params"],
                n_xyz=x.shape[-2],
                in_channels=x.shape[-1],
                out_channels=x.shape[-1],
                n_resolutions=x.shape[1],
                use_atom_features=self.use_atom_features
            )(x, s, v)
        x = RadConv(
                in_features=x.shape[-1],
                out_features=self.out_channels,
                kernel_size=self.base["kernel_size"],
                stride=self.stride,
                padding=self.padding,
                spacing=self.grid_spacing,
                n_resolutions=x.shape[1],
                n_basis=self.base["n_base_kernels"],
                dtype=x.dtype
            )(x)
        return nn.silu(x)


class ResEmeddingBlocks(nn.Module):
    out_channels: int
    res_block_depth: int
    n_res_blocks: int

    grid_spacing: float
    base_params: Dict[str, Any]
    use_atom_features: bool

    @nn.compact
    def __call__(self, x: jax.Array, s: jax.Array, v: jax.Array) -> jax.Array:
        for _ in range(self.n_res_blocks):
            dx = x
            for _ in range(self.res_block_depth):
                dx = EmbeddingBlock(
                            out_channels=self.out_channels,
                            stride=1,
                            padding="SAME",
                            grid_spacing=self.grid_spacing,
                            base=self.base_params,
                            use_atom_features=self.use_atom_features
                        )(dx, s, v)
            x += dx
        return x


class BaseEmbedding(nn.Module):
    n_layers: int

    n_channels: List[int]
    res_block_depth: int
    n_res_blocks: int
    block_params: Dict[str, Any]
    use_atom_features: bool

    @nn.compact
    def __call__(self, x: jax.Array, s: jax.Array, v: jax.Array):
        for i in range(self.n_layers):
            x = ResEmeddingBlocks(
                    out_channels=x.shape[-1],
                    res_block_depth=self.res_block_depth,
                    n_res_blocks=self.n_res_blocks,
                    grid_spacing=self.block_params["grid_spacing"],
                    base_params=self.block_params["base"],
                    use_atom_features=self.use_atom_features
                )(x, s, v)
            x = EmbeddingBlock(out_channels=self.n_channels[i],
                               use_atom_features=self.use_atom_features,
                               **self.block_params)(x, s, v)
        return x