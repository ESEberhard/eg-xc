from .invariant import InvariantEmbedding
from .equivariant import EquivariantEmbedding