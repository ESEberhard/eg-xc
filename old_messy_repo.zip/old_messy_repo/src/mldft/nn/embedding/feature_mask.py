import jax.numpy as jnp
import flax.linen as nn
from mldft.grids.generation import generate_base_grid


class RadialMask(nn.Module):
    n_basis: int
    gamma: float   # in units of relative grid length

    n_xyz: int
    n_channels: int
    n_resolutions: int

    def setup(self):
        mu = jnp.linspace(-0.05, 0.95, self.n_basis, dtype=jnp.float32)  # TODO: Think about this

        points_per_unit_length = (self.n_xyz - 1) // 2
        h = 1 / points_per_unit_length
        grid = generate_base_grid(h, 1).coords
        dist = jnp.linalg.norm(grid, axis=-1)  # (N, N, N)
        self.gaussian_basis = jnp.exp(- self.gamma * \
                            jnp.square(
                                dist[..., None] - mu[None, None, None, :]
                            )
                        ).astype(jnp.float32) # shape (N, N, N, n_filters)

    @nn.compact
    def __call__(self):
        mask = nn.Dense(self.n_channels * self.n_resolutions,
                        # kernel_init=nn.initializers.ones_init(),
                        use_bias=False)(self.gaussian_basis)
        mask = nn.silu(mask)
        # mask = nn.Dense(self.n_channels * self.n_resolutions,  # TODO: add second layer?
        #                 use_bias=False)(self.gaussian_basis)
        # mask = nn.silu(mask)  # shape (N, N, N, N_resolutions * N_channels)
        mask = mask.reshape(self.n_xyz, self.n_xyz, self.n_xyz, self.n_resolutions, self.n_channels)
        mask = jnp.swapaxes(mask, 0, 3) # shape (N_resolutions, N, N, N, N_channels)
        return mask  # shape (N_resolutions, N, N, N, N_channels)

