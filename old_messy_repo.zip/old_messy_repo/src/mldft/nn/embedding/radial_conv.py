import jax
import jax.numpy as jnp
import flax.linen as nn
from typing import Union


def radial_basis(r, mu, gamma):
    return jnp.exp(-gamma * jnp.square(r - mu))


def get_base_kernels(kernel_size: int,
                     spacing: float,
                     n_basis: int,
                     dtype: Union[str, jax.typing.DTypeLike]):
    assert kernel_size % 2 == 1, "Kernel size must be odd"

    mu_vec = jnp.linspace(0,
                          spacing * (kernel_size // 2) + 1,
                          n_basis)
    gamma = 1 / spacing

    def get_basis_kernel(kernel_size, spacing, mu, gamma):
        k_half = kernel_size // 2
        x = jnp.mgrid[-k_half : k_half + 1,
                    -k_half : k_half + 1,
                    -k_half : k_half + 1].T * spacing
        # x: shape (kernel_size, kernel_size, kernel_size, 3)
        r = jnp.linalg.norm(x, axis=-1)

        kernel = jax.vmap(jax.vmap(jax.vmap(lambda r: radial_basis(r, mu, gamma))))(r)
        return kernel

    base_kernels = jax.vmap(get_basis_kernel,
                            in_axes=(None, None, 0, None))(
                            kernel_size,
                            spacing,
                            mu_vec,
                            gamma)
    return base_kernels.astype(dtype)


class RadConv(nn.Module):
    """
    A rotationally invariant convolutional layer based on gaussian basis functions.
    """
    in_features: int
    out_features: int
    kernel_size: int
    stride: int
    padding: str
    spacing: float

    n_resolutions: int
    n_basis: int
    dtype: Union[str, jax.typing.DTypeLike]
    use_bias: bool = True

    def setup(self):
        self.base_kernels = get_base_kernels(self.kernel_size,
                                             self.spacing,
                                             self.n_basis,
                                             dtype=self.dtype)
        # base_kernels: shape (n_resolutions, n_basis, kernel_size, kernel_size, kernel_size)
        # TODO: think about smart initilization of these layers
        basis_coeff_shape = (self.n_resolutions, self.out_features, self.in_features, self.n_basis)
        self.basis_coeff = self.param('basis_coeff',
                                lambda rng_key:
                                    1e-3 * jax.random.normal(rng_key, basis_coeff_shape, dtype=self.dtype)
                                )
        if self.use_bias:
            self.bias = self.param('bias',
                                    lambda _:
                                        nn.initializers.zeros(_, (self.out_features,), dtype=self.dtype)
                                    )

    def __call__(self, x: jax.Array):
        """
        x: shape (N_atoms, N_resolutions, Nx_grid, Ny_grid, Nz_grid, grid_channels)
        """
        kernel = jnp.einsum('ruvl, lijk -> ruvijk',
                            self.basis_coeff,  # shape (n_resolutions, out_features, in_features, n_basis)
                            self.base_kernels) # shape (n_basis, kernel_size, kernel_size, kernel_size)

        # kernel: shape (n_resolutions, out_features, in_features, Nx_grid, Ny_grid, Nz_grid, kernel_size, kernel_size, kernel_size)

        def conv(x_resolution: jax.Array, kernel_resolution: jax.Array):
            """
            x_resolution: shape (N_atom, Nx_grid, Ny_grid, Nz_grid, grid_channels)
            kernel: shape (out_features, in_features, Nx_grid, Ny_grid, Nz_grid)
            """
            x_resolution = jnp.moveaxis(x_resolution, -1, 1)  # shape (N_resolutions, grid_channels, Nx, Ny, Nz)

            temp = jax.lax.conv_general_dilated(x_resolution,
                                                kernel_resolution,
                                                window_strides=[self.stride]*3,
                                                padding=self.padding)
            if self.use_bias:
                temp += self.bias[None, :, None, None, None]
            return jnp.moveaxis(temp, 1, -1)

        out = jax.vmap(conv, in_axes=(1, 0), out_axes=1)(x, kernel)
        return out