import jax
import jax.numpy as jnp
import flax.linen as nn

from mldft.nn.embedding.cnn import BaseEmbedding

from typing import List, Dict, Any


class FilterGenerator(nn.Module):
    n_resolutions: int
    n_channels: int
    n_basis: int = 20

    def setup(self) -> None:
        n = jnp.arange(1, self.n_basis + 1)
        self.prefactors = n * jnp.pi

    @nn.compact
    def __call__(self, r: jax.Array) -> jax.Array:
        """
        input: distance to grid center in respective grid units
            (Nx_grid, Ny_grid, Nz_grid)
        output: scalar filter
            (N_resolutions, Nx_grid, Ny_grid, Nz_grid, n_features)
        """
        x = jnp.sin(r[..., None] * self.prefactors[None, None, None, :])  # shape (N_atoms, N_resolutions, Nx_grid, Ny_grid, Nz_grid, n_basis)
        x = nn.Einsum((self.n_resolutions, self.n_channels, self.n_basis),
                      'xyzn, rfn -> rxyzf')(x)
        return x


class EquivariantEmbedding(nn.Module):
    n_layers: int
    n_features: int
    n_resolutions: int
    use_atom_features: bool

    n_channels: List[int]
    res_block_depth: int
    n_res_blocks: int
    block_params: Dict[str, Any]
    atom_max_cutoff: float

    def setup(self):
        # generate base grid
        h = self.block_params["grid_spacing"] / self.atom_max_cutoff
        linear_grid = jnp.arange(-1, 1 + h, h, dtype=jnp.float32)
        assert len(linear_grid) % 2 == 1

        # Create the 3D grid using meshgrid
        coords = jnp.stack(jnp.meshgrid(linear_grid, linear_grid, linear_grid),
                           axis=-1)
        self.pos = jnp.swapaxes(coords, 0, 1)  # (Nx, Ny, Nz, 3)
        self.r   = jnp.linalg.norm(self.pos, axis=-1)  # (Nx, Ny, Nz)

    @nn.compact
    def __call__(self,
                 x: jax.Array,
                 s: jax.Array,
                 v: jax.Array,) -> jax.Array:
        """
        input:  x (jax.Array): grid features (N_atoms, N_res, Nx, Ny, Nz, N_channels)
        output: equivariant atom features (N_atoms, n_feats, 3)
        """
        x = BaseEmbedding(
                n_layers=self.n_layers - 1,
                n_channels=self.n_channels,
                res_block_depth=self.res_block_depth,
                n_res_blocks=self.n_res_blocks,
                block_params=self.block_params,
                use_atom_features=self.use_atom_features
            )(x, s, v)

        W = FilterGenerator(self.n_resolutions, self.n_features)(self.r)
        v = jnp.einsum(
                'arxyzc, xyzi, rxyzf -> arcfi',
                x,
                self.pos / self.r[..., None],
                W
            )  # (N_atoms, N_res, Nx, Ny, Nz, N_channels)
        v = nn.Einsum(
                (self.n_resolutions, x.shape[-1]),
                'arcfi, rc -> afi',
                use_bias=False,
                kernel_init=nn.initializers.zeros_init()
            )(v)  # (N_atoms, n_feats, 3)
        return v
