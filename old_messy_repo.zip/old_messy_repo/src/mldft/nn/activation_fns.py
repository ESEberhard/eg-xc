import jax
import jax.numpy as jnp


def shifted_softplus(x: jax.Array) -> jax.Array:
    # TODO: use natural logarithm?
    return jnp.logaddexp2(x, 0) - 1

def test_function(x: jax.Array) -> jax.Array:
    """
    Smooth activation function that is zero for x < 1e-9
    """
    mask = x > 0
    term1 = jnp.exp(-1.0 / (jnp.abs(x) + 1e-2))
    return jnp.where(mask, term1, 0.0)

def custom_activation(x: jax.Array, a:float = 10.0, n: int = 2) -> jax.Array:
    """
    n times continuously differentiable function that is zero for x < 0.
    a parametrizes how quickly the function picks up from x = 0.
    """
    x = jnp.where(x < 0, 0.0, x)
    out = x * (1 - jnp.exp(-a * x))**n
    return out